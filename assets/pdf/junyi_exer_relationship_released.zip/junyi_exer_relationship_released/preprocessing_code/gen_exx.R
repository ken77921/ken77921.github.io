library(multicore)
require(tools)
options(stringsAsFactors = F)
options(digit.secs=6)

min_num=5

get.exx <- function(is,ie) {
	d=NULL
	for(i in is:(ie-1)) {
		if(i%%10==0) print(i)
		pp = pall[((eix[i]+1):eix[i+1]),]
		pp = pp[pp$total_num>=min_num,]
		if(nrow(pp)==0) next
		e = unique(pp$exercise)
		un = length(unique(pp$user_id))
		tns = pp$total_num[pp$problem_num==1]
		c1 = pp$correct[pp$problem_num==1]
		cl = pp$correct[pp$problem_num==pp$total_num]
		
		d = rbind(d,data.frame(exer = e,
							   c1.crt=sum(c1)/length(c1),
							   cl.crt=sum(cl)/length(cl),
							   tn_mn=mean(tns),
							   tn_med=median(tns),
							   tn_var=var(tns),
							   tn_sum=sum(tns),
							   unum=un))
	}
	return(d)
}

print("loads pall......")
lf = list.files("db")

checkEx <- function(i) {
	if(i%%10000==0) print(i)
	return(pall$exercise[i]!=pall$exercise[i+1])
} 

if("junyi_pall_e.RData" %in% lf) {
	print("loads db......")
	load("db/junyi_pall_e.RData")
} else {
	source("gen_pall.R")
	print("sorts pall by exercises......")
	pall = pall[order(pall$exercise),]
	print("generates index for pall by exercises....")
	eix = c(0, which(sapply(1:(nrow(pall)-1), function(i) checkEx(i))), nrow(pall))
	save(pall,eix, file="junyi_pall_e.RData")
}
index = c(seq(from=1, to=length(eix), by = 50), length(eix))

jobs = list()
j=0
d = NULL

print("generates exx......")
for(i in 1:(length(index)-1)) {
	j=j+1
	jobs[[j]] = parallel(get.exx(index[i], index[i+1]))
	if(length(jobs)>=17) {
		print("start collecting results")
		ret = collect(jobs)
		for(i in 1:length(ret)) {
			d = rbind(d, ret[[i]])
		}
		print("end of collection")
		j=0
		jobs=list()
	}
}
if(length(jobs)) {
	print("final collection")
	ret = collect(jobs)
	for(i in 1:length(ret)) {
		d = rbind(d, ret[[i]])
	}
	jobs=list()
}

save(d, file="junyi_exx.RData")
write.csv(d, file="results/ken_exx.csv")


	