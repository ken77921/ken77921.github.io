library(multicore)
require(tools)
options(stringsAsFactors = F)
options(digit.secs=6)

# number of parallel threads
# decided based on the capability of the machine executing the process
num_thrd = 17

get.ft2 <- function(is, ie, tgt) {
	print(sprintf("%d,%d", is, ie))
	dd = NULL
	for(i in is:(ie-1)) {
		if(i%%200==0) print(i)
		pp = pr[(uix.pr[i]+1):uix.pr[i+1],]
		if(sum(pp$exercise==tgt)==0) next
		ts = min(pp$time_done[pp$exercise==tgt])
		u = which(uids==unique(pp$user_id))
		es = intersect(ee, unique(pp$exercise[pp$time_taken>0&(pp$time_done<ts)]))
		dd = rbind(dd, do.call(rbind, lapply(es, function(e) {
										pp2 = pp[pp$time_taken>0&pp$exercise==e&(pp$time_done<ts),]
										if(sum(pp2$correct)==0) t.df = difftime(ts, min(pp2$time_done), unit="sec")
										else t.df = as.numeric(difftime(ts, min(pp2$time_done[pp2$correct]), unit="sec"))
										num = nrow(pp2)
										return(data.frame(uid = u, e1 = which(ee==tgt), e2 = which(ee==e), num = num, crct = sum(pp2$correct)/num, tt.avg = sum(pp2$time_taken)/num,t.df=t.df))
									})))
	}
	return(dd)
}

lfs = list.files("results")

index = c(seq(from=1, to=length(uix.pr), by = 6000), length(uix.pr))
#index = c(seq(from=1, to=30, by = 10), 41)
jobs = list()
for(tgt in ee) {
#for(tgt in c("count_one_by_one_1")) {
	fn = sprintf("pretest_feature_%s.csv", tgt)
	if(fn %in% lfs) next
	d = NULL
	print(tgt)
	for(i in 1:(length(index)-1)) {
		jobs[[length(jobs)+1]] = parallel(get.ft2(index[i], index[i+1], tgt))
		if(length(jobs)>=num_thrd) {
			print("start collecting results")
			ret = collect(jobs)
			for(i in 1:length(ret)) {
				d = rbind(d, ret[[i]])
			}
			print("end of collection")
			jobs=list()
		}
	}
	if(length(jobs)) {
		print("final collection")
		ret = collect(jobs)
		if(length(ret)>0) {
			for(i in 1:length(ret)) {
				d = rbind(d, ret[[i]])
			}
		}
		jobs=list()
	}
	write.csv(d, file=sprintf("results/pretest_feature_%s.csv", tgt))
}

