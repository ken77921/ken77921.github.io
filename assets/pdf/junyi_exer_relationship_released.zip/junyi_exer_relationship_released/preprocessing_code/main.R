require(tools)
options(stringsAsFactors = F)
options(digit.secs=6)

ready.load=T
ready.proc=F

#loading problem logs
lf_db = list.files("db")
lf_junyi = list.files("junyi")
ready.load=T
if("junyi_pr.RData" %in% lf_db) {
	re.load.pl.csv = F
	re.load.pl.rdata = T
} else if("junyi_ProblemLog.csv" %in% lf_junyi) {
	re.load.pl.csv = T
	re.load.pl.rdata = F
} else {
	print("no csv or RData for ProblemLog, loading fails......")
	ready.load = F
}
if(!("junyi_Exercise.csv" %in% lf_junyi)) {
	print("no csv file for Exercise, loading fails......")
	ready.load = F
} else re.load.exer = T

if(ready.load) {
	source("load.R")
	uids = unique(pr$user_id)
	ee = unique(exer$name[exer$live=="true"])
	ready.proc=T
}


if(ready.proc) {
	write.csv(unique(pr$exercise), file="results/pretest_exer_list.csv")
	write.csv(unique(uids), file="results/pretest_uid_list.csv")
	write.csv(unique(ee), file="results/pretest_exer_list_live.csv")
	source("gen_label.R")
	source("gen_feature.R")
	source("gen_exx.R")
}