require(tools)
options(stringsAsFactors = F)
options(digit.secs=6)

load("db/junyi_pr.RData")
exer = read.csv(file="junyi/junyi_Exercise.csv")

d = pr[,c("user_id","exercise","problem_type","correct","count_attempts","hint_used","time_taken","ip_address")]
d$fast = sapply(1:nrow(pr), function(i) pr$time_taken[i]<=exer$seconds_per_fast_problem[exer$name==pr$exercise[i]][1])
d$uid = pr$user_id
d$date = pr$time_done
names(d)[1]="user"
write.csv(d, file="junyi/proc_ProblemLog.csv")
write.csv(max(d$date), file="junyi/proc_timestamp.csv")
