require(tools)
options(stringsAsFactors = F)
options(digit.secs=6)

#re.load.pl.csv = T
#re.load.exer = T
#re.load.pl.rdata = F

checkID <- function(i) {
	if(i%%10000==0) print(i)
	return(pr$user_id[i]!=pr$user_id[i+1])
} 

if(re.load.pl.csv) {
	print("loading problem logs")
	pr = read.csv(file = "junyi/junyi_ProblemLog.csv",encoding="UTF-8")
	print("raw problem logs are loaded, now starts purging......")
	
	print("gets rid of the logs made by shadow ids......")
	pr = pr[!grepl("nouserid", pr$user_id),]
	
	print("corrects boolean values......")
	pr$correct=(pr$correct=="true")
	pr$earned_proficiency=(pr$earned_proficiency=="true")
	pr$hint_used=(pr$hint_used=="true")
	pr$review_mode=(pr$review_mode=="true")
	pr$suggested=(pr$suggested=="true")
	pr$topic_mode=(pr$topic_mode=="true")
	
	print("transforms time_done into POSIX format")
	pr$time_done=as.POSIXlt(pr$time_done/10^6,tz="Asia/Taipei",origin="1970-01-01")
	
	print("generating user index")
	pr = pr[(pr$time_taken>0)&(!(pr$count_attempts==1&pr$count_hints==0&!pr$correct)),]
	pr = pr[order(pr$user_id),]
	uix.pr = c(0, which(sapply(1:(nrow(pr)-1), function(i) checkID(i))), nrow(pr))
	
	# testing whether the user index is done correctly
	###
	#ix = sample(1:length(uix.pr), 10, replace=F)
	#for(i in ix) {
	#	if(sum(pr$user_id==pr$user_id[uix.pr[i]])>1) {
	#		print(sprintf("%s,%s,%s,%s",pr$user_id[uix.pr[i]-1], pr$user_id[uix.pr[i]], pr$user_id[uix.pr[i]+1], (pr$user_id[uix.pr[i]-1]==pr$user_id[uix.pr[i]]&&pr$user_id[uix.pr[i]]!=pr$user_id[uix.pr[i]+1])))
	#	}
	#}
	###
	print("save the processed problem logs as RData")
	save(pr, uix.pr, file="db/junyi_pr.RData")
}
if(re.load.pl.rdata) {
	print("loading junyi_pr.RData")
	load(file="db/junyi_pr.RData")
}

if(re.load.exer) {
	print("loading Exercise")
	exer = read.csv(file="junyi/junyi_Exercise.csv")
}