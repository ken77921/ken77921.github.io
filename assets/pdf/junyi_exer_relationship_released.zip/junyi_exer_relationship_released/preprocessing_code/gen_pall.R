library(multicore)
require(tools)
options(stringsAsFactors = F)
options(digit.secs=6)

re.load=F
if(re.load) {
	print("loading data set")
	load(file="junyi_pr.RData")
	exer=read.csv(file="junyi_Exercise.csv")
}

cal.ewma <- function(ans, weight) {
	ewma=0.9
	for(i in 1:length(ans)) {
		ewma = weight*ans[i]+(1-weight)*ewma
	}	
	return(ewma)
}

coefs=c(-1.2229719,0.8393673,2.1262489,0.0153545,0.4135883,-0.5677724,0.6284309)
	
get.pall <- function(is, ie) {
	print(sprintf("%d,%d", is, ie))
	dd = NULL
	for(i in is:(ie-1)) {
		if(i%%50==0) print(i)
		pp = pr[(uix.pr[i]+1):uix.pr[i+1],]
		e = unique(pp$exercise)
		for(ee in e) {
			ppp = pp[pp$exercise==ee,]
			nn = nrow(ppp)
			tmp = ppp[,c("user_id","exercise","problem_type","correct","count_attempts","count_hints","time_taken","earned_proficiency","points_earned","review_mode","time_done")]
			tmp = tmp[order(tmp$time_done),]
			tmp$time_per_attempt=(tmp$time_taken/tmp$count_attempts)
			tmp$problem_num=(1:nn)
			tmp$total_num=nn
			if(nrow(tmp)==1) tmp$gap=-1
			else tmp$gap = c(-1, sapply(2:nrow(tmp), function(j) difftime(tmp$time_done[j],tmp$time_done[j-1],units="secs")))
			tmp$crt2 = (1/(tmp$count_attempts+tmp$count_hints))
			ft = exer$seconds_per_fast_problem[exer$name==ee][1]
			tmp$tt2 = tmp$time_taken/ft
			
			oracle=tmp$correct
			zs=vector()
			streak=0
			max_streak=0
			for(ii in 1:length(oracle)) {
				if(ii<=20) {
					ix = 1:ii
				} else {
					ix=((ii-19):ii)
				}
				ans = oracle[ix]
				if(oracle[ii]) {
					streak=streak+1
					if(max_streak<streak) max_streak=streak
				} else {
					streak=0
				}
				ewma_3=cal.ewma(ans,0.333)
				ewma_10=cal.ewma(ans,0.1)
				log_num_done=log(min(ii, 20))
				log_num_missed=log((min(ii,20)-sum(oracle[ix]))+1)
				crct = sum(oracle[ix])/min(ii,20)
				z = coefs[1]+coefs[2]*ewma_3+coefs[3]*ewma_10+coefs[4]*max_streak+coefs[5]*log_num_done+coefs[6]*log_num_missed+coefs[7]*crct
				z = 1/(1+exp(-z))
				zs = c(zs, z)
			}
			tmp$pdct=zs
			
			dd = rbind(dd, tmp)
		}
	}
	return(dd)
}

get.pall.2 <- function(is, ie) {
	print(sprintf("%d,%d", is, ie))
	dd = NULL
	for(i in is:(ie-1)) {
		if(i%%50==0) print(i)
		pp = pr[(uix.pr[i]+1):uix.pr[i+1],]
		e = unique(pp$exercise)
		for(ee in e) {
			ppp = pp[pp$exercise==ee,]
			nn = nrow(ppp)
			tmp = ppp[,c("user_id","exercise","correct","time_done")]
			tmp = tmp[order(tmp$time_done),]
			tmp$problem_num=(1:nn)
			tmp$total_num=nn
			
			dd = rbind(dd, tmp)
		}
	}
	return(dd)
}


print("generates pall......")
#index for testing
#index = c(seq(from=1, to=200, by = 10), 210)
index = c(seq(from=1, to=length(uix.pr), by = 6000), length(uix.pr))

jobs = list()
j=0
d = NULL
for(i in 1:(length(index)-1)) {
#for(i in 1:length(ix)) {
	j=j+1
	jobs[[j]] = parallel(get.pall.2(index[i], index[i+1]))
	if(length(jobs)>=17) {
		print("start collecting results")
		ret = collect(jobs)
		for(i in 1:length(ret)) {
			d = rbind(d, ret[[i]])
		}
		print("end of collection")
		j=0
		jobs=list()
	}
}
if(length(jobs)) {
	print ("final collection")
	ret = collect(jobs)
	for(i in 1:length(ret)) {
		d = rbind(d, ret[[i]])
	}
	jobs=list()
}

pall = d
print("generates index by user_id")
pall = pall[order(pall$user_id),]
uix = c(0, which(sapply(1:(nrow(pall)-1), function(i) pall$user_id[i]!=pall$user_id[i+1])), nrow(pall))
save(pall, uix, file="junyi_pall_u.RData")
