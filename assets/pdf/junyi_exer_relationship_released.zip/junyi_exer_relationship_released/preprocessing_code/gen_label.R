library(multicore)
require(tools)
options(stringsAsFactors = F)
options(digit.secs=6)

# number of parallel threads
# decided based on the capability of the machine executing the process
num_thrd = 17

get.lb1 <- function(is, ie) {
	print(sprintf("%d,%d", is, ie))
	dd = NULL
	for(i in is:(ie-1)) {
		if(i%%200==0) print(i)
		pp = pr[(uix.pr[i]+1):uix.pr[i+1],]
		u = which(uids==unique(pp$user_id))
		es = intersect(ee, unique(pp$exercise[pp$time_taken>0]))
		if(length(es)==0) next
		dd = rbind(dd, do.call(rbind, lapply(es, function(e) {
										td.min=min(pp$time_done[pp$time_taken>0&pp$exercise==e])
										pp2 = pp[pp$time_taken>0&pp$exercise==e&difftime(pp$time_done, td.min, unit="hour")<=1,]
										num = nrow(pp2)
										if(sum(pp2$correct)==0) tt1 = NA
										else tt1 = pp2$time_taken[which(pp2$time_done==min(pp2$time_done[pp2$correct]))[1]]
										is_crct.first = pp2$correct[which(pp2$time_done==min(pp2$time_done))[1]]
										return(data.frame(uid = u, exer = which(ee==e), num = num, crct = sum(pp2$correct)/num, tt.avg = sum(pp2$time_taken)/num,tt.avg.crct=sum(pp2$time_taken[pp2$correct])/sum(pp2$correct),t.crct1=tt1, is_crct.first=is_crct.first))
									})))
	}
	return(dd)
}

index = c(seq(from=1, to=length(uix.pr), by = 6000), length(uix.pr))
jobs = list()
d = NULL
for(i in 1:(length(index)-1)) {
#for(i in sample(1:(length(index)-1), 10)) {
	jobs[[length(jobs)+1]] = parallel(get.lb1(index[i], index[i+1]))
	if(length(jobs)>=num_thrd) {
		print("start collecting results")
		ret = collect(jobs)
		for(i in 1:length(ret)) {
			d = rbind(d, ret[[i]])
		}
		print("end of collection")
		jobs=list()
	}
}
if(length(jobs)) {
	print("final collection")
	ret = collect(jobs)
	for(i in 1:length(ret)) {
		d = rbind(d, ret[[i]])
	}
	jobs=list()
}
write.csv(d, file="results/ken_label.csv")
