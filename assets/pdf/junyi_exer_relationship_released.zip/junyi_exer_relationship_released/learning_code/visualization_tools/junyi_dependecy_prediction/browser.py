import os
import csv
import cgi
import webapp2
import web_const
import math

def print_links(file_path,self):
    with open(file_path,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        row=spamreader.next()
        for row in spamreader:
            if row[7].strip() == 'False' or row[7].strip() == 'FALSE' :
                continue
            parstr=row[9].replace('[','')
            parstr=parstr.replace(']','')
            if len(parstr) == 0:
                continue
            tok=[ x.strip() for x in parstr.split(',')]
            for par in tok:
                out="{ data: { source: '" + par + "', target: '" + row[8] + "' } },"
                self.response.out.write(out+"\n")

def load_exer_list(path):
    with open(path,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        d=[]
        for row in spamreader:
            d.append(row[1])
        return sorted(d)

def load_exer_order2name(exer_list_path):
    f_exer_list=open(exer_list_path,"r")
    reader = csv.reader(f_exer_list, delimiter=',')
    d_exer_eff_list={}
    i=0
    for row in reader:
        d_exer_eff_list[i]=row[1].strip()
        i=i+1
    return d_exer_eff_list
    
def load_exer_id2name(exer_list_path):
    f_exer_list=open(exer_list_path,"r")
    reader = csv.reader(f_exer_list, delimiter=',')
    row=reader.next()
    d_exer_list={}
    for row in reader:
        d_exer_list[int(row[0])-1]=row[1]
    return d_exer_list

##def load_score(score_path,select_exer):
##    score_csvfile=open(score_path,'rb')
##    reader = csv.reader(score_csvfile, delimiter=',')
##    row=reader.next()
##    d_score_norm={}
##    other_statistics=[0]*9
##    for row in reader:
##        d_score_norm[row[1].strip()]=float(row[3])
##        if row[1].strip() == select_exer:
##            other_statistics[0:9]=row[2:11] #sample number, base error, simple sparsity, complex sparsity, abolute error, improve value        
##    return d_score_norm,other_statistics

def load_score(score_path,select_exer):
    score_csvfile=open(score_path,'rb')
    reader = csv.reader(score_csvfile, delimiter=',')
    row=reader.next()
    d_score_norm={}
    other_statistics=[0]*7
    for row in reader:
        d_score_norm[row[1].strip()]=float(row[3])
        if row[1].strip() == select_exer:
            other_statistics[0:8]=row[2:10] #RF_score, RF_score_norm, correct sample number, base error, simple sparsity, complex sparsity, abolute error, mean accuracy
    return d_score_norm,other_statistics

def load_fw_file(fw_path, sel_exer,start_dim,end_dim):
    with open(fw_path,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        fw=[]
        for row in spamreader:
            if row[1].strip() != sel_exer:
                continue
            fw=row[start_dim:end_dim]
            break
        return fw

def load_fw(weight_path, sel_exer,d_exer_list,start_ind,end_ind):
    weight=load_fw_file(weight_path, sel_exer,start_ind,end_ind)
    if len(weight)==0:
        return []
    weight=[float(x) for x in weight]
    d_weight={}
    for i in d_exer_list:
        d_weight[d_exer_list[i]]=weight[i]
    return d_weight

def load_score_norm(score_path, sel_exer,d_exer_list,gt_score,middle_score):
    score=load_fw_file(score_path, sel_exer,2,-1)
    score=[float(x) for x in score]
    max_score=max(score)
    min_score=min(score)
    if middle_score==-1:
        score_norm=[ (x-min_score)/(max_score-min_score) for x in score]
        gt_score_norm={}
        for ex in gt_score:
            gt_score_norm[ex]=(gt_score[ex]-min_score)/(max_score-min_score)
    else:
        score_norm=[ 0.5*( 1 + (x-middle_score)/(max_score-middle_score)) if x>middle_score else 0.5*(x-min_score)/(middle_score-min_score)  for x in score]
        gt_score_norm={}
        for ex in gt_score:
            x=gt_score[ex]
            if x>middle_score:
                gt_score_norm[ex]=0.5*( 1 + (x-middle_score)/(max_score-middle_score))
            else:
                gt_score_norm[ex]=0.5*(x-min_score)/(middle_score-min_score)
            if(gt_score_norm[ex]<0):
                gt_score_norm[ex]=0
    d_score_norm={}
    for i in d_exer_list:
        d_score_norm[d_exer_list[i]]=score_norm[i]
    return d_score_norm, gt_score_norm, max_score-min_score

def load_gt(gt_path,sel_exer):
    with open(gt_path,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        gt_rel_score={}
        gt_diff_score={}
        gt_pre_score={}
        gt_raw={}
        for row in spamreader:
            if sel_exer != row[0]:
                continue
            gt_rel_score[row[1]]=float(row[2])
            gt_diff_score[row[1]]=float(row[4])
            gt_pre_score[row[1]]=float(row[6])
            gt_raw[row[1]]=[row[3],row[5],row[7]]
            
        
    return gt_rel_score, gt_diff_score, gt_pre_score, gt_raw

def color_string_saturate(value):
    if(value>255):
        return "ff"
    elif(value<0):
        return "00"
    else:
        return "%02x" % value

def decide_color(bright_score,back_score,border_score):
    scale=bright_score*128+127
    red=color_string_saturate(scale*back_score)
    green=color_string_saturate(scale*(1-back_score))
    blue=color_string_saturate(scale*(1-back_score))
    back_color=red+green+blue

    if border_score>0.5:
        red=color_string_saturate(scale*(border_score-0.5)*2)
        green=color_string_saturate(scale*(1-border_score)*2)
        blue="%02x" % 0
    else:
        red="%02x" % 0
        green=color_string_saturate(scale*border_score*2)
        blue=color_string_saturate(scale*(0.5-border_score)*2)
    border_color=red+green+blue
    return back_color, border_color

def print_node_on_network(path, d_score_norm, d_pre_score_norm, d_relate_score_norm, d_diff_score_norm, d_sample_num, gt_rel_score_norm, gt_diff_score_norm, gt_pre_score_norm, gt_raw, sel_exer, self):
    with open(path,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        row=spamreader.next()
        for row in spamreader:
            if row[7].strip() == 'False' or row[7].strip() == 'FALSE':
                continue

            if row[8] not in d_pre_score_norm:
                out="{ data: { id: '" + row[8] + "', name: '" + row[13] + "' , text_in_c: '#FFFFFF' "
                self.response.out.write(out + '} },\n')
                continue

            weight_distri= ", rel: '" + str(d_relate_score_norm[row[8]]) + "', diff: '" + str(d_diff_score_norm[row[8]]) + "', pre: '" +  str(d_pre_score_norm[row[8]]) + "', sn: '" +  str(d_sample_num[row[8]]) + "'"
            if row[8] in gt_rel_score_norm:
                weight_distri=weight_distri + ", rel_gt: '" + str(gt_rel_score_norm[row[8]]) + "', diff_gt: '" +str(gt_diff_score_norm[row[8]]) + "', pre_gt: '" + str(gt_pre_score_norm[row[8]]) + "', rel_gt_raw: ' " + str(gt_raw[row[8]][0]) + "', diff_gt_raw: ' " + str(gt_raw[row[8]][1]) + "', pre_gt_raw: ' " + str(gt_raw[row[8]][2]) + "'"

            bright_score=d_pre_score_norm[row[8]]
            back_score=d_relate_score_norm[row[8]]
            border_score=d_diff_score_norm[row[8]]

            back_color, border_color=decide_color(bright_score,back_score,border_score)
            
            if row[8] == sel_exer:    
                out="{ data: { id: '" + row[8] + "', name: '" + row[13] + "', color: '#FFFFFF', border_c: '#FF0000', text_c: '#" + border_color + "', text_in_c: '#" + back_color + "' " + weight_distri
            else:
                if row[8] not in gt_rel_score_norm:
                    out="{ data: { id: '" + row[8] + "', name: '" + row[13] + "', color: '#" + back_color + "', border_c: '#" + border_color + "', text_in_c: '#FFFFFF'" + weight_distri
                else:
                    bright_score=gt_pre_score_norm[row[8]]
                    print bright_score
                    back_score=gt_rel_score_norm[row[8]]
                    print back_score
                    border_score=gt_diff_score_norm[row[8]]
                    print border_score

                    gt_back_color, gt_border_color=decide_color(bright_score,back_score,border_score)
                    
                    out="{ data: { id: '" + row[8] + "', name: '" + row[10] + "', color: '#" + back_color + "', border_c: '#" + border_color + "', text_in_c: '#" + gt_back_color + "', text_c: '#" + gt_border_color + "'" + weight_distri
            self.response.out.write(out + '} },\n')
        self.response.out.write('\n')
sel_exer=""

class MainHandler(webapp2.RequestHandler):
    def get(self):
        self.response.out.write(web_const.WEB_BEGIN_CONST)
        
        pre_path = os.path.join(os.path.split(__file__)[0], '.\\data\\regression_prerequisite_results.csv')
        d=load_exer_list(pre_path)
        global sel_exer
        if not sel_exer:
            sel_exer=d[0].strip()

        self.response.out.write('<form action="./draw" method="post" style="float:right;"> \n<select style="width:100px" name="select_exer" id="select_exer"> \n')
        for usr in d:
            usr_no_space=usr.strip()
            if usr_no_space != sel_exer:
                self.response.out.write('<option value="' + usr_no_space + '">' + usr_no_space + '</option> \n')
            else:
                self.response.out.write('<option value="' + usr_no_space + '" selected="selected">' + usr_no_space + '</option> \n')
        self.response.out.write('</select> \n<p><input type="submit" /></p> \n')
        self.response.out.write('</form> \n')
        
        score_path = os.path.join(os.path.split(__file__)[0], 'data\\rf_score_data.csv')
        d_score_norm,other_statistics = load_score(score_path,sel_exer)
        total_sample_num=other_statistics[2]
##        self.response.out.write("<p align='right'> total sample number: " + total_sample_num + "</p>\n")
        self.response.out.write("<p align='right'> correct sample number: " + other_statistics[2] + "</p>\n")
        self.response.out.write("<p align='right'> score: " + other_statistics[0]  + "</p>\n")
        self.response.out.write("<p align='right'> mean accuracy: " + other_statistics[7]  + "</p>\n")
        self.response.out.write("<p align='right'> base error: " + other_statistics[3] + "</p>\n")
        self.response.out.write("<p align='right'> abolute error: " + other_statistics[6] + "</p>\n")
        self.response.out.write("<p align='right'> simple sparsity: " + other_statistics[4] + "</p>\n")
        self.response.out.write("<p align='right'> complex sparsity: " + other_statistics[5] + "</p>\n")
##        self.response.out.write("<p align='right'> score: " + other_statistics[0]  + "</p>\n")
##        self.response.out.write("<p align='right'> mean accuracy: " + other_statistics[8]  + "</p>\n")
##        self.response.out.write("<p align='right'> base error: " + other_statistics[3] + "</p>\n")
##        self.response.out.write("<p align='right'> abolute error: " + other_statistics[6] + "</p>\n")
##        self.response.out.write("<p align='right'> improve value: " + other_statistics[7] + "</p>\n")
##        self.response.out.write("<p align='right'> simple sparsity: " + other_statistics[4] + "</p>\n")
##        self.response.out.write("<p align='right'> complex sparsity: " + other_statistics[5] + "</p>\n")

        sample_num_path = os.path.join(os.path.split(__file__)[0], 'data\\classifier_results_f_samples_first_correct.csv')
        d_exer_eff_list=load_exer_order2name(sample_num_path)

        gt_path = os.path.join(os.path.split(__file__)[0], 'data\\collected_gt_all.csv')
        gt_rel_score, gt_diff_score, gt_pre_score, gt_raw=load_gt(gt_path,sel_exer)
        
        d_pre_score_norm,gt_pre_score_norm,score_range = load_score_norm(pre_path,sel_exer,d_exer_eff_list,gt_pre_score,-1)
        self.response.out.write("<p align='right'> score range: " + str(score_range) + "</p>\n")
        
        self.response.out.write(web_const.WEB_MIDDLE_1_CONST)
        self.response.out.write("'height': " + str(15+15*(1-math.exp(-score_range/(9-1)/0.2))) + ", \n")
	self.response.out.write("'width': " + str(15+15*(1-math.exp(-score_range/(9-1)/0.2))) + ", \n")
        self.response.out.write(web_const.WEB_MIDDLE_2_CONST)

        relation_path = os.path.join(os.path.split(__file__)[0], 'data\\regression_similarity_results.csv')
        d_relate_score_norm,gt_rel_score_norm,score_range = load_score_norm(relation_path,sel_exer,d_exer_eff_list,gt_rel_score,-1)

        difficulty_path = os.path.join(os.path.split(__file__)[0], 'data\\regression_difficulty_results.csv')
        d_diff_score_norm,gt_diff_score_norm,score_range = load_score_norm(difficulty_path,sel_exer,d_exer_eff_list,gt_diff_score,5)

    
        exer_list_path = os.path.join(os.path.split(__file__)[0], 'data\\pretest_exer_list.csv')
        d_exer_list=load_exer_id2name(exer_list_path)
        d_sample_num = load_fw(sample_num_path,sel_exer,d_exer_list,3,-1)

        
        exer_all_path = os.path.join(os.path.split(__file__)[0], 'data\\junyi_Exercise.csv')
        print_node_on_network(exer_all_path, d_score_norm, d_pre_score_norm, d_relate_score_norm, d_diff_score_norm, d_sample_num, gt_rel_score_norm, gt_diff_score_norm, gt_pre_score_norm, gt_raw, sel_exer, self)
        
	self.response.out.write("], \n edges: [\n")

        print_links(exer_all_path,self)
		
        self.response.out.write(web_const.WEB_END_CONST)


class DrawHandler(webapp2.RequestHandler):
    def post(self):
        global sel_exer
        sel_exer=self.request.get_all('select_exer')
        sel_exer=str(sel_exer)[3:-2]
        self.redirect('/')

application = webapp2.WSGIApplication([
    ('/', MainHandler),
    ('/draw', DrawHandler)
], debug=True)

