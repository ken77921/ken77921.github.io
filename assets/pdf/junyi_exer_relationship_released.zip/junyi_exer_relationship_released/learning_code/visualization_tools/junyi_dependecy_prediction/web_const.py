WEB_BEGIN_CONST='''
<!DOCTYPE html>
<html>
<head>
		<link href="/javascript/cytoscape.js-panzoom.css" rel="stylesheet" type="text/css" />
		<link href="/javascript/font-awesome-4.0.3/css/font-awesome.css" rel="stylesheet" type="text/css" />
<meta name="description" content="[An example of getting started with Cytoscape.js]" />
<script type="text/javascript" src="/javascript/jquery.min.js"></script>
<script type="text/javascript" src="/javascript/cytoscape.min.js"></script>
<meta charset=utf-8 />
<!--
Created using JS Bin
http://jsbin.com

Copyright (c) 2014 by maxkfranz (http://jsbin.com/urabis/16/edit)

Released under the MIT license: http://jsbin.mit-license.org
-->
<title>Cytoscape.js initialisation</title>
<script type="text/javascript" src="/javascript/cytoscape.js-panzoom.js"></script>
<style id="jsbin-css">
body { 
  font: 12px helvetica neue, helvetica, arial, sans-serif;
}

#cy {
  height: 100%;
  width: 80%;
  position: absolute;
  left: 0;
  top: 0;
}



</style>
</head>
<body> 
  <div id="cy"></div>
  <p align="center">Tap a node to highlight its neighbourhood and select the exercise in the option bar</p>
  '''

WEB_MIDDLE_1_CONST='''

  <label id="rel" style="float:right;"></label>
  <label style="float:right;">similarity: </label>
  <br>
  <label id="diff" style="float:right;"></label>
  <label style="float:right;">difficulty: </label>
  <br>
  <label id="pre" style="float:right;"></label>
  <label style="float:right;">prerequisite: </label>
  <br>
  <label id="rel_gt" style="float:right;"></label>
  <label style="float:right;">similarity (gt): </label>
  <br>
  <label id="diff_gt" style="float:right;"></label>
  <label style="float:right;">difficulty (gt): </label>
  <br>
  <label id="pre_gt" style="float:right;"></label>
  <label style="float:right;">prerequisite (gt): </label>
  <br>
   <label id="rel_gt_raw" style="float:right;"></label>
  <label style="float:right;">similarity (gt_raw): </label>
  <br>
  <label id="diff_gt_raw" style="float:right;"></label>
  <label style="float:right;">difficulty (gt_raw): </label>
  <br>
  <label id="pre_gt_raw" style="float:right;"></label>
  <label style="float:right;">prerequisite (gt_raw): </label>
  <br>
  <label id="sample_num" style="float:right;"></label>
  <label style="float:right;">correct sample number before: </label>
  <br>


<script type="text/javascript">
document.getElementById("cy").style.width=($( document ).width() - 120).toString() + "px";
$(function(){ // on dom ready
var cy = cytoscape({
boxSelectionEnabled: false,
panningEnabled: true,
userPanningEnabled: true,
//panningEnabled: false,
//userPanningEnabled: false,
container: document.getElementById('cy'),
  style: cytoscape.stylesheet()
    .selector('node')
      .css({
	  '''
WEB_MIDDLE_2_CONST='''	  
        'content': 'data(name)',
		'font-size': 8,
        //'text-valign': 'center',
		'background-color': 'data(color)',
		//'min-zoomed-font-size': 5,
		'border-width': 5,
		'border-color': 'data(border_c)',
        //'color': 'white',
		'color': 'data(text_in_c)',
		'text-outline-width': 2,
        'text-outline-color': 'data(text_c)'
      })
    .selector('edge')
      .css({
        'target-arrow-shape': 'triangle',
		'width': 'data(w)',
		'color': 'data(c)',
		//'control-point-distance': 100
		//'control-point-step-size': 1
		//'control-point-weight' : '0.5'
      })
    .selector(':selected')
      .css({
        'background-color': 'black',
        'line-color': 'black',
        'target-arrow-color': 'black',
        'source-arrow-color': 'black'
      })
    .selector('.faded')
      .css({
        'opacity': 0.5,
        'text-opacity': 0
      }),
  
  elements: {
    nodes: [
'''

WEB_END_CONST='''

    ]
  },

  layout: {
    name: 'breadthfirst',

    fit: true, // whether to fit the viewport to the graph
    ready: undefined, // callback on layoutready
    stop: undefined, // callback on layoutstop
    directed: true, // whether the tree is directed downwards (or edges can point in any direction if false)
    padding: 30, // padding on fit
    circle: false, // put depths in concentric circles if true, put depths top down if false
    roots: undefined, // the roots of the trees
    maximalAdjustments: 0 // how many times to try to position the nodes in a maximal way (i.e. no backtracking)
  },
	  
  ready: function(){
    window.cy = this;
    
    // giddy up...
    
    cy.elements().unselectify();
    
    cy.on('tap', 'node', function(e){
      var node = e.cyTarget; 
	  document.getElementById("select_exer").value=node.id();
	  //document.getElementById('raw').innerHTML='test';
	  document.getElementById('rel').innerHTML=node.data('rel');
	  document.getElementById('diff').innerHTML=node.data('diff');
	  document.getElementById('pre').innerHTML=node.data('pre');
	  document.getElementById('rel_gt').innerHTML=node.data('rel_gt');
	  document.getElementById('diff_gt').innerHTML=node.data('diff_gt');
	  document.getElementById('pre_gt').innerHTML=node.data('pre_gt');
	  document.getElementById('rel_gt_raw').innerHTML=node.data('rel_gt_raw');
	  document.getElementById('diff_gt_raw').innerHTML=node.data('diff_gt_raw');
	  document.getElementById('pre_gt_raw').innerHTML=node.data('pre_gt_raw');
	  document.getElementById('sample_num').innerHTML=node.data('sn');
      var neighborhood = node.neighborhood().add(node);
      
      cy.elements().addClass('faded');
      neighborhood.removeClass('faded');
    });
    
    cy.on('tap', function(e){
      if( e.cyTarget === cy ){
        cy.elements().removeClass('faded');
      }
    });
  }
});

cy.panzoom({
	// options go here
});

}); // on dom ready
</script>
</body>
</html>
'''