import os
import csv
import cgi
import webapp2
import web_const
import math
from google.appengine.ext import ndb

##browser_key = ndb.Key('browser', 'default_browser')

##class cross_DS(ndb.Model):
##  student = ndb.TextProperty()
##  date = ndb.DateTimeProperty(auto_now_add=True)

def print_links(file_path,self):
    with open(file_path,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        row=spamreader.next()
        for row in spamreader:
            if row[7].strip() == 'False' or row[7].strip() == 'FALSE' :
                continue
            parstr=row[9].replace('[','')
            parstr=parstr.replace(']','')
            if len(parstr) == 0:
                continue
            tok=[ x.strip() for x in parstr.split(',')]
            for par in tok:
                out="{ data: { source: '" + par + "', target: '" + row[8] + "' } },"
                self.response.out.write(out+"\n")

def load_name_list(path):
    with open(path,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        d=[]
        for row in spamreader:
            d.append(row[0])
        return sorted(d)

def load_prob_accuracy(path, target_usr):
    with open(path,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        d_correct={}
        d_false={}
        d_time={}
        for row in spamreader:
            if row[0].strip() != target_usr:
                continue
            max_num=0
            for i in range(1, len(row)):
                if i%4 == 1:
                    exercise=row[i].strip()
                elif i%4 == 2:
                    d_correct[exercise]=int(row[i])
                elif i%4 == 3:
                    d_false[exercise]=int(row[i])
                    ans_num=d_correct[exercise]+int(row[i])
                    if max_num < ans_num:
                        max_num = ans_num
                else:
                    d_time[exercise]=float(row[i])
            break
        return d_correct, d_false, d_time, max_num

def print_node_on_network(path, d_correct, d_false, d_time, max_num, self):
    with open(path,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        row=spamreader.next()
        for row in spamreader:
            if row[7].strip() == 'False' or row[7].strip() == 'FALSE':
                continue
            if row[8].strip() not in d_correct:
                out="{ data: { id: '" + row[8] + "', name: '" + row[13] + "' "
            else:
                correct=d_correct[row[8]]
                false=d_false[row[8]]
                total=correct+false
                red="%02x" % ((( 255-127*math.exp(-float(total)/max_num*10))*false)/total)
                green="%02x" % 0
                blue="%02x" % (((255-127*math.exp(-float(total)/max_num*10))*correct)/total)
                out="{ data: { id: '" + row[8] + "', name: '" + row[10] + "', color: '#" + red + green + blue + "' "
                if d_time[row[8]] != -1:
                    red="%02x" % int((1-d_time[row[8]]) * 255)
                    green="%02x" % int(d_time[row[8]] * 255)
                    blue="%02x" % int((1-d_time[row[8]]) * 255)
                    out=out + ", time: '#" + red + green + blue + "'" 
            self.response.out.write(out + '} },\n')
        self.response.out.write('\n')
sel_usr=""

class MainHandler(webapp2.RequestHandler):
    def get(self):
        self.response.out.write(web_const.WEB_BEGIN_CONST)
        path = os.path.join(os.path.split(__file__)[0], '.\\data\\usr_prob_correct_1.txt')
        d=load_name_list(path)
##        query_results = ndb.gql('SELECT * '
##                'FROM cross_DS '
##                'ORDER BY date DESC LIMIT 10',
##                browser_key)
##        sel_usr=d[0].strip()
##        for x in query_results:
##            sel_usr=x.student
        global sel_usr
        if not sel_usr:
            sel_usr=d[0].strip()
        self.response.out.write('<form action="./draw" method="post" style="float:right;"> \n<select style="width:100px" name="select_user"> \n')
        for usr in d:
            usr_no_space=usr.strip()
            if usr_no_space != sel_usr:
                self.response.out.write('<option value="' + usr_no_space + '">' + usr_no_space + '</option> \n')
            else:
                self.response.out.write('<option value="' + usr_no_space + '" selected="selected">' + usr_no_space + '</option> \n')
        self.response.out.write('</select> \n<p><input type="submit" /></p> \n')
        self.response.out.write('</form> \n')
        
        self.response.out.write(web_const.WEB_MIDDLE_CONST)       
        d_correct, d_false, d_time, max_num = load_prob_accuracy(path,sel_usr)
        path = os.path.join(os.path.split(__file__)[0], 'data\\junyi_Exercise.csv')
        print_node_on_network(path,d_correct, d_false, d_time, max_num, self)

        self.response.out.write("], \n edges: [\n")

        print_links(path,self)
        self.response.out.write(web_const.WEB_END_CONST)


class DrawHandler(webapp2.RequestHandler):
    def post(self):
        global sel_usr
        sel_usr=self.request.get_all('select_user')
        sel_usr=str(sel_usr)[3:-2]
        self.redirect('/')
##        sel_usr=cgi.escape(self.request.get_all('select_user'))
##        sel_usr=str(sel_usr).translate(None,"[]'")[1:]
##        browser = cross_DS(parent=browser_key)
##        browser.student = sel_usr
##        browser.put()

application = webapp2.WSGIApplication([
    ('/', MainHandler),
    ('/draw', DrawHandler)
], debug=True)

