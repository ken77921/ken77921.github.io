WEB_BEGIN_CONST='''
<!DOCTYPE html>
<html>
<head>
		<link href="/javascript/cytoscape.js-panzoom.css" rel="stylesheet" type="text/css" />
		<link href="/javascript/font-awesome-4.0.3/css/font-awesome.css" rel="stylesheet" type="text/css" />
<meta name="description" content="[An example of getting started with Cytoscape.js]" />
<script type="text/javascript" src="/javascript/jquery.min.js"></script>
<script type="text/javascript" src="/javascript/cytoscape.min.js"></script>
<meta charset=utf-8 />
<!--
Created using JS Bin
http://jsbin.com

Copyright (c) 2014 by maxkfranz (http://jsbin.com/urabis/16/edit)

Released under the MIT license: http://jsbin.mit-license.org
-->
<title>Cytoscape.js initialisation</title>
<script type="text/javascript" src="/javascript/cytoscape.js-panzoom.js"></script>
<style id="jsbin-css">
body { 
  font: 12px helvetica neue, helvetica, arial, sans-serif;
}

#cy {
  height: 100%;
  width: 80%;
  position: absolute;
  left: 0;
  top: 0;
}



</style>
</head>
<body> 
  <div id="cy"></div>
  <p align="center">Tap a node to highlight its neighbourhood</p>
  '''

WEB_MIDDLE_CONST='''
<script type="text/javascript">
document.getElementById("cy").style.width=($( document ).width() - 120).toString() + "px";
$(function(){ // on dom ready
var cy = cytoscape({
boxSelectionEnabled: false,
panningEnabled: true,
userPanningEnabled: true,
//panningEnabled: false,
//userPanningEnabled: false,
container: document.getElementById('cy'),
  style: cytoscape.stylesheet()
    .selector('node')
      .css({
	  	'height': 20,
		'width': 20,
        'content': 'data(name)',
		'font-size': 8,
        //'text-valign': 'center',
		'background-color': 'data(color)',
		//'min-zoomed-font-size': 5,
		'border-width': 5,
		'border-color': 'data(time)',
        'color': 'white',
		'text-outline-width': 2,
        'text-outline-color': '#888'
      })
    .selector('edge')
      .css({
        'target-arrow-shape': 'triangle',
		'width': 'data(w)',
		'color': 'data(c)',
		//'control-point-distance': 100
		//'control-point-step-size': 1
		//'control-point-weight' : '0.5'
      })
    .selector(':selected')
      .css({
        'background-color': 'black',
        'line-color': 'black',
        'target-arrow-color': 'black',
        'source-arrow-color': 'black'
      })
    .selector('.faded')
      .css({
        'opacity': 0.5,
        'text-opacity': 0
      }),
  
  elements: {
    nodes: [
'''

WEB_END_CONST='''

    ]
  },

  layout: {
    name: 'breadthfirst',

    fit: true, // whether to fit the viewport to the graph
    ready: undefined, // callback on layoutready
    stop: undefined, // callback on layoutstop
    directed: true, // whether the tree is directed downwards (or edges can point in any direction if false)
    padding: 30, // padding on fit
    circle: false, // put depths in concentric circles if true, put depths top down if false
    roots: undefined, // the roots of the trees
    maximalAdjustments: 0 // how many times to try to position the nodes in a maximal way (i.e. no backtracking)
  },
	  
  ready: function(){
    window.cy = this;
    
    // giddy up...
    
    cy.elements().unselectify();
    
    cy.on('tap', 'node', function(e){
      var node = e.cyTarget; 
      var neighborhood = node.neighborhood().add(node);
      
      cy.elements().addClass('faded');
      neighborhood.removeClass('faded');
    });
    
    cy.on('tap', function(e){
      if( e.cyTarget === cy ){
        cy.elements().removeClass('faded');
      }
    });
  }
});

cy.panzoom({
	// options go here
});

}); // on dom ready
</script>
</body>
</html>
'''