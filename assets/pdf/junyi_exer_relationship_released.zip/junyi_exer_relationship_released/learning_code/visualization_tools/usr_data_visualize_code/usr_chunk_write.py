import csv
import operator
import sys
from collections import defaultdict
import os
f=[]

input_dir='..\\..\\input'
output_dir='..\\..\\intermediate\\user_chunks_full_records'

if not os.path.exists(output_dir):
    os.makedirs(output_dir)

for i in range(100):
    f.append( open(output_dir+'\\'+ str(i)+'.txt','w') )

file_num=100
with open(input_dir+'\\proc_ProblemLog.csv','rb') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=',')
    seq=[]
##    for x in range(1000):
##        row=spamreader.next()
##        print(row)
    for row in spamreader:
        sys.stdout.write('.')
        ind=sum(ord(x) for x in row[1])%file_num
        f[ind].write( ", ".join(row) + '\n')

for i in range(100):
    f[i].close()
