import csv
import operator
import sys
import os
from datetime import datetime
from collections import defaultdict

input_dir='..\\..\\intermediate\\user_chunks_full_records'
output_dir='..\\..\\intermediate\\user_chunks'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

f_usr_prob = open(output_dir+'\\usr_prob_correct_1.txt','w')
with open(input_dir+'\\1.txt','rb') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=',')
    d_correct={}
    d_false={}
    d_time={}
##    row=spamreader.next()
##    for x in range(100):
##        row=spamreader.next()
##        print(row)
    for row in spamreader:
        sys.stdout.write('.')
 
        if row[1] not in d_correct:
            d_correct[row[1]]=defaultdict(int)
            d_false[row[1]]=defaultdict(int)
            d_time[row[1]]={}
            
        if row[2] not in d_correct[row[1]]:
            d_correct[row[1]][row[2]]=0
            d_false[row[1]][row[2]]=0
			
        if row[4].strip() == 'TRUE':
            d_correct[row[1]][row[2]] += 1
            time_str=row[11].strip()
            if len(time_str)>20:
                date_object = datetime.strptime(time_str, '%Y-%m-%d %H:%M:%S.%f')
            else:
                date_object = datetime.strptime(time_str, '%Y-%m-%d %H:%M:%S')
            if row[2] not in d_time[row[1]]:
                d_time[row[1]][row[2]]=date_object
            else:
                if d_time[row[1]][row[2]]>date_object:
                    d_time[row[1]][row[2]]=date_object
        else:
            d_false[row[1]][row[2]] += 1

    for x in d_time:
        sorted_x = sorted(d_time[x].iteritems(), key=operator.itemgetter(1))
        i=1
        for y in sorted_x:
            d_time[x][y[0]]=float(i)/len(sorted_x)
            i=i+1
        
    for x in d_correct:
        f_usr_prob.write(x + ", ")
        for y in d_correct[x]:
            num_correct=d_correct[x][y]
            num_false=d_false[x][y]
            if y in d_time[x]:
                ratio_time=d_time[x][y]
                f_usr_prob.write(y + ", " + str(num_correct) + ", " + str(num_false) + ", " + str(ratio_time) + ", ")
            else:
                f_usr_prob.write(y + ", " + str(num_correct) + ", " + str(num_false) + ", -1,")
##            f_usr_prob.write(y + ", " + str(float(num_correct)/(num_correct+num_false)) + ", " + str(num_correct+num_false) + ", ")
        f_usr_prob.write("\n")

        
    
##    print sorted_d_usr
##    for x in sorted_d_usr:
##        print x[0] + ', ' + str(x[1])
##    print d_usr
##    for x in d_usr:
##        print x + ', ' + str(d_usr[x])
    

f_usr_prob.close()

