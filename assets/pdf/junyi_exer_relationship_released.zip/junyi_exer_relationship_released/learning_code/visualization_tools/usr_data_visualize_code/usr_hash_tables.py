import csv
import operator
import sys
import os
from collections import defaultdict

input_dir='..\\..\\input'
output_dir='..\\..\\intermediate\\usr_analysis'

if not os.path.exists(output_dir):
    os.makedirs(output_dir)

f_usr = open(output_dir+'\\out_usr.txt','w')
f_prob = open(output_dir+'\\out_prob.txt','w')
with open(input_dir+'\\proc_ProblemLog.csv','rb') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=',')
    d_usr=defaultdict(int)
    d_prob=defaultdict(int)
    i=0
    row=spamreader.next()
    print(row)
##    for x in range(100):
##        row=spamreader.next()
    for row in spamreader:
##        print(row)
        i=i+1
##        sys.stdout.write('.')
        d_usr[row[1]] += 1
        d_prob[row[2]] += 1
    sorted_d_usr = sorted(d_usr.iteritems(), key=operator.itemgetter(1))
    sorted_d_prob = sorted(d_prob.iteritems(), key=operator.itemgetter(1))
    print len(d_usr)-1
    print i-1
    for x in sorted_d_usr:
        f_usr.write(x[0] + ', ' + str(x[1]) + '\n')
    f_usr.write(str(len(d_usr)-1) + '\n')
    for x in sorted_d_prob:
        f_prob.write(x[0] + ', ' + str(x[1]) + '\n')
    f_prob.write(str(i-1) + '\n')
f_usr.close()
f_prob.close()

f_hash_org = open(output_dir+'\\hashing_table_org.txt','w')
f_hash_usr = open(output_dir+'\\hashing_table_usr.txt','w')
f_hash_file = open(output_dir+'\\hashing_table_file.txt','w')
file_num=100
with open(output_dir+'\\out_usr.txt','rb') as csvfile:
    spamreader = csv.reader(csvfile, delimiter=',')
    seq=[]
    d=defaultdict(int)
    file_bal=[0]*file_num
##    for x in range(100):
##        row=spamreader.next()
##        print(row)
    for row in spamreader:
        sys.stdout.write('.')
        ind=sum(ord(x) for x in row[0])%file_num
        d[row[0]]=ind
        file_bal[ind]+=1
        f_hash_org.write(row[0] + ', ' + str(ind) + '\n')

    f_hash_org.write( str(file_bal) )
    for x in sorted(d):
        f_hash_usr.write(x + ', ' + str(d[x]) + '\n')
    sorted_d = sorted(d.iteritems(), key=operator.itemgetter(1))

    for x in sorted_d:
        f_hash_file.write(x[0] + ', ' + str(x[1]) + '\n')

f_hash_org.close()
f_hash_usr.close()
f_hash_file.close()
