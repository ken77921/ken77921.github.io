import os
import csv
import cgi
import webapp2
import web_const
import math
import numpy as np

from print_node_on_network import print_node_on_network

##effective_exer_num=370

## difficulty scaling
middle_diff=5
max_diff=9
min_diff=1



def load_difficulty_graph(path_diff,effective_exer_num):
    with open(path_diff,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        graph_weight_diff=np.zeros((effective_exer_num,effective_exer_num))
        i=0
        for row in spamreader:
            graph_weight_diff[i,:]=[ 0.5*( 1 + (float(x)-middle_diff)/(max_diff-middle_diff)) if float(x)>middle_diff else 0.5*(float(x)-min_diff)/(middle_diff-min_diff)  for x in row[2:2+effective_exer_num]]
##            graph_weight_diff[i,:]=[(float(x)-middle_diff)/diff_scale for x in row[2:2+effective_exer_num]]
            i=i+1
    return graph_weight_diff

def load_graph(path_graph,effective_exer_num):
    with open(path_graph,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        d_name2order={}
        l_order2name=[0]*effective_exer_num
        graph_weight=np.zeros((effective_exer_num,effective_exer_num))
        i=0
        for row in spamreader:
            d_name2order[row[1]]=i
            l_order2name[i]=row[1]
            graph_weight[i,:]=[float(x) for x in row[2:2+effective_exer_num]]
            i=i+1
    return d_name2order, l_order2name, graph_weight

def load_name_list(path):
    with open(path,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        d=[]
        for row in spamreader:
            d.append(row[0])
        return sorted(d)

def load_sample_number(path,effective_exer_num):
    with open(path,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        d_sample_num={}
        l_sample_num=np.zeros((effective_exer_num,1))
        i=0
        for row in spamreader:
            d_sample_num[row[1]]=int(row[2])
            l_sample_num[i]=int(row[2])
            i=i+1
        return d_sample_num, l_sample_num

def load_prob_accuracy(path, target_usr):
    with open(path,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        d_correct={}
        d_false={}
        d_time={}
        for row in spamreader:
            if row[0].strip() != target_usr:
                continue
            max_num=0
            for i in range(1, len(row)):
                if i%4 == 1:
                    exercise=row[i].strip()
                elif i%4 == 2:
                    d_correct[exercise]=int(row[i])
                elif i%4 == 3:
                    d_false[exercise]=int(row[i])
                    ans_num=d_correct[exercise]+int(row[i])
                    if max_num < ans_num:
                        max_num = ans_num
                else:
                    d_time[exercise]=float(row[i])
            break
        return d_correct, d_false, d_time, max_num
    
def compute_accuracy_logistic(d_name2order, d_correct, d_false,effective_exer_num):
#     l_accuracy_c=np.zeros((1,effective_exer_num))
#     l_accuracy_e=np.zeros((1,effective_exer_num))
    l_c=np.zeros((effective_exer_num,1))
    l_e=np.zeros((effective_exer_num,1))
    for ex in d_name2order:
        if ex in d_correct:
#             l_accuracy_c[0,d_name2order[ex]]=1/(1+math.exp(d_false[ex]-d_correct[ex]))
            l_c[d_name2order[ex],0]=d_correct[ex]
        if ex in d_false:
#             l_accuracy_e[0,d_name2order[ex]]=1-(1/(1+math.exp(d_false[ex]-d_correct[ex])))
            l_e[d_name2order[ex],0]=d_false[ex]
#     return l_accuracy_c, l_accuracy_e, l_c, l_e
    return l_c, l_e

sel_usr=""

def file_len(fname):
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1

class MainHandler(webapp2.RequestHandler):
    def get(self):
        path_sample = os.path.join(os.path.split(__file__)[0], '.\\data\\classifier_results_f_samples_first_correct.csv')
        effective_exer_num=file_len(path_sample)
        
        self.response.out.write(web_const.WEB_BEGIN_CONST)
        path = os.path.join(os.path.split(__file__)[0], '.\\data\\usr_prob_correct_1.txt')
        d=load_name_list(path)
        global sel_usr
        if not sel_usr:
            sel_usr=d[0].strip()
        self.response.out.write('<form action="./draw" method="post" style="float:right;"> \n<select style="width:100px" name="select_user"> \n')
        for usr in d:
            usr_no_space=usr.strip()
            if usr_no_space != sel_usr:
                self.response.out.write('<option value="' + usr_no_space + '">' + usr_no_space + '</option> \n')
            else:
                self.response.out.write('<option value="' + usr_no_space + '" selected="selected">' + usr_no_space + '</option> \n')
        self.response.out.write('</select> \n<p><input type="submit" value="student modeling" /></p> \n')
        self.response.out.write('</form> \n')
        
        self.response.out.write(web_const.WEB_MIDDLE_CONST)
        path_graph = os.path.join(os.path.split(__file__)[0], '.\\data\\prerequisite_k5_graph.csv')
        d_name2order, l_order2name, graph_weight=load_graph(path_graph,effective_exer_num)

        path_diff = os.path.join(os.path.split(__file__)[0], '.\\data\\regression_difficulty_results.csv')
        graph_weight_diff=load_difficulty_graph(path_diff,effective_exer_num)
        
        d_correct, d_false, d_time, max_num = load_prob_accuracy(path,sel_usr)
#         l_accuracy_c, l_accuracy_e, l_c, l_e=compute_accuracy_logistic(d_name2order, d_correct, d_false)
        l_c, l_e=compute_accuracy_logistic(d_name2order, d_correct, d_false,effective_exer_num)
        

        d_sample_num, l_sample_num=load_sample_number(path_sample,effective_exer_num)
        
        path = os.path.join(os.path.split(__file__)[0], 'data\\junyi_Exercise.csv')

        print_node_on_network(path,d_correct, d_false, d_name2order, l_order2name, \
        l_c, l_e, graph_weight, graph_weight_diff, l_sample_num, d_time, max_num, self,effective_exer_num)
        
        self.response.out.write(web_const.WEB_END_CONST)


class DrawHandler(webapp2.RequestHandler):
    def post(self):
        global sel_usr
        sel_usr=self.request.get_all('select_user')
        sel_usr=str(sel_usr)[3:-2]
        self.redirect('/')

application = webapp2.WSGIApplication([
    ('/', MainHandler),
    ('/draw', DrawHandler)
], debug=True)

