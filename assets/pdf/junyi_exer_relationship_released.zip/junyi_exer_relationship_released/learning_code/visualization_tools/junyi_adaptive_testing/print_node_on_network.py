import csv
import numpy as np
import math
import random
import logging

##effective_exer_num=370

## weight ratio of difficulty w.r.t prerequisite
diff_w=1

## threshold of showing colors
predict_threshold=0.3

num_test_question=8

prior_extreme_prevent=0.05

prior_w=1

exploration_min_scale=0.1

prerequisite_w=3

# observed_confident_scale=1

## scales of showing colors
exer_scale=1
predict_scale=0.3

## prior parameters
prior_w=1

def compute_color(correct,false,scale):
    ce_diff=correct-false
    correct_rt=1/(1+math.exp(-ce_diff/scale))
    if ce_diff>0:
        red="%02x" % 0
        green="%02x" % (255*(1-correct_rt)*2)
        blue="%02x" % (255*(correct_rt-0.5)*2)
    else:
        red="%02x" % (255*(0.5-correct_rt)*2)
        green="%02x" % (255*(correct_rt)*2)
        blue="%02x" % 0

    return red+green+blue

def print_links(file_path,self):
    with open(file_path,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        row=spamreader.next()
        for row in spamreader:
            if row[7].strip() == 'False' or row[7].strip() == 'FALSE' :
                continue
            parstr=row[9].replace('[','')
            parstr=parstr.replace(']','')
            if len(parstr) == 0:
                continue
            tok=[ x.strip() for x in parstr.split(',')]
            for par in tok:
                out="{ data: { source: '" + par + "', target: '" + row[8] + "' } },"
                self.response.out.write(out+"\n")
	
def print_node_on_network(path, d_correct, d_false, d_name2order, l_order2name, \
                          l_c, l_e, graph_weight, graph_weight_diff, l_sample_num, d_time, max_num, self,effective_exer_num):
#                           l_accuracy_c, l_accuracy_e, l_c, l_e, graph_weight, graph_weight_diff, l_sample_num, d_time, max_num, self):
    with open(path,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        row=spamreader.next()
        
        graph_weight_T=np.transpose(graph_weight)
        graph_weight_diff_easy=1-graph_weight_diff*2
        graph_weight_diff_easy[graph_weight_diff>0.5]=0
        graph_weight_diff_easy[graph_weight_diff_easy>0]=graph_weight_diff_easy[graph_weight_diff_easy>0]+graph_weight_diff_easy[graph_weight_diff_easy>0].mean()
        
        graph_weight_diff_hard=graph_weight_diff*2-1
        graph_weight_diff_hard[graph_weight_diff<0.5]=0
        graph_weight_diff_hard[graph_weight_diff_hard>0]=graph_weight_diff_hard[graph_weight_diff_hard>0]+graph_weight_diff_hard[graph_weight_diff_hard>0].mean()
        
        graph_weight_diff_easy_T=graph_weight_diff_easy.T
        graph_weight_diff_hard_T=graph_weight_diff_hard.T
        
#         graph_total_c=graph_weight_diff_easy+graph_weight*prerequisite_w
#         graph_total_e=graph_weight_diff_hard+graph_weight_T*prerequisite_w
# #         graph_total_c=graph_weight_diff_easy+graph_weight+np.identity(effective_exer_num)
# #         graph_total_e=graph_weight_diff_hard+graph_weight_T+np.identity(effective_exer_num)
#         graph_total_c=graph_total_c.T
#         graph_total_e=graph_total_e.T

        l_sample_num_repeat_hard=np.repeat(l_sample_num, effective_exer_num, axis=1)
        l_sample_num_repeat_easy=np.copy(l_sample_num_repeat_hard)
        l_sample_num_repeat_easy[graph_weight_diff_easy_T==0]=0
        l_sample_num_repeat_hard[graph_weight_diff_hard_T==0]=0
        easy_usr_num=np.sum(l_sample_num_repeat_easy,axis=0)
        hard_usr_num=np.sum(l_sample_num_repeat_hard,axis=0)
#         P_C_prior=np.ones_like(easy_usr_num)*0.5
        P_C_prior=(hard_usr_num**prior_w)/(easy_usr_num**prior_w+hard_usr_num**prior_w)
        P_C_prior[P_C_prior>(1-prior_extreme_prevent)]=(1-prior_extreme_prevent)
        P_C_prior[P_C_prior<prior_extreme_prevent]=prior_extreme_prevent
        ce_prior=np.log(1/P_C_prior-1)
        c_prior=np.zeros_like(ce_prior)
        e_prior=np.zeros_like(ce_prior)
        c_prior[ce_prior<0]=-ce_prior[ce_prior<0]
        e_prior[ce_prior>0]=ce_prior[ce_prior>0]
        c_prior=c_prior.reshape((effective_exer_num,1))
        e_prior=e_prior.reshape((effective_exer_num,1))
#         P_C_prior=P_C_prior.reshape(( effective_exer_num,1))

        selected_node=np.zeros(num_test_question)
        answering_correctly=np.zeros(num_test_question)
        test_ans_c_num=0
        test_ans_e_num=0
#         selected_node=[0]*num_test_question
#         answering_correctly=[0]*num_test_question
        
        for i in range(num_test_question+1):
            l_accuracy=1/(1+np.exp(l_e-l_c))
            l_accuracy_c=np.copy(l_accuracy)
            l_accuracy_c[l_c==0]=0
            l_accuracy_e=np.copy(1-l_accuracy)
            l_accuracy_e[l_e==0]=0
            
            l_accuracy_difference_c=1/(1+np.exp(l_e-l_c-1))-l_accuracy_c
            l_accuracy_difference_e=1/(1+np.exp(l_e+1-l_c))-l_accuracy_e
            l_accuracy_difference_c[l_accuracy_difference_c<0]=0
            l_accuracy_difference_e[l_accuracy_difference_e<0]=0
            l_accuracy_difference_c=l_accuracy_difference_c.T
            l_accuracy_difference_e=l_accuracy_difference_e.T
            
            accuracy_spread_c_test=np.dot(graph_weight,l_accuracy_c )
            accuracy_spread_e_test=np.dot(graph_weight_T,l_accuracy_e )
            
            accuracy_diff_c_test=np.dot(graph_weight_diff_easy_T,l_accuracy_c )
            accuracy_diff_e_test=np.dot(graph_weight_diff_hard_T,l_accuracy_e )
            
            likelihood_num_c=l_c+accuracy_spread_c_test*prerequisite_w+accuracy_diff_c_test # maybe we do not need to add l_c
            likelihood_num_e=l_e+accuracy_spread_e_test*prerequisite_w+accuracy_diff_e_test
    
            total_c=likelihood_num_c+c_prior*prior_w # maybe we do not need to add l_c
            total_e=likelihood_num_e+e_prior*prior_w
            
#             accuracy_likelihood=1/(1+np.exp( (total_e-total_c)/observed_confident_scale ))
#             P_C=accuracy_likelihood.T
#             balance_weight_c=1/(1+math.exp(test_ans_e_num-test_ans_c_num))
#             balance_score=balance_weight_c*(1-P_C)+(1-balance_weight_c)*P_C
            balance_score=np.exp(-np.abs(likelihood_num_c-likelihood_num_e+(test_ans_c_num-test_ans_e_num)))
            balance_score=balance_score.T

#             accuracy_likelihood=accuracy_likelihood.T
#             P_C=(P_C_prior)*accuracy_likelihood/( (P_C_prior)*accuracy_likelihood+( (1-P_C_prior) )*(1-accuracy_likelihood))
            
#             exploration_value=np.max(total_c+total_e)-(total_c+total_e)
#             exploration_value=1/(exploration_min_scale+total_c+total_e)
            exploration_value=np.mean(total_c+total_e)-(total_c+total_e)
            exploration_value[exploration_value<0]=0
            
            
            
    ##        logging.debug("%s", str(exploration_value.shape))
    #         exploration_value_v=exploration_value.reshape((effective_exer_num,1))
#             exploration_value_ext=np.repeat(exploration_value,effective_exer_num, axis=1)
#             exploring_score=P_C*correct_score+(1-P_C)*false_score
            correct_diff_score=np.sum(exploration_value*graph_weight_diff_easy_T,axis=0)*l_accuracy_difference_c
            false_diff_score=np.sum(exploration_value*graph_weight_diff_hard_T,axis=0)*l_accuracy_difference_e
            diff_score=np.minimum(correct_diff_score,false_diff_score)
            
            correct_pre_score=np.sum(exploration_value*graph_weight,axis=0)*l_accuracy_difference_c
            false_pre_score=np.sum(exploration_value*graph_weight_T,axis=0)*l_accuracy_difference_e
            pre_score=np.minimum(correct_pre_score,false_pre_score)
            
            exploring_score=diff_score*pre_score*balance_score
            if (i==num_test_question):
                break
            selected_node[i]=np.argmax(exploring_score)
            
            answering_correctly[i]=random.randint(0, 1)
##            answering_correctly[i]=1
#             answering_correctly[i]=0
            print 'i='+str(i)
            print selected_node[i]
            print exploring_score[0,selected_node[i]]
            if answering_correctly[i]==1:
                l_c[selected_node[i]]=l_c[selected_node[i]]+1
                test_ans_c_num=test_ans_c_num+1
                print 'correct!'
#                 print l_c[selected_node[i]]
#                 print l_accuracy_c[selected_node[i]]
            else:
                l_e[selected_node[i]]=l_e[selected_node[i]]+1
                test_ans_e_num=test_ans_e_num+1
                print 'false!'
#                 print l_e[selected_node[i]]
#                 print l_accuracy_e[selected_node[i]]
            print diff_score[0,selected_node[i]]
            print pre_score[0,selected_node[i]]
            print balance_score[0,selected_node[i]]
        
        exploring_score=exploring_score.reshape(effective_exer_num)
        l_accuracy=1/(1+np.exp(l_e-l_c))
        l_accuracy_c=np.copy(l_accuracy)
        l_accuracy_c[l_c==0]=0
        l_accuracy_e=np.copy(1-l_accuracy)
        l_accuracy_e[l_e==0]=0
        
        spread_c=graph_weight* (l_accuracy_c.T)
        spread_e=graph_weight_T* (l_accuracy_e.T)
        accuracy_spread_c=np.max(spread_c,axis=1)
        accuracy_spread_e=np.max(spread_e,axis=1)
        spread_ind_c=np.argmax(spread_c,axis=1)
        spread_ind_e=np.argmax(spread_e,axis=1)

        diff_c=graph_weight_diff_easy_T* (l_accuracy_c.T)
        diff_e=graph_weight_diff_hard_T* (l_accuracy_e.T)
        accuracy_diff_c=np.max(diff_c,axis=1)
        accuracy_diff_e=np.max(diff_e,axis=1)
        diff_ind_c=np.argmax(diff_c,axis=1)
        diff_ind_e=np.argmax(diff_e,axis=1)



        accuracy_spread_sum=accuracy_spread_c+accuracy_spread_e+diff_w*(accuracy_diff_c+accuracy_diff_e)
        accuracy_spread_sum=np.reshape(accuracy_spread_sum,effective_exer_num)

##        logging.debug("%f", np.sum(accuracy_spread_sum))
##        logging.debug("%s", str(accuracy_spread_sum.shape))

        for row in spamreader:
            if row[7].strip() == 'False' or row[7].strip() == 'FALSE' :
                continue
            if (row[8] in d_name2order) and (d_name2order[row[8]] in selected_node):
                order=d_name2order[row[8]]
                out="{ data: { id: '" + row[8] + "', name: '" + row[13] + "', color: '#FFFFFF', exp_score: '"+str(exploring_score[order]) \
                +"', P_C_prior: '"+str(P_C_prior[order]) + "', EX_v: '"+str(exploration_value[order,0])+"'"
#                 print np.nonzero(selected_node==order)
                accuracy=answering_correctly[np.nonzero(selected_node==order)].mean()
                red="%02x" % int( (1-accuracy) * 255)
                green="%02x" % 0
                blue="%02x" % int(accuracy * 255)
                out=out+", time: '#"+ red + green + blue +"'"
#                 if ==0:
#                     out=out+", time: '#FF0000'"
#                 else:
#                     out=out+", time: '#0000FF'"

                self.response.out.write(out + '} },\n')
                continue
            
                
            if row[8] not in d_correct:
                out="{ data: { id: '" + row[8] + "', name: '" + row[13] + "' "
                if row[8] in d_name2order:
                    
                    order=d_name2order[row[8]]
                    spread_value=accuracy_spread_sum[order]
                    if spread_value > predict_threshold:
                        color_string=compute_color(accuracy_spread_c[order]+diff_w*accuracy_diff_c[order],accuracy_spread_e[order]+diff_w*accuracy_diff_e[order],predict_scale)
                        out="{ data: { id: '" + row[8] + "', name: '" + row[13] + "', text: '#" + color_string + "' "

                    out=out+", exp_score: '"+str(exploring_score[order])+"', P_C_prior: '"+str(P_C_prior[order]) +"', EX_v: '"+str(exploration_value[order,0])+"'"
                    pred_diff_c=accuracy_diff_c[order]
                    pred_diff_e=accuracy_diff_e[order]
                    out = out + ", pred_diff_c: '" + str(pred_diff_c) + "', pred_diff_e: '" + str(pred_diff_e) + "'"
                    if pred_diff_c>0:
                        pre_order=diff_ind_c[order]
                        source_diff_c=l_order2name[pre_order]
#                         correct=d_correct[source_diff_c]
#                         false=d_false[source_diff_c]
                        correct=l_c[pre_order]
                        false=l_e[pre_order]
                        correct_diff_rt=1/(1+math.exp(-(correct-false)))
                        prereq_diff_w_c=pred_diff_c/correct_diff_rt
                        out = out + ", source_diff_c: '" + source_diff_c + "', correct_diff_rt: '" + str(correct_diff_rt) + "', prereq_diff_w_c: '" + str(prereq_diff_w_c) + "'"
                    if pred_diff_e>0:
                        pre_order=diff_ind_e[order]
                        source_diff_e=l_order2name[pre_order]
#                         correct=d_correct[source_diff_e]
#                         false=d_false[source_diff_e]
                        correct=l_c[pre_order]
                        false=l_e[pre_order]
                        correct_diff_rt=1/(1+math.exp(-(correct-false)))
                        prereq_diff_w_e=pred_diff_e/(1-correct_diff_rt)
                        out = out + ", source_diff_e: '" + source_diff_e + "', error_diff_rt: '" + str(1-correct_diff_rt) + "', prereq_diff_w_e: '" + str(prereq_diff_w_e) + "'"
                        
                    pred_c=accuracy_spread_c[order]
                    pred_e=accuracy_spread_e[order]
                    out = out + ", pred_c: '" + str(pred_c) + "', pred_e: '" + str(pred_e) + "'"
                    if pred_c>0:
                        pre_order=spread_ind_c[order]
                        source_c=l_order2name[pre_order]
#                         correct=d_correct[source_c]
#                         false=d_false[source_c]
                        correct=l_c[pre_order]
                        false=l_e[pre_order]
                        correct_rt=1/(1+math.exp(-(correct-false)))
                        prereq_w_c=pred_c/correct_rt
                        out = out + ", source_c: '" + source_c + "', correct_rt: '" + str(correct_rt) + "', prereq_w_c: '" + str(prereq_w_c) + "'"
                    if pred_e>0:
                        pre_order=spread_ind_e[order]
                        source_e=l_order2name[pre_order]
#                         correct=d_correct[source_e]
#                         false=d_false[source_e]
                        correct=l_c[pre_order]
                        false=l_e[pre_order]
                        correct_rt=1/(1+math.exp(-(correct-false)))
                        prereq_w_e=pred_e/(1-correct_rt)
                        out = out + ", source_e: '" + source_e + "', error_rt: '" + str(1-correct_rt) + "', prereq_w_e: '" + str(prereq_w_e) + "'"
                    
##                        logging.debug("enter")
##                        accuracy_spread=accuracy_spread_c[order]/spread_value
##                        scale=( 255-127*math.exp(-float(spread_value)/2*10))
##                        red="%02x" % (scale*(1-accuracy_spread))
##                        green="%02x" % 0
##                        blue="%02x" % (scale*accuracy_spread)
            else:
                correct=d_correct[row[8]]
                false=d_false[row[8]]
                color_string=compute_color(correct,false,exer_scale)
                out="{ data: { id: '" + row[8] + "', name: '" + row[13] + "', color: '#" + color_string + "', do_c: '" + str(correct) + "', do_e: '" + str(false) + "' "
                if d_time[row[8]] != -1:
                    red="%02x" % int((1-d_time[row[8]]) * 255)
                    green="%02x" % 0
                    blue="%02x" % int(d_time[row[8]] * 255)
                else:
                    red='FF'
                    green='FF'
                    blue='FF'
                out=out + ", time: '#" + red + green + blue + "'" 
            self.response.out.write(out + '} },\n')
        self.response.out.write("{ data: { id: 'show_modeling', name: 'show_modeling', color: '#FF0000', time: '#0000FF', text_out: '#00ff00' } },\n")
        self.response.out.write("{ data: { id: 'show_testing', name: 'show_testing', color: '#0000FF', time: '#FF0000', text_out: '#00ff00' } },\n")

        self.response.out.write('\n')
        self.response.out.write("], \n     edges: [\n")
        for i in range(num_test_question-1):
            self.response.out.write("{ data: { source: '" + l_order2name[int(selected_node[i])] + "', target: '" + l_order2name[int(selected_node[i+1])] + "', is_testing: 1, c: '#00FF00', w: 5 } },\n")
		
##	file_path = os.path.join(os.path.split(__file__)[0], 'data\\junyi_Exercise.csv')
    print_links(path,self)
