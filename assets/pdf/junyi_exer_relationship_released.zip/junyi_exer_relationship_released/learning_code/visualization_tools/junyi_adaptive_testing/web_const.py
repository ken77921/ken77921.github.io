# -*- coding: utf-8 -*-

WEB_BEGIN_CONST='''
<!DOCTYPE html>
<html>
<head>
		<link href="/javascript/cytoscape.js-panzoom.css" rel="stylesheet" type="text/css" />
		<link href="/javascript/font-awesome-4.0.3/css/font-awesome.css" rel="stylesheet" type="text/css" />
<meta name="description" content="[An example of getting started with Cytoscape.js]" />
<script type="text/javascript" src="/javascript/jquery.min.js"></script>
<script type="text/javascript" src="/javascript/cytoscape.min.js"></script>
<meta charset=utf-8 />
<!--
Created using JS Bin
http://jsbin.com

Copyright (c) 2014 by maxkfranz (http://jsbin.com/urabis/16/edit)

Released under the MIT license: http://jsbin.mit-license.org
-->
<title>Cytoscape.js initialisation</title>
<script type="text/javascript" src="/javascript/cytoscape.js-panzoom.js"></script>
<style id="jsbin-css">
body { 
  font: 12px helvetica neue, helvetica, arial, sans-serif;
}

#cy {
  height: 100%;
  width: 80%;
  position: absolute;
  left: 0;
  top: 0;
}



</style>
</head>
<body> 
  <div id="cy"></div>
  <p align="center">Tap a node to highlight its neighbourhood</p>
  '''

WEB_MIDDLE_CONST='''
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <a id="exer_link" style="float:right;" target="_blank"></a>
  <br>
  <br>
  <label id="do_c" style="float:right;"></label>
  <label style="float:right;">#correct answers: </label>
  <br>
  <label id="do_e" style="float:right;"></label>
  <label style="float:right;">#wrong answers: </label>
  <br>
  <br>
  <label style="float:right;">Prerequisite: </label>
  <br>
  <label id="pred_c" style="float:right;"></label>
  <label style="float:right;">predicted correct answers: </label>
  <br>
  <label id="source_c" style="float:right;"></label>
  <label style="float:right;"> , </label>
  <label id="source_c_chinese" style="float:right;"></label>
  <label style="float:right;">Source of correct: </label>
  <br>
  <label style="float:right;"> (prerequisite_weight) </label>
  <label id="prereq_w_c" style="float:right;"></label>
  <label style="float:right;"> (accuracy) x </label>
  <label id="correct_rt" style="float:right;"></label>
  <br>
  <br>
  <label id="pred_e" style="float:right;"></label>
  <label style="float:right;">predicted wrong answers: </label>
  <br>
  <label id="source_e" style="float:right;"></label>
  <label style="float:right;"> , </label>
  <label id="source_e_chinese" style="float:right;"></label>
  <label style="float:right;">Source of wrong: </label>
  <br>
  <label style="float:right;"> (prerequisite_weight) </label>
  <label id="prereq_w_e" style="float:right;"></label>
  <label style="float:right;"> (accuracy) x </label>
  <label id="error_rt" style="float:right;"></label>
  <br>
  <br>
  <label style="float:right;">Difficulty: </label>
  <br>
  <label id="pred_diff_c" style="float:right;"></label>
  <label style="float:right;">predicted correct answers (by difficulty): </label>
  <br>
  <label id="source_diff_c" style="float:right;"></label>
  <label style="float:right;"> , </label>
  <label id="source_diff_c_chinese" style="float:right;"></label>
  <label style="float:right;">Source of correct: </label>
  <br>
  <label style="float:right;"> (difficulty_weight) </label>
  <label id="prereq_diff_w_c" style="float:right;"></label>
  <label style="float:right;"> (accuracy) x </label>
  <label id="correct_diff_rt" style="float:right;"></label>
  <br>
  <br>
  <label id="pred_diff_e" style="float:right;"></label>
  <label style="float:right;">predicted wrong answers (by difficulty): </label>
  <br>
  <label id="source_diff_e" style="float:right;"></label>
  <label style="float:right;"> , </label>
  <label id="source_diff_e_chinese" style="float:right;"></label>
  <label style="float:right;">Source of wrong: </label>
  <br>
  <label style="float:right;"> (difficulty_weight) </label>
  <label id="prereq_diff_w_e" style="float:right;"></label>
  <label style="float:right;"> (accuracy) x </label>
  <label id="error_diff_rt" style="float:right;"></label>
  <br>
  <br>
  <label id="exp_score" style="float:right;"></label>
  <label style="float:right;">exploration score: </label>
  <br>
  <label id="P_C_prior" style="float:right;"></label>
  <label style="float:right;">P_C_prior: </label>
  <br>
  <label id="P_C" style="float:right;"></label>
  <label style="float:right;">P_C: </label>
  <br>
  <label id="EX_v" style="float:right;"></label>
  <label style="float:right;">Exploration value: </label>
  
  
<script type="text/javascript">
document.getElementById("cy").style.width=($( document ).width() - 120).toString() + "px";
$(function(){ // on dom ready
var cy = cytoscape({
boxSelectionEnabled: false,
panningEnabled: true,
userPanningEnabled: true,
//panningEnabled: false,
//userPanningEnabled: false,
container: document.getElementById('cy'),
  style: cytoscape.stylesheet()
    .selector('node')
      .css({
	  	'height': 20,
		'width': 20,
        'content': 'data(name)',
		'font-size': 8,
        //'text-valign': 'center',
		'background-color': 'data(color)',
		//'min-zoomed-font-size': 5,
		'border-width': 5,
		'border-color': 'data(time)',
        'color': 'white',
		//'color': 'data(text)',
		'text-outline-width': 2,
        //'text-outline-color': '#888'
		'text-outline-color': 'data(text_out)'
      })
    .selector('edge')
      .css({
        'target-arrow-shape': 'triangle',
		'width': 'data(w)',
		'line-color': 'data(c)',
		'target-arrow-color': 'data(c)',
		//'control-point-distance': 100
		//'control-point-step-size': 1
		//'control-point-weight' : '0.5'
      })
    .selector(':selected')
      .css({
        'background-color': 'black',
        'line-color': 'black',
        'target-arrow-color': 'black',
        'source-arrow-color': 'black'
      })
    .selector('.faded')
      .css({
        'opacity': 0.5,
        'text-opacity': 0
      }),
  
  elements: {
    nodes: [
'''

WEB_END_CONST='''


    ]
  },

  layout: {
    name: 'breadthfirst',

    fit: true, // whether to fit the viewport to the graph
    ready: undefined, // callback on layoutready
    stop: undefined, // callback on layoutstop
    directed: true, // whether the tree is directed downwards (or edges can point in any direction if false)
    padding: 30, // padding on fit
    circle: false, // put depths in concentric circles if true, put depths top down if false
    roots: undefined, // the roots of the trees
    maximalAdjustments: 0 // how many times to try to position the nodes in a maximal way (i.e. no backtracking)
  },
	  
  ready: function(){
    window.cy = this;
    
    // giddy up...
    
    cy.elements().unselectify();
    
    var model_tap_switch=0;
    var model_tap_testing=1;
    var removed_edges;
    
    cy.on('tap', 'node', function(e){
    
      var node = e.cyTarget;
      if(node.id()=='show_modeling'){
      	if(model_tap_switch==0){
	      	cy.elements().css( 'text-outline-color','data(text)' );
	      	model_tap_switch=1;
	    }else{
	      	cy.elements().css( 'text-outline-color','#888' );
	      	model_tap_switch=0;
	    }
      	return;
      }
      
      if(node.id()=='show_testing'){
      	if(model_tap_testing==0){
	      	//cy.elements( "edge[is_testing = 1]" ).restore();
	      	//cy.edges( "[is_testing = 1]" ).restore();
	      	//cy.edges( "[is_testing = 1]" ).show();
	      	//cy.edges( "[source = 'division_1']" ).css('width', 5);
	      	removed_edges.restore();
	      	cy.layout();
	      	model_tap_testing=1;
	    }else{
	    	//var collection=cy.elements( 'edge[is_testing = 1]' );
	    	//cy.remove( collection );
	      	//cy.remove( 'edge[is_testing = 1]' );
	      	//cy.edges( "[is_testing = 1]" ).hide();
	      	//cy.edges( "[source = 'division_1']" ).css('width', 0);
	      	removed_edges=cy.edges( "[is_testing = 1]" );
	      	removed_edges.remove();
	      	cy.layout();
	      	model_tap_testing=0;
	    }
      	return;
      }
      
       
	  //document.getElementById("select_exer").value=node.id();
	  document.getElementById("exer_link").innerHTML=node.data('name');
	  document.getElementById("exer_link").href='http://www.junyiacademy.org/exercise/'+node.id();
	  
	  document.getElementById('do_c').innerHTML=node.data('do_c');
	  document.getElementById('do_e').innerHTML=node.data('do_e');
	  document.getElementById('pred_c').innerHTML=node.data('pred_c');
	  document.getElementById('pred_e').innerHTML=node.data('pred_e');
	  document.getElementById('source_c').innerHTML=node.data('source_c');
	  document.getElementById('source_e').innerHTML=node.data('source_e');
	  document.getElementById('correct_rt').innerHTML=node.data('correct_rt');
	  document.getElementById('error_rt').innerHTML=node.data('error_rt');
	  document.getElementById('prereq_w_c').innerHTML=node.data('prereq_w_c');
	  document.getElementById('prereq_w_e').innerHTML=node.data('prereq_w_e');
	  
	  c_node=cy.getElementById( node.data('source_c') );
	  document.getElementById('source_c_chinese').innerHTML=c_node.data('name');
	  e_node=cy.getElementById( node.data('source_e') );
	  document.getElementById('source_e_chinese').innerHTML=e_node.data('name');
	  
	  document.getElementById('pred_diff_c').innerHTML=node.data('pred_diff_c');
	  document.getElementById('pred_diff_e').innerHTML=node.data('pred_diff_e');
	  document.getElementById('source_diff_c').innerHTML=node.data('source_diff_c');
	  document.getElementById('source_diff_e').innerHTML=node.data('source_diff_e');
	  document.getElementById('correct_diff_rt').innerHTML=node.data('correct_diff_rt');
	  document.getElementById('error_diff_rt').innerHTML=node.data('error_diff_rt');
	  document.getElementById('prereq_diff_w_c').innerHTML=node.data('prereq_diff_w_c');
	  document.getElementById('prereq_diff_w_e').innerHTML=node.data('prereq_diff_w_e');
	  
	  c_diff_node=cy.getElementById( node.data('source_diff_c') );
	  document.getElementById('source_diff_c_chinese').innerHTML=c_diff_node.data('name');
	  e_diff_node=cy.getElementById( node.data('source_diff_e') );
	  document.getElementById('source_diff_e_chinese').innerHTML=e_diff_node.data('name');
	  
	  document.getElementById('exp_score').innerHTML=node.data('exp_score');
	  document.getElementById('P_C_prior').innerHTML=node.data('P_C_prior');
	  document.getElementById('P_C').innerHTML=node.data('P_C');
	  document.getElementById('EX_v').innerHTML=node.data('EX_v');
	  
      var neighborhood = node.neighborhood().add(node).add(c_node).add(e_node).add(c_diff_node).add(e_diff_node);
      
      cy.elements().addClass('faded');
      neighborhood.removeClass('faded');
    });
    
    cy.on('tap', function(e){
      if( e.cyTarget === cy ){
        cy.elements().removeClass('faded');
      }
    });
  }
});

cy.panzoom({
	// options go here
});

}); // on dom ready
</script>
</body>
</html>
'''