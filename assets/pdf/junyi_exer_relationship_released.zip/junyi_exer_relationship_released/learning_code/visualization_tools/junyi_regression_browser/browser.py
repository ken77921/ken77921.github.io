import os
import csv
import cgi
import webapp2
import web_const
import math
from google.appengine.ext import ndb

def load_exer_list(path):
    with open(path,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        d=[]
        for row in spamreader:
            d.append(row[1].strip())
        exer_num=len(row)-3
        return sorted(d),exer_num

def load_exer_id2name(exer_list_path):
    f_exer_list=open(exer_list_path,"r")
    reader = csv.reader(f_exer_list, delimiter=',')
    row=reader.next()
    d_exer_list={}
    d_name2id={}
    for row in reader:
        d_exer_list[int(row[0])-1]=row[1]
        d_name2id[row[1]]=int(row[0])-1
    return d_exer_list,d_name2id

def load_score(score_path,select_exer):
    score_csvfile=open(score_path,'rb')
    reader = csv.reader(score_csvfile, delimiter=',')
    row=reader.next()
    d_score_norm={}
    other_statistics=[0]*8
    for row in reader:
        d_score_norm[row[1].strip()]=float(row[3])
        if row[1].strip() == select_exer:
            other_statistics[0:8]=row[2:10] #RF_score, RF_score_norm, correct sample number, base error, simple sparsity, complex sparsity, abolute error, mean accuracy
    return d_score_norm,other_statistics

def load_fw_file(fw_path, sel_exer,start_dim,end_dim):
    with open(fw_path,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        fw=[]
        for row in spamreader:
            if row[1].strip() != sel_exer:
                continue
##            fw_distri=[float(x) for x in row[2:-1]]
            fw=row[start_dim:end_dim]
            break
        return fw


def load_fw(weight_path, sel_exer,d_exer_list,start_ind,end_ind):
    weight=load_fw_file(weight_path, sel_exer,start_ind,end_ind)
    if len(weight)==0:
        return []
    weight=[float(x) for x in weight]
    d_weight={}
    for i in d_exer_list:
        d_weight[d_exer_list[i]]=weight[i]
    return d_weight

def load_fw_norm(weight_path, sel_exer,d_exer_list):
    weight=load_fw_file(weight_path, sel_exer,2,-1)
    weight=[float(x) for x in weight]
    max_weight=max(weight)
    weight_norm=[x/max_weight for x in weight]
    d_weight_norm={}
    for i in d_exer_list:
        d_weight_norm[d_exer_list[i]]=weight_norm[i]
    return d_weight_norm, max_weight

def print_links(file_path,self):
    with open(file_path,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        row=spamreader.next()
        for row in spamreader:
            if row[7].strip() == 'False' or row[7].strip() == 'FALSE' :
                continue
            parstr=row[9].replace('[','')
            parstr=parstr.replace(']','')
            if len(parstr) == 0:
                continue
            tok=[ x.strip() for x in parstr.split(',')]
            for par in tok:
                out="{ data: { source: '" + par + "', target: '" + row[8] + "' } },"
                self.response.out.write(out+"\n")


def print_node_on_network(path,d_score_norm, d_weight_norm, d_sample_num, raw_weight, dist_weight, gmm_weight, total_sample_num, sel_exer, self,d_have_list):
    with open(path,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        row=spamreader.next()
        for row in spamreader:
            if row[7].strip() == 'FALSE' or row[7].strip() == 'False':
                continue

            if row[8] not in d_score_norm and row[8] not in d_have_list:
                continue
            
            if row[8] in d_score_norm:
                score=d_score_norm[row[8]]
                if score>=0:
                    blue="%02x" % (255*score)
                    red="%02x" % 0
                else:
                    blue="%02x" % (255*abs(score))
                    red="%02x" % (255*abs(score))
                green="%02x" % 0

                score_color=red+green+blue
            else:
                score_color="888888"

            if len(gmm_weight) == 0:
                gmm_str=''
            else:
                gmm_str=str(gmm_weight[row[8]])

##            raw_weight[row[8]]
##            dist_weight[row[8]]
##            d_sample_num[row[8]]
            weight_distri= ", raw: '" + str(raw_weight[row[8]]) + "', dist: '" + str(dist_weight[row[8]]) + "', gmm: '" + gmm_str + "', sn: '" +  str(d_sample_num[row[8]]) + "'"

            if row[8].strip() not in d_weight_norm:
                out="{ data: { id: '" + row[8] + "', name: '" + row[13] + "' "
            elif row[8] == sel_exer:
                out="{ data: { id: '" + row[8] + "', name: '" + row[13] + "', color: '#" + score_color + "', text_c: '#FF0000', border_c: '#FF0000' " + weight_distri
            else:
                weight=d_weight_norm[row[8]]
                red="%02x" % (255*weight)
                green="%02x" % (255*(1-weight))
                blue="%02x" % 0
                back_color=red+green+blue

                sample_num_norm=d_sample_num[row[8]]/float(total_sample_num)
                red="%02x" % 0
                green="%02x" % (255*(1-sample_num_norm))
                blue="%02x" % (255*sample_num_norm)
                border_color=red+green+blue

                out="{ data: { id: '" + row[8] + "', name: '" + row[10] + "', color: '#" + back_color + "', text_c: '#" + score_color + "', border_c: '#" + border_color + "'" + weight_distri
            self.response.out.write(out + '} },\n')
        self.response.out.write('\n')
sel_exer=""

class MainHandler(webapp2.RequestHandler):
    def get(self):
        self.response.out.write(web_const.WEB_BEGIN_CONST)

        path = os.path.join(os.path.split(__file__)[0], 'data\\classifier_results_fw_sum.txt')
##        path = os.path.join(os.path.split(__file__)[0], os.pardir, 'classifier_results_fw_sum.txt')

        d,exer_num=load_exer_list(path)
##        query_results = ndb.gql('SELECT * '
##                'FROM cross_DS '
##                'ORDER BY date DESC LIMIT 10',
##                browser_key)
##        sel_exer=d[0].strip()
##        for x in query_results:
##            sel_exer=x.student
        global sel_exer
        if not sel_exer:
            sel_exer=d[0]

        self.response.out.write('<form action="./draw" method="post" style="float:right;"> \n<select style="width:100px" name="select_exer" id="select_exer"> \n')
        for usr in d:
            usr_no_space=usr
            if usr_no_space != sel_exer:
                self.response.out.write('<option value="' + usr_no_space + '">' + usr_no_space + '</option> \n')
            else:
                self.response.out.write('<option value="' + usr_no_space + '" selected="selected">' + usr_no_space + '</option> \n')
        self.response.out.write('</select> \n<p><input type="submit" /></p> \n')
        self.response.out.write('</form> \n')

        score_path = os.path.join(os.path.split(__file__)[0], 'data\\rf_score_data.csv')
        d_score_norm,other_statistics = load_score(score_path,sel_exer)
        total_sample_num=other_statistics[2]
#         self.response.out.write("<p align='right'> sample number: " + total_sample_num + "</p>\n")
	self.response.out.write("<p align='right'> correct sample number: " + other_statistics[2] + "</p>\n")
        self.response.out.write("<p align='right'> score: " + other_statistics[0]  + "</p>\n")
        self.response.out.write("<p align='right'> mean accuracy: " + other_statistics[7]  + "</p>\n")
        self.response.out.write("<p align='right'> base error: " + other_statistics[3] + "</p>\n")
        self.response.out.write("<p align='right'> abolute error: " + other_statistics[6] + "</p>\n")
        self.response.out.write("<p align='right'> simple sparsity: " + other_statistics[4] + "</p>\n")
        self.response.out.write("<p align='right'> complex sparsity: " + other_statistics[5] + "</p>\n")
#         self.response.out.write("<p align='right'> mean accuracy: " + other_statistics[8]  + "</p>\n")
#         self.response.out.write("<p align='right'> improve value: " + other_statistics[7] + "</p>\n")

        fw_distri_path = os.path.join(os.path.split(__file__)[0], 'data\\classifier_results_fw_distribution.txt')
        fw_distri = load_fw_file(fw_distri_path,sel_exer,2,-1)
        self.response.out.write("<p align='right'> raw data sum: " + fw_distri[0] + "</p>\n")
        self.response.out.write("<p align='right'> graph distance sum: " + fw_distri[1] + "</p>\n")
        self.response.out.write("<p align='right'> gmm sum: " + fw_distri[2] + "</p>\n")
##        self.response.out.write("<p align='right'> correct num sum: " + fw_distri[3] + "</p>\n")
##        self.response.out.write("<p align='right'> spent time sum: " + fw_distri[4] + "</p>\n")
##        self.response.out.write("<p align='right'> exer num sum: " + fw_distri[5] + "</p>\n")

        exer_list_path = os.path.join(os.path.split(__file__)[0], 'data\\pretest_exer_list.csv')
        d_exer_list,c=load_exer_id2name(exer_list_path)
        d_weight_norm,max_weight = load_fw_norm(path,sel_exer,d_exer_list)
        self.response.out.write("<p align='right'> max weight: " + str(max_weight) + "</p>\n")

        self.response.out.write(web_const.WEB_MIDDLE_1_CONST)
        self.response.out.write("'height': " + str(15+15*(1-math.exp(-max_weight/0.2))) + ", \n")
        self.response.out.write("'width': " + str(15+15*(1-math.exp(-max_weight/0.2))) + ", \n")
        self.response.out.write(web_const.WEB_MIDDLE_2_CONST)



##        exer_num=837
        sample_num_path = os.path.join(os.path.split(__file__)[0], 'data\\classifier_results_f_samples_first_correct.csv')
        d_sample_num = load_fw(sample_num_path,sel_exer,d_exer_list,3,3+exer_num)
##        d_sample_num = load_sample_num(sample_num_path,sel_exer,d_exer_list,total_sample_num)


        raw_path = os.path.join(os.path.split(__file__)[0], 'data\\classifier_results_fw_org.txt')
        d_raw_weight = load_fw(raw_path,sel_exer,d_exer_list,2,2+exer_num)
        dist_path = os.path.join(os.path.split(__file__)[0], 'data\\classifier_results_fw_dist_trans.txt')
        d_dist_weight = load_fw(dist_path,sel_exer,d_exer_list,2,2+exer_num)
        gmm_path = os.path.join(os.path.split(__file__)[0], 'data\\classifier_results_fw_gmm_trans.txt')
        d_gmm_weight = load_fw(gmm_path,sel_exer,d_exer_list,2,2+exer_num)

        have_link_path = os.path.join(os.path.split(__file__)[0], 'data\\have_links_list.txt')
        c,d_have_list=load_exer_id2name(have_link_path)

        exer_all_path = os.path.join(os.path.split(__file__)[0], 'data\\junyi_Exercise.csv')
        print_node_on_network(exer_all_path, d_score_norm, d_weight_norm, d_sample_num, d_raw_weight, d_dist_weight, d_gmm_weight, total_sample_num, sel_exer, self,d_have_list)

        self.response.out.write("], \n edges: [\n")

        print_links(exer_all_path,self)

        self.response.out.write(web_const.WEB_END_CONST)


class DrawHandler(webapp2.RequestHandler):
    def post(self):
        global sel_exer
        sel_exer=self.request.get_all('select_exer')
        sel_exer=str(sel_exer)[3:-2]
        self.redirect('/')
##        sel_exer=cgi.escape(self.request.get_all('select_user'))
##        sel_exer=str(sel_exer).translate(None,"[]'")[1:]
##        browser = cross_DS(parent=browser_key)
##        browser.student = sel_exer
##        browser.put()

application = webapp2.WSGIApplication([
    ('/', MainHandler),
    ('/draw', DrawHandler)
], debug=True)

##browser_key = ndb.Key('browser', 'default_browser')

##class cross_DS(ndb.Model):
##  student = ndb.TextProperty()
##  date = ndb.DateTimeProperty(auto_now_add=True)

##    with open(weight_path,'rb') as csvfile:
##        spamreader = csv.reader(csvfile, delimiter=',')
##        d_weight_norm={}
##        for row in spamreader:
##            if row[1].strip() != target_exer:
##                continue
##            weight=[float(x) for x in row[2:-1]]
##            weight_max=max(weight)
##            norm_weight=[x/weight_max for x in weight]
##            for i in d_exer_list:
##                d_weight_norm[d_exer_list[i]]=norm_weight[i]
####                d_weight_norm[row[1].replace('"','')]=norm_weight[int(row[0].replace('"',''))-1]
####            d_weight_norm[target_exer]=float(row_score[3])
##            break
##        return d_weight_norm

##def load_sample_num(sample_num_path, sel_exer,d_exer_list,total_sample_num):
##    sample_num=load_fw_file(sample_num_path, sel_exer,3,-1)
##    sample_num_norm=[float(x)/total_sample_num for x in sample_num]
##    d_sample_num={}
##    for i in d_exer_list:
##        d_sample_num[d_exer_list[i]]=sample_num_norm[i]
##    return d_sample_num
##    with open(sample_num_path,'rb') as csvfile:
##        spamreader = csv.reader(csvfile, delimiter=',')
##        d_sample_num={}
##        for row in spamreader:
##            if row[1].strip() != sel_exer:
##                continue
##            all_sample_num=float(row[2])
##            sample_num=[float(x)/all_sample_num for x in row[3:-1]]
##            for i in d_exer_list:
##                d_sample_num[d_exer_list[i]]=sample_num[i]
####                d_weight_norm[row[1].replace('"','')]=norm_weight[int(row[0].replace('"',''))-1]
####            d_weight_norm[target_exer]=float(row_score[3])
##            break
##        return d_sample_num
