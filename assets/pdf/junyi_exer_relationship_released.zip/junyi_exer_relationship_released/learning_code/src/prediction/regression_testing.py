'''
Created on Jan 28, 2015

@author: Ken-MMNlab
'''

# from collections import defaultdict
import csv
import ast
import math
import numpy as np
from datetime import datetime
import scipy.stats.stats as sci_st

from sklearn.decomposition import PCA
from sklearn import preprocessing
from sklearn import linear_model
from sklearn.svm import NuSVR
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import GradientBoostingRegressor

import matplotlib.pyplot as plt
# from mpl_toolkits.mplot3d import Axes3D

our_font_size=30
title_font_size=60

##def file_len(fname):
##    with open(fname) as f:
##        for i, l in enumerate(f):
##            pass
##    return i + 1

def file_len_filtered(fname,d_i):
    csvfile=open(fname,'rb')
    spamreader = csv.reader(csvfile, delimiter=',')
    i=0
    for row in spamreader:
        if (row[0] not in d_i) or (row[1] not in d_i):
            continue
        i=i+1
        
    return i

def rt_func(a,b):
    return math.log(a)-math.log(b)

def show_f_weight(clf,X,Y,X_names,group_ind,f_ind,want_sort,title_name):
    clf.fit(X,Y)
    importances = clf.feature_importances_
    stds = np.std([tree.feature_importances_ for tree in clf.estimators_],axis=0)
    im_group=np.zeros(len(group_ind)-1)
    stds_group=np.zeros(len(group_ind)-1)
    for i in range(len(group_ind)-1):
        im_group[i]=sum(importances[group_ind[i]:group_ind[i+1]])
        stds_group[i]=sum(stds[group_ind[i]:group_ind[i+1]])

    fig=plt.figure(f_ind)
    fig.add_axes([0.3,0.1,0.6,0.8])

    plt.title(title_name,fontsize=title_font_size)
    pos = np.arange(im_group.shape[0]) + .5
    X_names=np.array(X_names)
    plt.xlabel('Relative weights',fontsize=our_font_size)
    plt.xticks(size=our_font_size)
#     ax = plt.gca()
#     ax.tick_params(width=10,length=20)

    if want_sort==1:
        indices = np.argsort(im_group)[::-1]
        plt.barh(pos, im_group[indices],color="r",xerr=stds_group[indices], align='center')
        plt.yticks(pos,X_names[indices],fontsize=our_font_size )
    else:
        plt.barh(pos, im_group,color="r",xerr=stds_group, align='center')
        plt.yticks(pos,X_names,fontsize=our_font_size )


def load_dict_from_csv(file_name,exer_num):
    dict_out = range(exer_num)
    for key, val in csv.reader(open(file_name)):
        dict_out[int(key)] = ast.literal_eval(val)
    return dict_out

def qmean(l_num):
    return math.sqrt(sum(n*n for n in l_num)/len(l_num))

def mean_sqaure(l_num):
    return sum(n*n for n in l_num)/len(l_num)


def direct_predict(clf,X_train,Y_train,X_test):
    Y_pred=np.zeros((X_test.shape[0],3),float)
    scaler=preprocessing.MinMaxScaler()
    Y_norm_1 = scaler.fit_transform(Y_train[:,0].reshape((-1,1)))
    Y_pred_norm_1=clf.fit(X_train, Y_norm_1.reshape(-1)).predict(X_test)
    Y_pred[:,0] = scaler.inverse_transform(Y_pred_norm_1)

    Y_norm_2 = scaler.fit_transform(Y_train[:,1].reshape((-1,1)))
    Y_pred_norm_2=clf.fit(X_train, Y_norm_2.reshape(-1)).predict(X_test)
    Y_pred[:,1] = scaler.inverse_transform(Y_pred_norm_2)

    Y_norm_3 = scaler.fit_transform(Y_train[:,2].reshape((-1,1)))
    Y_pred_norm_3=clf.fit(X_train, Y_norm_3.reshape(-1)).predict(X_test)
    Y_pred[:,2] = scaler.inverse_transform(Y_pred_norm_3)

    return Y_pred

def PCA_predict(clf,X_train,Y_train,X_test):
#     pca = PCA(n_components=3)
    pca = PCA(n_components=2)
    Y_pca_train = pca.fit_transform(Y_train)
    Y_pca_pred=np.zeros((X_test.shape[0],2),float)
#     Y_pca_pred=np.zeros((X_test.shape[0],3),float)
    scaler=preprocessing.MinMaxScaler()
    Y_norm_1 = scaler.fit_transform(Y_pca_train[:,0].reshape((-1,1)))
    Y_pred_norm_1=clf.fit(X_train, Y_norm_1.reshape(-1)).predict(X_test)
    Y_pca_pred[:,0] = scaler.inverse_transform(Y_pred_norm_1)

    Y_norm_2 = scaler.fit_transform(Y_pca_train[:,1].reshape((-1,1)))
    Y_pred_norm_2=clf.fit(X_train, Y_norm_2.reshape(-1)).predict(X_test)
    Y_pca_pred[:,1] = scaler.inverse_transform(Y_pred_norm_2)

#     Y_norm_3 = scaler.fit_transform(Y_pca_train[:,2].reshape((-1,1)))
#     Y_pred_norm_3=clf.fit(X_train, Y_norm_3.reshape(-1)).predict(X_test)
#     Y_pca_pred[:,2] = scaler.inverse_transform(Y_pred_norm_3)

#     Y_pca_pred=np.zeros((X_test.shape[0],3),float)
#     Y_pca_pred[:,0] = clf.fit(X_train, Y_pca_train[:,0]).predict(X_test)
#     Y_pca_pred[:,1] = clf.fit(X_train, Y_pca_train[:,1]).predict(X_test)
#     Y_pca_pred[:,2] = clf.fit(X_train, Y_pca_train[:,2]).predict(X_test)
    Y_norm_pred=pca.inverse_transform(Y_pca_pred)
    return Y_norm_pred

def eval_by_rank(Y_pred,Y_gt,test_index,exer_group_ind_arr):
    test_index_min=min(test_index)
    test_index_max=max(test_index)
    s_arr=[]
    k_arr=[]
    w_arr=[]
    for i in range(len(exer_group_ind_arr)-1):
        start_ind=exer_group_ind_arr[i]-test_index_min
        end_ind=exer_group_ind_arr[i+1]-test_index_min
        if start_ind<0 or start_ind>=test_index_max-test_index_min:
            continue
        if end_ind-start_ind<=1:
            continue
        Y_pred_rank_i=sci_st.rankdata(Y_pred[start_ind:end_ind], method='ordinal')
        Y_gt_rank_i=sci_st.rankdata(Y_gt[start_ind:end_ind], method='ordinal')
        s_arr.append(sci_st.spearmanr(Y_pred_rank_i,Y_gt_rank_i)[0])
        if math.isnan(sci_st.spearmanr(Y_pred_rank_i,Y_gt_rank_i)[0]):
            print Y_pred[start_ind:end_ind]
        k_arr.append(sci_st.kendalltau(Y_pred_rank_i,Y_gt_rank_i)[0])
#         w_arr.append(end_ind-start_ind)
        w_arr.append(1)
    s_arr=np.array(s_arr)
    k_arr=np.array(k_arr)
    w_arr=np.array(w_arr)
    sw_mean=np.sum(s_arr*w_arr)/np.sum(w_arr)
    kw_mean=np.sum(k_arr*w_arr)/np.sum(w_arr)
    return sw_mean,kw_mean

def RSE_eval(f_out,clf_5,X_training,X_testing,Y,Y_training,relation_rms,difficulty_rms,prerequisite_rms,use_PCA,rounding_opt):

    if(use_PCA):
        Y_pred=PCA_predict(clf_5,X_training,Y_training,X_testing)
    else:
        Y_pred=direct_predict(clf_5,X_training,Y_training,X_testing)
#         Y_pred=PCA_predict(clf_4,X_structure_norm[train_index,:],Y,X_structure_norm[test_index,:])
    if(rounding_opt==0):
        r0=mean_sqaure(Y_pred[:,0]-Y[:,0])/relation_rms
        r1=mean_sqaure(Y_pred[:,1]-Y[:,1])/difficulty_rms
        r2=mean_sqaure(Y_pred[:,2]-Y[:,2])/prerequisite_rms
    else:
        r0=mean_sqaure(np.round(Y_pred[:,0])-Y[:,0])/relation_rms
        r1=mean_sqaure(np.round(Y_pred[:,1])-Y[:,1])/difficulty_rms
        r2=mean_sqaure(np.round(Y_pred[:,2])-Y[:,2])/prerequisite_rms

    print str(r0)+','+str(r1)+','+str(r2)
    if (f_out!=0):
        f_out.write(str(r0)+','+str(r1)+','+str(r2)+',')

def rank_eval(f_out,clf,X_training,X_testing,Y_training,Y,exer_group_ind_arr,use_PCA,rounding_opt):
    if(use_PCA):
        Y_pred=PCA_predict(clf,X_training,Y_training,X_testing)
    else:
        Y_pred=direct_predict(clf,X_training,Y_training,X_testing)

    if(rounding_opt==1):
        s0,k0=eval_by_rank(np.round(Y_pred[:,0]),Y[:,0],range(Y.shape[0]),exer_group_ind_arr)
        s1,k1=eval_by_rank(np.round(Y_pred[:,1]),Y[:,1],range(Y.shape[0]),exer_group_ind_arr)
        s2,k2=eval_by_rank(np.round(Y_pred[:,2]),Y[:,2],range(Y.shape[0]),exer_group_ind_arr)
    else:
        s0,k0=eval_by_rank(Y_pred[:,0],Y[:,0],range(Y.shape[0]),exer_group_ind_arr)
        s1,k1=eval_by_rank(Y_pred[:,1],Y[:,1],range(Y.shape[0]),exer_group_ind_arr)
        s2,k2=eval_by_rank(Y_pred[:,2],Y[:,2],range(Y.shape[0]),exer_group_ind_arr)
# #             Y_norm_pred=PCA_predict(clf_4,X_structure_norm[train_index,:],Y_norm[train_index,:],X_structure_norm[test_index,:])
#         Y_norm_pred=PCA_predict(clf_4,X_norm[train_index,:],Y_norm[train_index,:],X_norm[test_index,:])
#         s0,k0=eval_by_rank(Y_norm_pred[:,0],Y_norm[test_index,0],test_index,exer_group_ind_arr)
#         s1,k1=eval_by_rank(Y_norm_pred[:,1],Y_norm[test_index,1],test_index,exer_group_ind_arr)
#         s2,k2=eval_by_rank(Y_norm_pred[:,2],Y_norm[test_index,2],test_index,exer_group_ind_arr)
    print str(s0)+','+str(s1)+','+str(s2)+','+str(k0)+','+str(k1)+','+str(k2)
    f_out.write(str(s0)+','+str(s1)+','+str(s2)+','+str(k0)+','+str(k1)+','+str(k2)+',')

def load_all_features(data_location,inter_dir,modeling_dir,feature_dir,exer_num,effective_exer_num):
    udir_dist=load_dict_from_csv(inter_dir+"\\udir_dist.txt",exer_num) #student_modeling/build_distances.py
    rdir_dist=load_dict_from_csv(inter_dir+"\\rdir_dist.txt",exer_num) #student_modeling/build_distances.py
    dir_dist=load_dict_from_csv(inter_dir+"\\dir_dist.txt",exer_num) #student_modeling/build_distances.py

    csvfile=open(data_location+'\\pretest_exx.csv','rb')
    spamreader = csv.reader(csvfile, delimiter=',')
    row=spamreader.next()
    d_c1={}
    d_c_last={}
    d_total_num_mean={}
    d_total_num_median={}
    d_total_num_var={}
    d_total_num_sum={}
    d_unum={}
    for row in spamreader:
        if float(row[8])<2:
            continue
        d_c1[row[1]]=float(row[2])
        d_c_last[row[1]]=float(row[3])
        d_total_num_mean[row[1]]=float(row[4])
        d_total_num_median[row[1]]=float(row[5])
        d_total_num_var[row[1]]=float(row[6])
        d_total_num_sum[row[1]]=float(row[7])
        d_unum[row[1]]=float(row[8])

    csvfile=open(data_location+'\\junyi_Exercise.csv','rb')
    spamreader = csv.reader(csvfile, delimiter=',')
##    d_create_time={}
    d_location_x={}
    d_location_y={}
    d_how_fast={}
    row=spamreader.next()
    for row in spamreader:
#         d_create_time[row[8]]=time.strptime(row[3],'%Y-%m-%d %H:%M:%S.').time()
##        d_create_time[row[8]]=datetime.strptime(row[3], '%Y-%m-%d %H:%M:%S.%f')
        d_location_x[row[8]]=int(row[5])
        d_location_y[row[8]]=int(row[16])
        d_how_fast[row[8]]=float(row[12])


    csvfile=open(modeling_dir+'\\classifier_results_fw_sum.txt','rb') #student_modeling/regression_new_feature.py and dist_gmm_to_nodes
    spamreader = csv.reader(csvfile, delimiter=',')
    d_i={}
    d_o={}
    d_pair_fw={}
    d_max_w={}
    i=0
    for row in spamreader:
        d_i[row[1].strip()]=int(row[0])
        d_o[row[1].strip()]=i
        d_pair_fw[row[1].strip()]=[float(x) for x in row[2:2+exer_num]]
        d_max_w[row[1].strip()]=max(d_pair_fw[row[1].strip()])
        i=i+1

    csvfile=open(feature_dir+'\\UN_exer_lapse_time.csv','rb') #file_analysis/user_num_and_order
    spamreader = csv.reader(csvfile, delimiter=',')
    d_exer_lapse_time={}
    for row in spamreader:
        d_exer_lapse_time[row[0].strip()]=float(row[1])

    csvfile=open(feature_dir+'\\UN_pair_dists_sample_num_crt.csv','rb') #file_analysis/user_num_and_order
    spamreader = csv.reader(csvfile, delimiter=',')
    d_pair_dist_crt={}
    for row in spamreader:
        d_pair_dist_crt[row[0].strip()]=[float(x) for x in row[1:1+effective_exer_num]]


    csvfile=open(feature_dir+'\\AO_pair_user_num.csv','rb') #feature_extraction/user_num_and_order
    spamreader = csv.reader(csvfile, delimiter=',')
    d_pair_usr_num={}
    for row in spamreader:
        d_pair_usr_num[row[1].strip()]=[float(x) for x in row[2:2+exer_num]]

    csvfile=open(feature_dir+'\\AO_pair_crt_num_sum.csv','rb') #feature_extraction/user_num_and_order
    spamreader = csv.reader(csvfile, delimiter=',')
    d_pair_crt_num_sum={}
    for row in spamreader:
        d_pair_crt_num_sum[row[1].strip()]=[float(x) for x in row[2:2+exer_num]]


    csvfile=open(feature_dir+'\\AO_pair_time_diff.csv','rb') #feature_extraction/user_num_and_order
    spamreader = csv.reader(csvfile, delimiter=',')
    d_pair_time_diff={}
    for row in spamreader:
        d_pair_time_diff[row[1].strip()]=[float(x) for x in row[2:2+exer_num]]

    csvfile=open(feature_dir+'\\KM_pair_location_dist.csv','rb') #feature_extraction/knowledge_maps
    spamreader = csv.reader(csvfile, delimiter=',')
    d_pair_location_dist={}
    for row in spamreader:
        d_pair_location_dist[row[0].strip()]=[float(x) for x in row[1:1+effective_exer_num]]

    csvfile=open(feature_dir+'\\KT_sibling_list.csv','rb') # feature_extraction/knowledge_maps
    spamreader = csv.reader(csvfile, delimiter=',')
    d_pair_sibling={}
    for row in spamreader:
        d_pair_sibling[row[1].strip()]=[float(x) for x in row[2:2+exer_num]]

    csvfile=open(feature_dir+'\\ET_pair_exer_name_dist.csv','rb') # feature_extraction/exer_titles
    spamreader = csv.reader(csvfile, delimiter=',')
    d_pair_name_dist={}
    for row in spamreader:
        d_pair_name_dist[row[1].strip()]=[float(x) for x in row[2:2+effective_exer_num]]

#     csvfile=open('..\\output\\ET_pair_exer_chinese_name_dist.csv','rb') #file_analysis/exer_name_dist
    csvfile=open(feature_dir+'\\ET_pair_exer_chinese_name_dist.csv','rb') #feature_extraction/exer_titles
    spamreader = csv.reader(csvfile, delimiter=',')
    d_pair_c_name_dist={}
    for row in spamreader:
        d_pair_c_name_dist[row[1].strip()]=[float(x) for x in row[2:2+effective_exer_num]]

    csvfile=open(feature_dir+'\\ET_pair_exer_name_dist_decomposed.csv','rb') #feature_extraction/exer_titles
    spamreader = csv.reader(csvfile, delimiter=',')
    d_pair_name_dist_d={}
    for row in spamreader:
        d_pair_name_dist_d[row[1].strip()]=[float(x) for x in row[2:2+effective_exer_num]]

    csvfile=open(feature_dir+'\\features_from_label.csv','rb') #file_analysis/compute_label_features
    spamreader = csv.reader(csvfile, delimiter=',')
    l_usr_num=[-1]*exer_num
    l_crct_num=[-1]*exer_num
    l_crct=[-1]*exer_num
    l_tt_avg=[-1]*exer_num
    l_crct_num_sum=[-1]*exer_num
    l_tt_avg_crt=[-1]*exer_num
    l_tt_crt1=[-1]*exer_num
    i=0
    row=spamreader.next()
    for row in spamreader:
        ind=int(row[0])
        l_usr_num[ind]=float(row[1])
        l_crct_num[ind]=float(row[2])
        l_crct[ind]=float(row[3])
        l_tt_avg[ind]=float(row[4])
        l_crct_num_sum[ind]=float(row[5])
        if len(row)>6:
            l_tt_avg_crt[ind]=float(row[6])
            l_tt_crt1[ind]=float(row[7])
        else:
            l_tt_avg_crt[ind]=0
            l_tt_crt1[ind]=0

    return udir_dist,rdir_dist,dir_dist,d_c1,d_c_last,d_total_num_mean,d_total_num_median,d_total_num_var,d_total_num_sum,d_unum,d_exer_lapse_time,d_location_x,d_location_y,d_how_fast,d_i,d_o,d_pair_fw,d_max_w,d_pair_dist_crt,d_pair_usr_num,d_pair_crt_num_sum,d_pair_time_diff,d_pair_location_dist,d_pair_sibling,d_pair_name_dist,d_pair_c_name_dist,d_pair_name_dist_d,l_usr_num,l_crct_num,l_crct,l_tt_avg,l_crct_num_sum,l_tt_avg_crt,l_tt_crt1

def concatenate_files(file_1_name,file_2_name,output_file_name):
    with open(output_file_name, 'w') as outfile:
        with open(file_1_name) as infile:
            outfile.write(infile.read())
        with open(file_2_name) as infile:
            outfile.write(infile.read())



def regression_testing(data_location,feature_dir,inter_dir,val_dir,modeling_dir,exer_num,effective_exer_num):
##    total_sample_num=file_len(data_location+'\\collected_gt_testing.csv')

    udir_dist,rdir_dist,dir_dist,d_c1,d_c_last,d_total_num_mean, \
    d_total_num_median,d_total_num_var,d_total_num_sum,d_unum,d_exer_lapse_time, \
    d_location_x,d_location_y,d_how_fast,d_i,d_o,d_pair_fw,d_max_w, \
    d_pair_dist_crt,d_pair_usr_num,d_pair_crt_num_sum,d_pair_time_diff, \
    d_pair_location_dist,d_pair_sibling,d_pair_name_dist,d_pair_c_name_dist, \
    d_pair_name_dist_d,l_usr_num,l_crct_num,l_crct,l_tt_avg,l_crct_num_sum,l_tt_avg_crt,l_tt_crt1=load_all_features(data_location,inter_dir,modeling_dir,feature_dir,exer_num,effective_exer_num)

    total_sample_num=file_len_filtered(data_location+'\\collected_gt_testing.csv',d_i)

    Y=np.zeros((total_sample_num,3),float)
    Y_responses_num=np.zeros((total_sample_num),int)

    X_content_names=["exer_name_dist","exer_c_name_dist","exer_name_dist_d"]
    X_content=np.zeros((total_sample_num,len(X_content_names)),float)

    X_structure_names=["udir","rdir","dir","is_parent","is_sibling"]
    X_structure=np.zeros((total_sample_num,len(X_structure_names)),float)

    X_loc_names=["location_dist","df_location_x","df_location_y"]
    X_loc=np.zeros((total_sample_num,len(X_loc_names)),float)

    X_usr_num_names=["df_unum_time_norm","rt_unum_time_norm","usr_num_dist_crt"]
    X_usr_num=np.zeros((total_sample_num,len(X_usr_num_names)),float)

    X_num_exer_taken_names=["df_tn_sum_time_norm","rt_tn_sum_time_norm","df_crt_num","rt_crt_num"]
    X_num_exer_taken=np.zeros((total_sample_num,len(X_num_exer_taken_names)),float)

    X_order_names=["usr_num_rt_12","usr_num_rt_21","rt_prev_usr_num","crt_num_rt_12","crt_num_rt_12","rt_prev_crt_num"]
    X_order=np.zeros((total_sample_num,len(X_order_names)),float)

    X_correct_names=["df_c1.crt","rt_c1.crt","df_cl.crt","rt_cl.crt","df_crt","rt_crt"]
    X_correct=np.zeros((total_sample_num,len(X_correct_names)),float)
    X_time_taken_names=["df_tt_avg","rt_tt_avg","df_tt_avg_crt","rt_tt_avg_crt","df_tt_crt1","rt_tt_crt1"]
    X_time_taken=np.zeros((total_sample_num,len(X_time_taken_names)),float)

    X_feature_weight_names=["fw_12","fw_21","df_fw_12_norm","df_fw_21_norm"]
    X_feature_weight=np.zeros((total_sample_num,len(X_feature_weight_names)),float)

    csvfile=open(data_location+'\\collected_gt_testing.csv','rb')
#     csvfile=open('.\\ken_cp.csv','rb')
#     row=spamreader.next()
    spamreader = csv.reader(csvfile, delimiter=',')
    i=0
    last_e1_name=''
    start_e1_ind=0
    exer_group_ind_arr=[]
    num_invalid_labels=0
    for row in spamreader:
        e1_name=row[0]
        e2_name=row[1]
        if e1_name!=last_e1_name:
            last_e1_name=e1_name
            start_e1_ind=i
            exer_group_ind_arr.append(start_e1_ind)

        if (e1_name not in d_i) or (e2_name not in d_i):
            num_invalid_labels=num_invalid_labels+1
            continue

        i1=d_i[e1_name]
        i2=d_i[e2_name]
#         X_structure[i,8]=0
        if(i2 in udir_dist[i1]):
            X_structure[i,0]=udir_dist[i1][i2]
        else:
            X_structure[i,0]=-1

        if(i2 in rdir_dist[i1]):
            X_structure[i,1]=rdir_dist[i1][i2]
            if X_structure[i,0]==1:
                X_structure[i,3]=1
        else:
            X_structure[i,1]=-1

        if(i2 in dir_dist[i1]):
            X_structure[i,2]=dir_dist[i1][i2]
        else:
            X_structure[i,2]=-1

        X_structure[i,4]=d_pair_sibling[e1_name][d_i[e2_name]]

        X_loc[i,0]=d_pair_location_dist[e1_name][d_o[e2_name]]
        X_loc[i,1]=d_location_x[e2_name]-d_location_x[e1_name]
        X_loc[i,2]=d_location_y[e2_name]-d_location_y[e1_name]

        X_content[i,0]=d_pair_name_dist[e1_name][d_o[e2_name]]
        X_content[i,1]=d_pair_c_name_dist[e1_name][d_o[e2_name]]
        X_content[i,2]=d_pair_name_dist_d[e1_name][d_o[e2_name]]

        X_time_taken[i,0]=l_tt_avg[i2]-l_tt_avg[i1]
        X_time_taken[i,1]=rt_func(l_tt_avg[i2],l_tt_avg[i1])
        X_time_taken[i,2]=l_tt_avg_crt[i2]-l_tt_avg_crt[i1]
        X_time_taken[i,3]=rt_func(l_tt_avg_crt[i2],l_tt_avg_crt[i1])
        X_time_taken[i,4]=l_tt_crt1[i2]-l_tt_crt1[i1]
        X_time_taken[i,5]=rt_func(l_tt_crt1[i2],l_tt_crt1[i1])

        usr_num_1=d_pair_usr_num[e1_name][i2]
        usr_num_2=d_pair_usr_num[e2_name][i1]

        X_order[i,0]=usr_num_1/l_usr_num[i1]
        X_order[i,1]=usr_num_2/l_usr_num[i2]
        if(usr_num_1+usr_num_2!=0):
            X_order[i,2]=float(usr_num_2)/(usr_num_1+usr_num_2)


        crt_num_1=d_pair_crt_num_sum[e1_name][i2]
        crt_num_2=d_pair_crt_num_sum[e2_name][i1]
        X_order[i,3]=crt_num_1/l_crct_num_sum[i1]
        X_order[i,4]=crt_num_2/l_crct_num_sum[i2]
        if(crt_num_1+crt_num_2!=0):
            X_order[i,5]=float(crt_num_2)/(crt_num_1+crt_num_2)


        X_feature_weight[i,0]=d_pair_fw[e1_name][i2]
        X_feature_weight[i,1]=d_pair_fw[e2_name][i1]
        if d_max_w[e1_name]!=0:
            X_feature_weight[i,2]=d_pair_fw[e1_name][i2]/d_max_w[e1_name]
        if d_max_w[e2_name]!=0:
            X_feature_weight[i,3]=d_pair_fw[e2_name][i1]/d_max_w[e2_name]

        X_correct[i,0]=d_c1[e2_name]-d_c1[e1_name]
        X_correct[i,1]=rt_func(d_c1[e2_name],d_c1[e1_name])
        X_correct[i,2]=d_c_last[e2_name]-d_c_last[e1_name]
        X_correct[i,3]=rt_func(d_c_last[e2_name],d_c_last[e1_name])
        X_correct[i,4]=l_crct[i2]-l_crct[i1]
        X_correct[i,5]=rt_func(l_crct[i2],l_crct[i1])


        X_num_exer_taken[i,0]=d_total_num_sum[e2_name]/d_exer_lapse_time[e2_name]-d_total_num_sum[e1_name]/d_exer_lapse_time[e1_name]
        X_num_exer_taken[i,1]=rt_func(d_total_num_sum[e2_name]/d_exer_lapse_time[e2_name],d_total_num_sum[e1_name]/d_exer_lapse_time[e1_name])
##        X_num_exer_taken[i,0]=d_total_num_sum[e2_name]-d_total_num_sum[e1_name]
##        X_num_exer_taken[i,1]=rt_func(d_total_num_sum[e2_name],d_total_num_sum[e1_name])
        X_num_exer_taken[i,2]=l_crct_num[i2]-l_crct_num[i1]
        X_num_exer_taken[i,3]=rt_func(l_crct_num[i2],l_crct_num[i1])


        X_usr_num[i,0]=d_unum[e2_name]/d_exer_lapse_time[e2_name]-d_unum[e1_name]/d_exer_lapse_time[e1_name]
        X_usr_num[i,1]=rt_func(d_unum[e2_name]/d_exer_lapse_time[e2_name],d_unum[e1_name]/d_exer_lapse_time[e1_name])
##        X_usr_num[i,0]=d_unum[e2_name]-d_unum[e1_name]
##        X_usr_num[i,1]=rt_func(d_unum[e2_name],d_unum[e1_name])
        X_usr_num[i,2]=d_pair_dist_crt[e1_name][d_o[e2_name]]

        Y[i,0]=float(row[2])
        Y[i,1]=float(row[4])
        Y[i,2]=float(row[6])
        Y_responses_num[i]=len(row[7])/2

        i=i+1

    exer_group_ind_arr.append(i)

    print "invalid exercise numbers:" + str(num_invalid_labels)

#     if i!=total_sample_num:
#         print "warning! total_sample_num setting is error"
#         sys.exit()

    X_training = np.genfromtxt(inter_dir+"\\training_data_X.csv", delimiter=',')
    Y_training = np.genfromtxt(inter_dir+"\\training_data_Y.csv", delimiter=',')

    X_testing=np.concatenate((X_feature_weight,X_order,X_usr_num,X_time_taken,X_correct,X_num_exer_taken,X_structure,X_content,X_loc),1)
    X_names=X_feature_weight_names+X_order_names+X_usr_num_names+X_time_taken_names+X_correct_names+X_num_exer_taken_names+X_structure_names+X_content_names+X_loc_names

    X_all=np.concatenate((X_training, X_testing), axis=0)
    Y_all=np.concatenate((Y_training,Y))
    np.savetxt(inter_dir+"\\all_data_X.csv", X_all, delimiter=",")
    np.savetxt(inter_dir+"\\all_data_Y.csv", Y_all, delimiter=",")

    min_max_scaler = preprocessing.MinMaxScaler()
#     print X_training.shape
#     print X_testing.shape
##    X_all=np.concatenate((X_training, X_testing), axis=0)
    min_max_scaler = preprocessing.MinMaxScaler()
    min_max_scaler.fit(X_all)
    X_training=min_max_scaler.transform(X_training)
    X_testing=min_max_scaler.transform(X_testing)



#     Y_norm = min_max_scaler.fit_transform(Y)

    clf_5 = NuSVR()
##    clf_3 = linear_model.BayesianRidge()
    clf_2 = RandomForestRegressor(max_depth=4,min_samples_split=10,n_estimators=100)
    clf_4 = GradientBoostingRegressor(max_depth=3, n_estimators=100)
    clf_1 = linear_model.LinearRegression()

    f_out=open(val_dir+"\\testing_results.csv","w")

    rounding_opt=0
    if(rounding_opt==1):
        Y_de_mean=Y[:,0]-round(Y[:,0].mean())
        relation_rms=mean_sqaure(Y_de_mean)
        Y_de_mean=Y[:,1]-round(Y[:,1].mean())
        difficulty_rms=mean_sqaure(Y_de_mean)
        Y_de_mean=Y[:,2]-round(Y[:,2].mean())
        prerequisite_rms=mean_sqaure(Y_de_mean)
    else:
        Y_de_mean=Y[:,0]-Y[:,0].mean()
        relation_rms=mean_sqaure(Y_de_mean)
        Y_de_mean=Y[:,1]-Y[:,1].mean()
        difficulty_rms=mean_sqaure(Y_de_mean)
        Y_de_mean=Y[:,2]-Y[:,2].mean()
        prerequisite_rms=mean_sqaure(Y_de_mean)

    use_PCA=0

    f_out.write("NuSVR RSE similarity, RSE difficulty, RSE prerequisite,")
    f_out.write("Random Forest RSE similarity, RSE difficulty, RSE prerequisite,")
    f_out.write("Gradient Boosting (GB) RSE similarity, RSE difficulty, RSE prerequisite,")
    f_out.write("Linear Regression RSE similarity, RSE difficulty, RSE prerequisite,")
    f_out.write("PCR RSE similarity, RSE difficulty, RSE prerequisite,")

    f_out.write("NuSVR Spearman rho similarity, rho difficulty, rho prerequsite, Kendalltau similarity, tau difficulty, tau prerequisite,")
    f_out.write("Random Forest Spearman rho similarity, rho difficulty, rho prerequsite, Kendalltau similarity, tau difficulty, tau prerequisite,")
    f_out.write("Gradient Boosting (GB) Spearman rho similarity, rho difficulty, rho prerequsite, Kendalltau similarity, tau difficulty, tau prerequisite,")
    f_out.write("Linear Regression Spearman rho similarity, rho difficulty, rho prerequsite, Kendalltau similarity, tau difficulty, tau prerequisite,")
    f_out.write("PCR Spearman rho similarity, rho difficulty, rho prerequsite, Kendalltau similarity, tau difficulty, tau prerequisite\n")
    
    RSE_eval(f_out,clf_5,X_training,X_testing,Y,Y_training,relation_rms,difficulty_rms,prerequisite_rms,use_PCA,rounding_opt)
##    RSE_eval(f_out,clf_3,X_training,X_testing,Y,Y_training,relation_rms,difficulty_rms,prerequisite_rms,use_PCA,rounding_opt)
    RSE_eval(f_out,clf_2,X_training,X_testing,Y,Y_training,relation_rms,difficulty_rms,prerequisite_rms,use_PCA,rounding_opt)
    RSE_eval(f_out,clf_4,X_training,X_testing,Y,Y_training,relation_rms,difficulty_rms,prerequisite_rms,use_PCA,rounding_opt)
    RSE_eval(f_out,clf_1,X_training,X_testing,Y,Y_training,relation_rms,difficulty_rms,prerequisite_rms,use_PCA,rounding_opt)
    RSE_eval(f_out,clf_1,X_training,X_testing,Y,Y_training,relation_rms,difficulty_rms,prerequisite_rms,1,rounding_opt)

    rank_eval(f_out,clf_5,X_training,X_testing,Y_training,Y,exer_group_ind_arr,use_PCA,rounding_opt)
##    rank_eval(f_out,clf_3,X_training,X_testing,Y_training,Y,exer_group_ind_arr,use_PCA,rounding_opt)
    rank_eval(f_out,clf_2,X_training,X_testing,Y_training,Y,exer_group_ind_arr,use_PCA,rounding_opt)
    rank_eval(f_out,clf_4,X_training,X_testing,Y_training,Y,exer_group_ind_arr,use_PCA,rounding_opt)
    rank_eval(f_out,clf_1,X_training,X_testing,Y_training,Y,exer_group_ind_arr,use_PCA,rounding_opt)
    rank_eval(f_out,clf_1,X_training,X_testing,Y_training,Y,exer_group_ind_arr,1,rounding_opt)

    f_out.close()

    concatenate_files(data_location+'\\collected_gt.csv',data_location+'\\collected_gt_testing.csv',data_location+'\\collected_gt_all.csv')


#     clf_2 = RandomForestRegressor(max_depth=4,min_samples_split=10,n_estimators=100)
#     group_ind=np.arange(X_all.shape[1]+1)
#     show_f_weight(clf_2,X_all,Y_all[:,0],X_names,group_ind,1,0,'Similarity')
#     show_f_weight(clf_2,X_all,Y_all[:,1],X_names,group_ind,2,0,'Difficulty')
#     show_f_weight(clf_2,X_all,Y_all[:,2],X_names,group_ind,3,0,'Prerequisite')
#     show_f_weight(clf_2,X_all,Y_all[:,0],X_names,group_ind,4,1,'Similarity')
#     show_f_weight(clf_2,X_all,Y_all[:,1],X_names,group_ind,5,1,'Difficulty')
#     show_f_weight(clf_2,X_all,Y_all[:,2],X_names,group_ind,6,1,'Prerequisite')
#     len_arr=[0,len(X_feature_weight_names),len(X_order_names),len(X_usr_num_names),len(X_time_taken_names),len(X_correct_names),len(X_num_exer_taken_names),len(X_structure_names),len(X_content_names),len(X_loc_names)]
#     group_ind=np.cumsum(len_arr)
# #     X_names_group=["Feature_weights","Order","Usr_num","Time_taken","Correct","Num_exer_taken","Structure","Content","Locations"]
# #     X_names_group=["User Performance Prediction","User Answering Order","#User Taking Exercises","Answering Time","Answering Accuracy","#Problems Taken in Exercises","Prerequisite Knowledge Tree","Exercise Titles","Locations in the Knowledge Map"]
#     X_names_group=["Student Modeling","User Answering Order","#User Taking Exercises","Answering Time","Answering Accuracy","#Problems Taken in Exercises","Prerequisite Knowledge Tree","Exercise Titles","Locations in the Knowledge Map"]
#     show_f_weight(clf_2,X_all,Y_all[:,0],X_names_group,group_ind,7,1,'Similarity')
#     show_f_weight(clf_2,X_all,Y_all[:,1],X_names_group,group_ind,8,1,'Difficulty')
#     show_f_weight(clf_2,X_all,Y_all[:,2],X_names_group,group_ind,9,1,'Prerequisite')
#     plt.show()


if __name__ == '__main__':

    effective_exer_num=577
    exer_num=837
#     total_sample_num=823
    data_location="..\\..\\input"
    feature_dir="..\\..\\intermediate\\feature_files"
    inter_dir="..\\..\\intermediate"
    val_dir="..\\..\\validation"
    modeling_dir="..\\..\\output\\student_modeling"
    regression_testing(data_location,feature_dir,inter_dir,val_dir,modeling_dir,exer_num,effective_exer_num)
