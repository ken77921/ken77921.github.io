'''
Created on Jan 29, 2015

@author: Ken-MMNlab
'''

from collections import defaultdict
import csv
import ast
import math
import numpy as np
from datetime import datetime
import random
import scipy.stats.stats as sci_st

from sklearn.decomposition import PCA
from sklearn import preprocessing
from sklearn.ensemble import GradientBoostingRegressor

import matplotlib.pyplot as plt
import sys

# effective_exer_num=370
# exer_num=493
# total_sample_num=744
# feature_dim=14

def rt_func(a,b):
    if(a<=0 or b<=0):
        print('rt_func error')
        sys.exit(-1)
    return math.log(a)-math.log(b)

def load_dict_from_csv(file_name,exer_num):
    dict_out = range(exer_num)
    for key, val in csv.reader(open(file_name)):
        dict_out[int(key)] = ast.literal_eval(val)
    return dict_out

def qmean(l_num):
    return math.sqrt(sum(n*n for n in l_num)/len(l_num))

def mean_sqaure(l_num):
    return sum(n*n for n in l_num)/len(l_num)

def direct_predict(clf,X_train,Y_train,X_test):
    Y_pred=np.zeros((X_test.shape[0],3),float)
    scaler=preprocessing.MinMaxScaler()
    Y_norm_1 = scaler.fit_transform(Y_train[:,0].reshape((-1,1)))
    Y_pred_norm_1=clf.fit(X_train, Y_norm_1.reshape(-1)).predict(X_test)
    Y_pred[:,0] = scaler.inverse_transform(Y_pred_norm_1)

    Y_norm_2 = scaler.fit_transform(Y_train[:,1].reshape((-1,1)))
    Y_pred_norm_2=clf.fit(X_train, Y_norm_2.reshape(-1)).predict(X_test)
    Y_pred[:,1] = scaler.inverse_transform(Y_pred_norm_2)

    Y_norm_3 = scaler.fit_transform(Y_train[:,2].reshape((-1,1)))
    Y_pred_norm_3=clf.fit(X_train, Y_norm_3.reshape(-1)).predict(X_test)
    Y_pred[:,2] = scaler.inverse_transform(Y_pred_norm_3)

    return Y_pred

##def PCA_predict(clf,X_train,Y_train,X_test):
##    pca = PCA(n_components=3)
##    Y_pca_train = pca.fit_transform(Y_train)
##    Y_pca_pred=np.zeros((X_test.shape[0],3),float)
##    Y_pca_pred[:,0] = clf.fit(X_train, Y_pca_train[:,0]).predict(X_test)
##    Y_pca_pred[:,1] = clf.fit(X_train, Y_pca_train[:,1]).predict(X_test)
##    Y_pca_pred[:,2] = clf.fit(X_train, Y_pca_train[:,2]).predict(X_test)
##    Y_norm_pred=pca.inverse_transform(Y_pca_pred)
##    return Y_norm_pred

def check_NaN(X,error_str):
    if(np.isnan(np.sum(X))):
        print(error_str)


def load_all_features(data_location,inter_dir,modeling_dir,feature_dir,exer_num,effective_exer_num):
    udir_dist=load_dict_from_csv(inter_dir+"\\udir_dist.txt",exer_num) #student_modeling/build_distances.py
    rdir_dist=load_dict_from_csv(inter_dir+"\\rdir_dist.txt",exer_num) #student_modeling/build_distances.py
    dir_dist=load_dict_from_csv(inter_dir+"\\dir_dist.txt",exer_num) #student_modeling/build_distances.py

    csvfile=open(data_location+'\\pretest_exx.csv','rb')
    spamreader = csv.reader(csvfile, delimiter=',')
    row=spamreader.next()
    d_c1={}
    d_c_last={}
    d_total_num_mean={}
    d_total_num_median={}
    d_total_num_var={}
    d_total_num_sum={}
    d_unum={}
    for row in spamreader:
        if float(row[8])<2:
            continue
        d_c1[row[1]]=float(row[2])
        d_c_last[row[1]]=float(row[3])
        d_total_num_mean[row[1]]=float(row[4])
        d_total_num_median[row[1]]=float(row[5])
        d_total_num_var[row[1]]=float(row[6])
        d_total_num_sum[row[1]]=float(row[7])
        d_unum[row[1]]=float(row[8])

    csvfile=open(data_location+'\\junyi_Exercise.csv','rb')
    spamreader = csv.reader(csvfile, delimiter=',')
##    d_create_time={}
    d_location_x={}
    d_location_y={}
    d_how_fast={}
    row=spamreader.next()
    for row in spamreader:
#         d_create_time[row[8]]=time.strptime(row[3],'%Y-%m-%d %H:%M:%S.').time()
##        d_create_time[row[8]]=datetime.strptime(row[3], '%Y-%m-%d %H:%M:%S.%f')
        d_location_x[row[8]]=int(row[5])
        d_location_y[row[8]]=int(row[16])
        d_how_fast[row[8]]=float(row[12])


    csvfile=open(modeling_dir+'\\classifier_results_fw_sum.txt','rb') #student_modeling/regression_new_feature.py and dist_gmm_to_nodes
    spamreader = csv.reader(csvfile, delimiter=',')
    d_i={}
    d_o={}
    d_pair_fw={}
    d_max_w={}
    d_i2n_effective={}
    i=0
    for row in spamreader:
        d_i2n_effective[int(row[0])]=row[1].strip()
        d_i[row[1].strip()]=int(row[0])
        d_o[row[1].strip()]=i
        d_pair_fw[row[1].strip()]=[float(x) for x in row[2:2+exer_num]]
        d_max_w[row[1].strip()]=max(d_pair_fw[row[1].strip()])
        i=i+1

    csvfile=open(feature_dir+'\\UN_exer_lapse_time.csv','rb') #file_analysis/user_num_and_order
    spamreader = csv.reader(csvfile, delimiter=',')
    d_exer_lapse_time={}
    for row in spamreader:
        d_exer_lapse_time[row[0].strip()]=float(row[1])

    csvfile=open(feature_dir+'\\UN_pair_dists_sample_num_crt.csv','rb') #file_analysis/user_num_and_order
    spamreader = csv.reader(csvfile, delimiter=',')
    d_pair_dist_crt={}
    for row in spamreader:
        d_pair_dist_crt[row[0].strip()]=[float(x) for x in row[1:1+effective_exer_num]]


    csvfile=open(feature_dir+'\\AO_pair_user_num.csv','rb') #feature_extraction/user_num_and_order
    spamreader = csv.reader(csvfile, delimiter=',')
    d_pair_usr_num={}
    for row in spamreader:
        d_pair_usr_num[row[1].strip()]=[float(x) for x in row[2:2+exer_num]]

    csvfile=open(feature_dir+'\\AO_pair_crt_num_sum.csv','rb') #feature_extraction/user_num_and_order
    spamreader = csv.reader(csvfile, delimiter=',')
    d_pair_crt_num_sum={}
    for row in spamreader:
        d_pair_crt_num_sum[row[1].strip()]=[float(x) for x in row[2:2+exer_num]]


    csvfile=open(feature_dir+'\\AO_pair_time_diff.csv','rb') #feature_extraction/user_num_and_order
    spamreader = csv.reader(csvfile, delimiter=',')
    d_pair_time_diff={}
    for row in spamreader:
        d_pair_time_diff[row[1].strip()]=[float(x) for x in row[2:2+exer_num]]

    csvfile=open(feature_dir+'\\KM_pair_location_dist.csv','rb') #feature_extraction/knowledge_maps
    spamreader = csv.reader(csvfile, delimiter=',')
    d_pair_location_dist={}
    for row in spamreader:
        d_pair_location_dist[row[0].strip()]=[float(x) for x in row[1:1+effective_exer_num]]

    csvfile=open(feature_dir+'\\KT_sibling_list.csv','rb') # feature_extraction/knowledge_maps
    spamreader = csv.reader(csvfile, delimiter=',')
    d_pair_sibling={}
    for row in spamreader:
        d_pair_sibling[row[1].strip()]=[float(x) for x in row[2:2+exer_num]]

    csvfile=open(feature_dir+'\\ET_pair_exer_name_dist.csv','rb') # feature_extraction/exer_titles
    spamreader = csv.reader(csvfile, delimiter=',')
    d_pair_name_dist={}
    for row in spamreader:
        d_pair_name_dist[row[1].strip()]=[float(x) for x in row[2:2+effective_exer_num]]

#     csvfile=open('..\\output\\ET_pair_exer_chinese_name_dist.csv','rb') #file_analysis/exer_name_dist
    csvfile=open(feature_dir+'\\ET_pair_exer_chinese_name_dist.csv','rb') #feature_extraction/exer_titles
    spamreader = csv.reader(csvfile, delimiter=',')
    d_pair_c_name_dist={}
    for row in spamreader:
        d_pair_c_name_dist[row[1].strip()]=[float(x) for x in row[2:2+effective_exer_num]]

    csvfile=open(feature_dir+'\\ET_pair_exer_name_dist_decomposed.csv','rb') #feature_extraction/exer_titles
    spamreader = csv.reader(csvfile, delimiter=',')
    d_pair_name_dist_d={}
    for row in spamreader:
        d_pair_name_dist_d[row[1].strip()]=[float(x) for x in row[2:2+effective_exer_num]]

    csvfile=open(feature_dir+'\\features_from_label.csv','rb') #file_analysis/compute_label_features
    spamreader = csv.reader(csvfile, delimiter=',')
    l_usr_num=[-1]*exer_num
    l_crct_num=[-1]*exer_num
    l_crct=[-1]*exer_num
    l_tt_avg=[-1]*exer_num
    l_crct_num_sum=[-1]*exer_num
    l_tt_avg_crt=[-1]*exer_num
    l_tt_crt1=[-1]*exer_num
    i=0
    row=spamreader.next()
    for row in spamreader:
        ind=int(row[0])
        l_usr_num[ind]=float(row[1])
        l_crct_num[ind]=float(row[2])
        l_crct[ind]=float(row[3])
        l_tt_avg[ind]=float(row[4])
        l_crct_num_sum[ind]=float(row[5])
        if len(row)>6:
            l_tt_avg_crt[ind]=float(row[6])
            l_tt_crt1[ind]=float(row[7])
        else:
            l_tt_avg_crt[ind]=0
            l_tt_crt1[ind]=0

    return d_i2n_effective,udir_dist,rdir_dist,dir_dist,d_c1,d_c_last,d_total_num_mean,d_total_num_median,d_total_num_var,d_total_num_sum,d_unum,d_exer_lapse_time,d_location_x,d_location_y,d_how_fast,d_i,d_o,d_pair_fw,d_max_w,d_pair_dist_crt,d_pair_usr_num,d_pair_crt_num_sum,d_pair_time_diff,d_pair_location_dist,d_pair_sibling,d_pair_name_dist,d_pair_c_name_dist,d_pair_name_dist_d,l_usr_num,l_crct_num,l_crct,l_tt_avg,l_crct_num_sum,l_tt_avg_crt,l_tt_crt1



def regression_predict_all(data_location,feature_dir,inter_dir,modeling_dir,output_dir,exer_num,effective_exer_num):
    total_sample_num=effective_exer_num*effective_exer_num

    d_i2n_effective,udir_dist,rdir_dist,dir_dist,d_c1,d_c_last,d_total_num_mean, \
    d_total_num_median,d_total_num_var,d_total_num_sum,d_unum,d_exer_lapse_time, \
    d_location_x,d_location_y,d_how_fast,d_i,d_o,d_pair_fw,d_max_w, \
    d_pair_dist_crt,d_pair_usr_num,d_pair_crt_num_sum,d_pair_time_diff, \
    d_pair_location_dist,d_pair_sibling,d_pair_name_dist,d_pair_c_name_dist, \
    d_pair_name_dist_d,l_usr_num,l_crct_num,l_crct,l_tt_avg,l_crct_num_sum,l_tt_avg_crt,l_tt_crt1=load_all_features(data_location,inter_dir,modeling_dir,feature_dir,exer_num,effective_exer_num)

    

    X_content_names=["exer_name_dist","exer_c_name_dist","exer_name_dist_d"]
    X_content=np.zeros((total_sample_num,len(X_content_names)),float)

    X_structure_names=["udir","rdir","dir","is_parent","is_sibling"]
    X_structure=np.zeros((total_sample_num,len(X_structure_names)),float)

    X_loc_names=["location_dist","df_location_x","df_location_y"]
    X_loc=np.zeros((total_sample_num,len(X_loc_names)),float)

    X_usr_num_names=["df_unum_time_norm","rt_unum_time_norm","usr_num_dist_crt"]
    X_usr_num=np.zeros((total_sample_num,len(X_usr_num_names)),float)

    X_num_exer_taken_names=["df_tn_sum_time_norm","rt_tn_sum_time_norm","df_crt_num","rt_crt_num"]
    X_num_exer_taken=np.zeros((total_sample_num,len(X_num_exer_taken_names)),float)


    X_order_names=["usr_num_rt_12","usr_num_rt_21","rt_prev_usr_num","crt_num_rt_12","crt_num_rt_12","rt_prev_crt_num"]
    X_order=np.zeros((total_sample_num,len(X_order_names)),float)

    X_correct_names=["df_c1.crt","rt_c1.crt","df_cl.crt","rt_cl.crt","df_crt","rt_crt"]
    X_correct=np.zeros((total_sample_num,len(X_correct_names)),float)
    X_time_taken_names=["df_tt_avg","rt_tt_avg","df_tt_avg_crt","rt_tt_avg_crt","df_tt_crt1","rt_tt_crt1"]
    X_time_taken=np.zeros((total_sample_num,len(X_time_taken_names)),float)

    X_feature_weight_names=["fw_12","fw_21","df_fw_12_norm","df_fw_21_norm"]
    X_feature_weight=np.zeros((total_sample_num,len(X_feature_weight_names)),float)


    i=0

    for i1 in range(exer_num):
        if(i1 not in d_i2n_effective):
            continue
        e1_name=d_i2n_effective[i1]

        for i2 in range(exer_num):
            if(i2 not in d_i2n_effective):
                continue
            e2_name=d_i2n_effective[i2]


            if(i2 in udir_dist[i1]):
                X_structure[i,0]=udir_dist[i1][i2]
            else:
                X_structure[i,0]=-1

            if(i2 in rdir_dist[i1]):
                X_structure[i,1]=rdir_dist[i1][i2]
                if X_structure[i,0]==1:
                    X_structure[i,3]=1
            else:
                X_structure[i,1]=-1

            if(i2 in dir_dist[i1]):
                X_structure[i,2]=dir_dist[i1][i2]
            else:
                X_structure[i,2]=-1

            X_structure[i,4]=d_pair_sibling[e1_name][i2]


            X_loc[i,0]=d_pair_location_dist[e1_name][d_o[e2_name]]
            X_loc[i,1]=d_location_x[e2_name]-d_location_x[e1_name]
            X_loc[i,2]=d_location_y[e2_name]-d_location_y[e1_name]

            X_content[i,0]=d_pair_name_dist[e1_name][d_o[e2_name]]
            X_content[i,1]=d_pair_c_name_dist[e1_name][d_o[e2_name]]
            X_content[i,2]=d_pair_name_dist_d[e1_name][d_o[e2_name]]


            X_time_taken[i,0]=l_tt_avg[i2]-l_tt_avg[i1]
            X_time_taken[i,1]=rt_func(l_tt_avg[i2],l_tt_avg[i1])
            X_time_taken[i,2]=l_tt_avg_crt[i2]-l_tt_avg_crt[i1]
            X_time_taken[i,3]=rt_func(l_tt_avg_crt[i2],l_tt_avg_crt[i1])
            X_time_taken[i,4]=l_tt_crt1[i2]-l_tt_crt1[i1]
            X_time_taken[i,5]=rt_func(l_tt_crt1[i2],l_tt_crt1[i1])

            usr_num_1=d_pair_usr_num[e1_name][i2]
            usr_num_2=d_pair_usr_num[e2_name][i1]

            X_order[i,0]=usr_num_1/l_usr_num[i1]
            X_order[i,1]=usr_num_2/l_usr_num[i2]
            if(usr_num_1+usr_num_2!=0):
                X_order[i,2]=float(usr_num_2)/(usr_num_1+usr_num_2)


            crt_num_1=d_pair_crt_num_sum[e1_name][i2]
            crt_num_2=d_pair_crt_num_sum[e2_name][i1]
            X_order[i,3]=crt_num_1/l_crct_num_sum[i1]
            X_order[i,4]=crt_num_2/l_crct_num_sum[i2]
            if(crt_num_1+crt_num_2!=0):
                X_order[i,5]=float(crt_num_2)/(crt_num_1+crt_num_2)


            X_feature_weight[i,0]=d_pair_fw[e1_name][i2]
            X_feature_weight[i,1]=d_pair_fw[e2_name][i1]
            if d_max_w[e1_name]!=0:
                X_feature_weight[i,2]=d_pair_fw[e1_name][i2]/d_max_w[e1_name]
            if d_max_w[e2_name]!=0:
                X_feature_weight[i,3]=d_pair_fw[e2_name][i1]/d_max_w[e2_name]



            X_correct[i,0]=d_c1[e2_name]-d_c1[e1_name]
            X_correct[i,1]=rt_func(d_c1[e2_name],d_c1[e1_name])
            X_correct[i,2]=d_c_last[e2_name]-d_c_last[e1_name]
            X_correct[i,3]=rt_func(d_c_last[e2_name],d_c_last[e1_name])
            X_correct[i,4]=l_crct[i2]-l_crct[i1]
            X_correct[i,5]=rt_func(l_crct[i2],l_crct[i1])

            X_num_exer_taken[i,0]=d_total_num_sum[e2_name]/d_exer_lapse_time[e2_name]-d_total_num_sum[e1_name]/d_exer_lapse_time[e1_name]
            X_num_exer_taken[i,1]=rt_func(d_total_num_sum[e2_name]/d_exer_lapse_time[e2_name],d_total_num_sum[e1_name]/d_exer_lapse_time[e1_name])
##            X_num_exer_taken[i,0]=d_total_num_sum[e2_name]-d_total_num_sum[e1_name]
##            X_num_exer_taken[i,1]=rt_func(d_total_num_sum[e2_name],d_total_num_sum[e1_name])
            X_num_exer_taken[i,2]=l_crct_num[i2]-l_crct_num[i1]
            X_num_exer_taken[i,3]=rt_func(l_crct_num[i2],l_crct_num[i1])


            X_usr_num[i,0]=d_unum[e2_name]/d_exer_lapse_time[e2_name]-d_unum[e1_name]/d_exer_lapse_time[e1_name]
            X_usr_num[i,1]=rt_func(d_unum[e2_name]/d_exer_lapse_time[e2_name],d_unum[e1_name]/d_exer_lapse_time[e1_name])
##            X_usr_num[i,0]=d_unum[e2_name]-d_unum[e1_name]
##            X_usr_num[i,1]=rt_func(d_unum[e2_name],d_unum[e1_name])
            X_usr_num[i,2]=d_pair_dist_crt[e1_name][d_o[e2_name]]


            i=i+1


    X_training = np.genfromtxt(inter_dir+"\\all_data_X.csv", delimiter=',')
    Y_training = np.genfromtxt(inter_dir+"\\all_data_Y.csv", delimiter=',')

##    X_training = np.genfromtxt(inter_dir+"\\training_data_X.csv", delimiter=',')
##    Y_training = np.genfromtxt(inter_dir+"\\training_data_Y.csv", delimiter=',')


    X_testing=np.concatenate((X_feature_weight,X_order,X_usr_num,X_time_taken,X_correct,X_num_exer_taken,X_structure,X_content,X_loc),1)
    X_names=X_feature_weight_names+X_order_names+X_usr_num_names+X_time_taken_names+X_correct_names+X_num_exer_taken_names+X_structure_names+X_content_names+X_loc_names

#     check_NaN(X_feature_weight,X_feature_weight_names)
#     check_NaN(X_order,X_order_names)
#     check_NaN(X_usr_num,X_usr_num_names)
#     check_NaN(X_time_taken,X_time_taken_names)
#     check_NaN(X_correct,X_correct_names)
#     check_NaN(X_num_exer_taken,X_num_exer_taken_names)
#     check_NaN(X_structure,X_structure_names)
#     check_NaN(X_content,X_content_names)

    all_X=np.concatenate((X_training, X_testing), axis=0)
    min_max_scaler = preprocessing.MinMaxScaler()
    min_max_scaler.fit(all_X)
    X_training=min_max_scaler.transform(X_training)
    X_testing=min_max_scaler.transform(X_testing)

    clf = GradientBoostingRegressor(max_depth=3, n_estimators=100)
##    print Y_training[:,1].tolist()
    Y_pred=direct_predict(clf,X_training,Y_training,X_testing)
##    print Y_pred[:,1]
##    print Y_pred[:,1]
#     Y_pred=Y_pred.reshape( (effective_exer_num,effective_exer_num) )


    f_out_1=open(output_dir+"\\regression_similarity_results.csv","w")
    f_out_2=open(output_dir+"\\regression_difficulty_results.csv","w")
    f_out_3=open(output_dir+"\\regression_prerequisite_results.csv","w")
    i=0
    for i1 in range(exer_num):
        if(i1 not in d_i2n_effective):
            continue
        e1_name=d_i2n_effective[i1]
        f_out_1.write(str(i1)+','+e1_name+',')
        f_out_2.write(str(i1)+','+e1_name+',')
        f_out_3.write(str(i1)+','+e1_name+',')
#     for e1_name in d_n_effective:
#         i1=d_n2i[e1_name]
        for i2 in range(exer_num):
            if(i2 not in d_i2n_effective):
                continue
#             e2_name=d_i2n_effective[i2]
            f_out_1.write(str(Y_pred[i,0])+',')
            f_out_2.write(str(Y_pred[i,1])+',')
            f_out_3.write(str(Y_pred[i,2])+',')
            i=i+1
        f_out_1.write('\n')
        f_out_2.write('\n')
        f_out_3.write('\n')

if __name__ == '__main__':
    effective_exer_num=577
    exer_num=837
#     total_sample_num=1131
    data_location="..\\..\\input"
    feature_dir="..\\..\\intermediate\\feature_files"
    inter_dir="..\\..\\intermediate"
    modeling_dir="..\\..\\output\\student_modeling"
    output_dir="..\\..\\output"
    regression_predict_all(data_location,feature_dir,inter_dir,modeling_dir,output_dir,exer_num,effective_exer_num)
