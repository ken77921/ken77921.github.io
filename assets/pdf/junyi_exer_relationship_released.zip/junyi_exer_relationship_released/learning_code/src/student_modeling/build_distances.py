'''
Created on Aug 13, 2014

@author: Ken-MMNlab
'''

import csv
from collections import defaultdict
import numpy as np
import networkx as nx
# import sys

def load_exer_num(data_location):
    exer_num=0
    with open(data_location + '\\pretest_exer_list.csv','rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        row=spamreader.next()
        for row in spamreader:
            if row[7].strip() == 'False':
                continue
            exer_num=exer_num+1
    return exer_num

def load_dict_into_csv(file_name):
    dict_out = {}
    for key, val in csv.reader(open(file_name)):
        dict_out[key] = val
    return dict_out

def write_dict_into_csv(file_name,dict_in):
    w = csv.writer(open(file_name, "w"))
    for key, val in dict_in.items():
        w.writerow([key, val])

def fw(mat_in):
    mat=mat_in
    D=nx.DiGraph(mat)
    length=nx.all_pairs_shortest_path_length(D)
#     new_mat=np.array(length)
#     mat_n=mat.shape[0]
#     for i in range(mat_n):
#         sys.stdout.write('.')
#         mat=np.minimum(mat,mat[i,:]+mat[:,i])

#     for k in range(mat_n):
#         sys.stdout.write('.')
#         for i in range(mat_n):
#             for j in range(mat_n):
#                 mat[i][j]=min(mat[i][j],mat[i][k]+mat[k][j])
    return length


# data_location="C:\Users\Ken-MMNlab\Desktop\MMNlab_svn\junyi\data"

def build_distances(data_location,output_dir):
    id_2_name=defaultdict(int)
    name_2_id={}
    with open(data_location + '\\pretest_exer_list.csv','rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        row=spamreader.next()
        for row in spamreader:
            name_2_id[row[1].replace('"','')]=int(row[0].replace('"',''))-1
            id_2_name[int(row[0].replace('"',''))-1]=row[1].replace('"','')
        exer_num=len(name_2_id)
    #     print name_2_id

    # direct_mat=np.ones((exer_num,exer_num),int)+float("inf")
    direct_mat=np.zeros((exer_num,exer_num),int)
    with open(data_location + '\\junyi_Exercise.csv','rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        row=spamreader.next()
        for row in spamreader:
            if row[7].strip() == 'FALSE' or row[7].strip() == 'False' :
                continue
            parstr=row[9].replace('[','')
            parstr=parstr.replace(']','')
            if len(parstr) == 0:
                continue
            tok=[ x.strip() for x in parstr.split(',')]
            for par in tok:
                if par not in name_2_id:
                    continue
                direct_mat[name_2_id[par],name_2_id[row[8]]]=1

    rdir_mat=direct_mat.transpose()
    udir_mat=rdir_mat+direct_mat

    all_ind=np.array(range(exer_num))
    remaining_ind=all_ind[udir_mat.sum(axis=0)>0]
    f_remaining=open(output_dir+"\\have_links_list.txt","w")
    for ind in remaining_ind:
        f_remaining.write(str(ind)+","+id_2_name[ind]+"\n")
##    print remaining_ind

    dir_dist=fw(direct_mat)
    rdir_dist=fw(rdir_mat)
    udir_dist=fw(udir_mat)

    write_dict_into_csv(output_dir+"\\dir_dist.txt",dir_dist)
    write_dict_into_csv(output_dir+"\\rdir_dist.txt",rdir_dist)
    write_dict_into_csv(output_dir+"\\udir_dist.txt",udir_dist)

    # np.savetxt(".\\input\\direct_mat.txt",direct_mat,fmt='%d',delimiter=',')

if __name__ == '__main__':
    data_location="..\..\input"
    output_dir="..\..\intermediate"
    build_distances(data_location,output_dir)
