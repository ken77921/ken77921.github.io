'''
Created on Aug 14, 2014

@author: Ken-MMNlab
'''

import operator
# import sys
import csv
import ast
import numpy as np
from sklearn.mixture import GMM
from sklearn import preprocessing
from sklearn import linear_model
from sklearn.cross_validation import cross_val_score
from collections import defaultdict
# from sklearn.externals import joblib
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import RandomForestClassifier
# from sklearn.svm import NuSVR
# from sklearn.ensemble import GradientBoostingRegressor
# from sklearn.ensemble import GradientBoostingClassifier
# from sklearn import tree
import random
import os
# from sklearn.tree import DecisionTreeRegressor
# from sklearn.ensemble import AdaBoostRegressor
##from sklearn.decomposition import PCA
##from sklearn.neighbors import KNeighborsRegressor
##from sklearn.svm import SVR

max_label_num=15000
forest_tree_num=300
GMM_max_sample=3000

def file_len(fname):
    i=0
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1

# usr_num=44169

def GMM_compression(X_raw_dense):
    X_T=X_raw_dense.transpose()
    sample_num,f_dim=X_raw_dense.shape
    X_comp_acc=np.zeros((sample_num,0))-1
    belonging_prob_acc=np.zeros((f_dim,0))-1
    component_num=32
    while component_num>1:
        GMM_clustering=GMM(n_components=component_num)
        GMM_clustering.fit(X_T)
        belonging_prob=GMM_clustering.predict_proba(X_T)
        X_compressed=np.dot(X_raw_dense, belonging_prob)
        X_comp_acc=np.column_stack((X_comp_acc,X_compressed))
        belonging_prob_acc=np.column_stack((belonging_prob_acc,belonging_prob))
        component_num=component_num/2
#     GMM_clustering=GMM(n_components=32)
#     GMM_clustering.fit(X_T)
#     belonging_prob=GMM_clustering.predict_proba(X_T)
#     X_compressed=np.dot(X_raw_dense, belonging_prob)
#     return X_compressed
    return X_comp_acc,belonging_prob_acc

def load_dict_into_csv(file_name,exer_num):
    dict_out = range(exer_num)
    for key, val in csv.reader(open(file_name)):
        dict_out[int(key)] = ast.literal_eval(val)
    return dict_out

def read_classify_label(classify_file_name,label_num):
    y_class=np.zeros((label_num),int)
    with open(classify_file_name,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
    ##    row=spamreader.next()
        i=0
        for row in spamreader:
            y_class[i]=int(row[1])
            i=i+1
            if(i>=label_num):
                break
            
    return y_class

def read_label(label_file_name,label_num,usr_num):
    
    d=[-1]*usr_num
    y=np.zeros((label_num),float)
    with open(label_file_name,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
    ##    row=spamreader.next()
        i=0
        for row in spamreader:
            d[int(row[0])]=i
            y[i]=float(row[2])
            i=i+1
            if(i>=label_num):
                break
    return y,d

def save_feature_weights(r_ind,dim,importance,std,f_handle):
    output_importance=np.zeros((dim))
    output_std=np.zeros((dim))

    output_importance[r_ind]=importance
    output_std[r_ind]=std

    for i in output_importance:
        f_handle.write(str(i)+", ")

    f_handle.write("std, ")
    for i in output_std:
        f_handle.write(str(i)+", ")

def hier_acc_feature(X_dir_sum,X_dir_num):

#     X_dir_sum[X_dir_num==0]=0
    u_num,f_num=X_dir_sum.shape
    f_num_target=int(f_num/2)
    empty_out=np.zeros((X_dir_num.shape[0],0))
    X_sum_acc_all=empty_out
    X_num_acc_all=empty_out
    if f_num_target<=1:
        return empty_out-1,empty_out-1
    while f_num_target>1:
#         print f_num_target
        compress_factor=int(f_num/f_num_target)
        range_f=compress_factor*f_num_target
        X_sum_acc=np.zeros((u_num,f_num_target))
        X_num_acc=np.zeros((u_num,f_num_target))
        for i in range(compress_factor):
            get_ind=np.arange(i, range_f-compress_factor+i+1, compress_factor)
            X_sum_acc=X_sum_acc+X_dir_sum[:,get_ind]
            X_num_acc=X_num_acc+X_dir_num[:,get_ind]
        X_sum_acc_all=np.column_stack((X_sum_acc_all,X_sum_acc))
        X_num_acc_all=np.column_stack((X_num_acc_all,X_num_acc))
        f_num_target=f_num_target/2
    X_mean_acc_all=X_sum_acc_all/(X_num_acc_all+0.000000000000000001)
    X_sum_acc_all[X_num_acc_all==0]=-1
    X_mean_acc_all[X_num_acc_all==0]=-1
#     print "acc" + str(X_sum_acc_all.shape[1])
    return X_sum_acc_all,X_mean_acc_all

def acc_dir_feature(dir_dist,exer_id,X):
    sample_num=X.shape[0]
    dir_dist_others=dir_dist[exer_id]
    max_dist=max(dir_dist_others.iteritems(), key=operator.itemgetter(1))[1]

    X_dir_sum=np.zeros((sample_num,max_dist))
    X_dir_num=np.zeros((sample_num,max_dist))
    for u in range(sample_num):
        for f in dir_dist_others:
            if X[u,f] == -1 or f == exer_id:
                continue
            f_dist=dir_dist_others[f]-1
            X_dir_sum[u,f_dist]=X_dir_sum[u,f_dist]+X[u,f]
            X_dir_num[u,f_dist]=X_dir_num[u,f_dist]+1

    X_dir_mean=X_dir_sum/(X_dir_num+0.0000000000000001)
    X_sum_acc_all,X_mean_acc_all=hier_acc_feature(X_dir_sum,X_dir_num)
    X_dir_sum[X_dir_num==0]=-1
    X_dir_mean[X_dir_num==0]=-1
    X_dir_all=np.column_stack((X_dir_sum,X_dir_mean,X_sum_acc_all,X_mean_acc_all))
    return X_dir_all,max_dist

def preprocess_data(X_full,miss_rep):
    have_val_feature=X_full.mean(axis=0)>-1
    X_have_val=X_full[:,have_val_feature]
    remaining_ind=np.arange(0,X_full.shape[1])
    remaining_ind=remaining_ind[have_val_feature]

    imp=preprocessing.Imputer(missing_values=miss_rep)
    imp.fit(X_have_val)
    X_dense=imp.transform(X_have_val)
    return X_dense,X_have_val,remaining_ind

def read_feature(feature_file_name,label_num,d,exer_num):
    X_temp=np.zeros((label_num,exer_num),float)-1
    X_time=np.zeros((label_num,exer_num),float)-1
    X_exer_num=np.zeros((label_num,exer_num),float)-1
    with open(feature_file_name,'rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        row=spamreader.next()
        for row in spamreader:
            if d[int(row[1])]==-1:
                continue
            X_temp[d[int(row[1])],int(row[3])-1]=float(row[5])
            X_exer_num[d[int(row[1])],int(row[3])-1]=float(row[4])
            X_time[d[int(row[1])],int(row[3])-1]=float(row[6])

        have_val_element=X_temp>-1
        X_correct_num=X_exer_num*X_temp
        X_correct_num[have_val_element==False]=-1
        X_ind=np.zeros((label_num,exer_num),int)
        X_ind[have_val_element]=1
        X_num=X_ind.sum(axis=1)
        have_val_user=X_num>0
    ##    print (X_num==0).nonzero()
    ##    X_sum=X_temp.sum(axis=1)+exer_num-X_num
    ##    X_mean=X_sum/X_num
    ##    X_sum=X_sum[have_val_user]
    ##    X_mean=X_mean[have_val_user]
    ##    print X_sum
    ##    print X_mean
        X_exer_num=X_exer_num[have_val_user,:]
        X_correct_num=X_correct_num[have_val_user,:]
        X_time=X_time[have_val_user,:]
        X_full=X_temp[have_val_user,:]
#         y=y[have_val_user]
    ##    pca = PCA(n_components=50)
    ##    X_pca=pca.fit_transform(X_dense)
    ##    print pca.explained_variance_ratio_.sum()

    ##    col_mean=X.mean(axis=0)
    ##    X=X/(col_mean[np.newaxis,:]+0.00000000000001)
        print X_full.shape

    return X_full,X_correct_num,X_time,X_exer_num,have_val_user

def data_preparation(label_file_name,feature_file_name,label_num,classify_file_name,dir_dist,rdir_dist,udir_dist,exer_id,usr_num,exer_num):
    label_num=min(label_num,max_label_num)
    y_class=read_classify_label(classify_file_name,label_num)
    y,d=read_label(label_file_name,label_num,usr_num)
    X_full,X_correct_num,X_exer_num,X_time,have_val_user=read_feature(feature_file_name,label_num,d,exer_num)
    
    y=y[have_val_user]
    y_class=y_class[have_val_user]

    
##    y_class=y_class[1:label_num]
##    y=y[1:label_num]
##    X_full=X_full[1:label_num,:]
##    X_correct_num=X_correct_num[1:label_num,:]
##    X_exer_num=X_exer_num[1:label_num,:]
##    X_time=X_time[1:label_num,:]

    X_dir_all,child_length=acc_dir_feature(dir_dist,exer_id,X_full)
    X_rdir_all,prerequisite_length=acc_dir_feature(rdir_dist,exer_id,X_full)
    X_udir_all,diameter_length=acc_dir_feature(udir_dist,exer_id,X_full)
#     print X_dir_all.shape[1]
#     print X_rdir_all.shape[1]
#     print X_udir_all.shape[1]
#     X_correct_num_udir_all,c=acc_dir_feature(udir_dist,exer_id,X_correct_num)

    X_dist=np.column_stack((X_dir_all,X_rdir_all,X_udir_all))

    X_raw_dense,X_raw_sparse,r_ind_org=preprocess_data(X_full,-1)
    X_dist_dense,X_dist_sparse,r_ind_dist=preprocess_data(X_dist,-1)
#     X_correct_num_d,X_correct_num_s,c=preprocess_data(X_correct_num,-1)
#     X_time_d,X_time_s,c=preprocess_data(X_time,-1)
#     X_exer_num,c,c=preprocess_data(X_exer_num,-1)



    dim_org=[0]*6
    belonging_prob_acc=[]
#     r_ind_dist=[]
#     X=np.column_stack((X_raw_sparse,X_raw_dense.mean(axis=1),X_raw_dense.sum(axis=1),X_correct_num.mean(axis=1),X_correct_num.sum(axis=1),X_time.mean(axis=1),X_time.sum(axis=1),X_exer_num.mean(axis=1),X_exer_num.sum(axis=1)))
    if label_num<=GMM_max_sample:
        X_compressed,belonging_prob_acc=GMM_compression(X_raw_dense)
#         X=np.column_stack((X_raw_sparse,X_dist_sparse,X_compressed,X_raw_dense.mean(axis=1),X_raw_dense.sum(axis=1),X_correct_num.mean(axis=1),X_correct_num.sum(axis=1),X_time.mean(axis=1),X_time.sum(axis=1),X_exer_num.mean(axis=1),X_exer_num.sum(axis=1)))
#         X=np.column_stack((X_raw_sparse,X_dist_sparse,X_correct_num_s,X_time_s,X_compressed))
        X=np.column_stack((X_raw_sparse,X_dist_sparse,X_compressed))
        dim_org[2]=X_compressed.shape[1]
    else:
#         X=np.column_stack((X_raw_sparse,X_dist_sparse,X_raw_dense.mean(axis=1),X_raw_dense.sum(axis=1),X_correct_num.mean(axis=1),X_correct_num.sum(axis=1),X_time.mean(axis=1),X_time.sum(axis=1),X_exer_num.mean(axis=1),X_exer_num.sum(axis=1)))
#         X=np.column_stack((X_raw_sparse,X_dist_sparse,X_correct_num_s,X_time_s))
        X=np.column_stack((X_raw_sparse,X_dist_sparse))

    print X.shape

    final_label_num=X.shape[0]
    shuffle_ind=list(range(final_label_num))
    random.shuffle(shuffle_ind)
    X_raw_dense=X_raw_dense[shuffle_ind,:]

    X=X[shuffle_ind,:]
    y=y[shuffle_ind]
    y_class=y_class[shuffle_ind]
    X_full=X_full[shuffle_ind,:]

    dim_org[0]=X_full.shape[1]
    dim_org[1]=X_dist.shape[1]

    dim_org[3]=child_length
    dim_org[4]=prerequisite_length
    dim_org[5]=diameter_length



    return X,X_raw_dense,X_raw_sparse,X_dist_sparse,y,dim_org,r_ind_org,r_ind_dist,belonging_prob_acc,X_full,y_class


def cross_val_methods(X,X_raw_dense,y,f_result):
    print "forest"
    clf_2 = RandomForestRegressor(max_depth=3,min_samples_split=10,n_estimators=30)
    s1=cross_val_score(clf_2,X,y,cv=5)
    print s1.mean()
    s2=cross_val_score(clf_2,X,y,cv=2)
    print s2.mean()
    f_result.write(str(s1.mean()) + "," + str(s2.mean()) + ", ")
#
#     print "Grad"
#     clf_4 = GradientBoostingRegressor(n_estimators=30)
#     s1=cross_val_score(clf_4,X,y,cv=5)
#     print s1.mean()
#     s2=cross_val_score(clf_4,X,y,cv=2)
#     print s2.mean()
#     f_result.write(str(s1.mean()) + "," + str(s2.mean()) + ", ")
    y_norm=(y-y.mean())
    y_norm=y_norm/max(y_norm)

    print "BayesianRidge"
    clf_3 = linear_model.BayesianRidge()
    s1=cross_val_score(clf_3,X_raw_dense,y_norm,cv=5)
    print s1.mean()
    s2=cross_val_score(clf_3,X_raw_dense,y_norm,cv=2)
    print s2.mean()
    f_result.write(str(s1.mean()) + "," + str(s2.mean()) + ", ")


#     print "NuSVR"
#     clf_5 = NuSVR()
#     s1=cross_val_score(clf_5,X,y,cv=5)
#     print s1.mean()
#     s2=cross_val_score(clf_5,X,y,cv=2)
#     print s2.mean()
#     f_result.write(str(s1.mean()) + "," + str(s2.mean()))
#

#     print "SVR"
#     clf_5 = SVR()
#     s=cross_val_score(clf_5,X,y,cv=5)
#     print s.mean()
#     s=cross_val_score(clf_5,X,y,cv=2)
#     print s.mean()

##    print "adaboost_tree"
##    clf_1 = AdaBoostRegressor(DecisionTreeRegressor(max_depth=2),n_estimators=50)
##    s=cross_val_score(clf_1,X,y,cv=5)
##    print s.mean()
##    s=cross_val_score(clf_1,X,y,cv=2)
##    print s.mean()

##print "KNN"
##clf_6 = KNeighborsRegressor()
##s=cross_val_score(clf_6,X,y,cv=5)
##print s.mean()
##s=cross_val_score(clf_6,X,y,cv=2)
##print s.mean()

##print "Ridge"
##clf_3 = linear_model.Ridge(alpha = 0.5)
##s=cross_val_score(clf_3,X,y,cv=5)
##print s.mean()
##s=cross_val_score(clf_3,X,y,cv=2)
##print s.mean()

##print "Lasso"
##clf_4 = linear_model.Lasso(alpha = 0.5)
##s=cross_val_score(clf_4,X,y,cv=5)
##print s.mean()
##s=cross_val_score(clf_4,X,y,cv=2)
##print s.mean()

def ROC_saving(X,y,y_class,exer_id,f_result_ROC,val_dir):
    training_ratio=0.7
    sample_num=X.shape[0]
#     dim_num=X.shape[1]

    train_size=int(sample_num*training_ratio)
    X_train=X[0:train_size,:]
    X_test=X[train_size+1:-1,:]
    y_train=y[0:train_size]
    y_test=y[train_size+1:-1]
    y_class_train=y_class[0:train_size]
    y_class_test=y_class[train_size+1:-1]

    y_mean=np.zeros_like(y_class_test)+y_class_test.mean()

    clf_1 = RandomForestRegressor(max_depth=3,min_samples_split=10,n_estimators=30)
#     clf_1 = GradientBoostingRegressor(n_estimators=30)
    clf_1.fit(X_train,y_train)
    y_est_r=clf_1.predict(X_test)

    clf_1 = RandomForestClassifier(max_depth=3,min_samples_split=10,n_estimators=30)
#     clf_1 = GradientBoostingClassifier(n_estimators=30)
    clf_1.fit(X_train,y_class_train)
    y_est_c=clf_1.predict_proba(X_test)

    y_save=np.column_stack((y_test,y_est_r,y_class_test,y_est_c[:,1],y_mean))

    np.savetxt(f_result_ROC, y_save, delimiter=",")
#     f_result.close()
    np.savetxt(val_dir+"\\ROC_results\\"+str(exer_id)+".txt", y_save, delimiter=",")



def regression_new_feature(data_location,inter_dir,val_dir,output_dir,exer_num):
    usr_num=file_len(data_location+"\\pretest_uid_list.csv")
    if not os.path.exists(val_dir):
        os.makedirs(val_dir)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

#     data_location="C:\Users\Ken-MMNlab\Desktop\MMNlab_svn\junyi\data"
    name_2_id=defaultdict(int)
    id_2_name={}
    with open(data_location + '\\pretest_exer_list.csv','rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        row=spamreader.next()
        for row in spamreader:
            name_2_id[row[1]]=int(row[0].replace('"',''))-1
            id_2_name[int(row[0].replace('"',''))-1]=row[1]
##    exer_num=len(name_2_id)

    dir_dist=load_dict_into_csv(inter_dir+"\\dir_dist.txt",exer_num)
    rdir_dist=load_dict_into_csv(inter_dir+"\\rdir_dist.txt",exer_num)
    udir_dist=load_dict_into_csv(inter_dir+"\\udir_dist.txt",exer_num)

    f_result=open(output_dir+'\\classifier_results.txt',"w")
    f_org=open(output_dir+'\\classifier_results_fw_org.txt',"w")
    f_dist=open(output_dir+'\\classifier_results_fw_dist.txt',"w")
    f_gmm=open(output_dir+'\\classifier_results_fw_gmm.txt',"w")
    f_gmm_trans=open(output_dir+'\\classifier_results_fw_gmm_trans.txt',"w")
    f_fw_sum=open(output_dir+'\\classifier_results_fw_distribution.txt',"w")
    f_sample_num_crt1=open(output_dir+'\\classifier_results_f_samples_first_correct.csv',"w")
#     f_sample_num=open(output_dir+'\\classifier_results_f_samples.txt',"w")

    f_result_ROC=open(val_dir+'\\classifier_results_ROC_RF.txt',"w")
    if not os.path.exists(val_dir+"\\ROC_results"):
        os.makedirs(val_dir+"\\ROC_results")

    for exer_id in id_2_name:
        if exer_id>5:
            continue
        exer_name=id_2_name[exer_id]
        print str(exer_id) + ", " + exer_name

#         feature_file_name=inter_dir + '\\full_feature_problems\\ken_feature_' + exer_name + '.csv'
#         feature_file_name=inter_dir + '\\feature_pieces\\' + str(exer_id) + '.txt'
        feature_file_name=data_location + '\\feature_pieces\\pretest_feature_' + exer_name + '.csv'
        label_file_name=inter_dir + '\\label_pieces\\' + str(exer_id) + '.txt'
        classify_file_name=inter_dir + '\\classify_label_pieces\\' + str(exer_id) + '.txt'
        label_num=file_len(label_file_name)
        print label_num
        if label_num<100:
            continue

        X,X_raw_dense,X_raw_sparse,X_dist_sparse,y,dim_org,r_ind_org,r_ind_dist,belonging_prob_acc,X_full,y_class=data_preparation(label_file_name,feature_file_name,label_num,classify_file_name,dir_dist,rdir_dist,udir_dist,exer_id,usr_num,exer_num)

        ROC_saving(X,y,y_class,exer_id,f_result_ROC,val_dir)

#         sample_num=(X_full!=-1).sum(axis=0)
#         f_sample_num.write(str(exer_id) + ", " + exer_name + ", " + str(X_full.shape[0]) + ", ")
#         for i in sample_num:
#             f_sample_num.write(str(i)+", ")
#         f_sample_num.write("\n")

        X_filtered=X_full[y_class==1,:]
        sample_num=(X_filtered!=-1).sum(axis=0)

        f_sample_num_crt1.write(str(exer_id) + ", " + exer_name + ", " + str(X_filtered.shape[0]) + ", ")
        for i in sample_num:
            f_sample_num_crt1.write(str(i)+", ")
        f_sample_num_crt1.write("\n")

        f_result.write(str(exer_id) + ", " + exer_name + ", ")


#         f_result.write(str(label_num) + ", ")
#         cross_val_methods(X,X_raw_dense,y,f_result)
#         f_result.write("\n")

        sparsity=float(sum((X_raw_sparse==-1).ravel()))/(X_raw_sparse.size)
        sparsity_all=float(sum((X_raw_sparse==-1).ravel())+sum((X_dist_sparse==-1).ravel()))/(X_raw_sparse.size+X_dist_sparse.size)
        trivial_error=(sum((y-y.mean())**2)/y.size)**0.5
        f_result.write(str(X_filtered.shape[0]) + ", " + str(trivial_error)+ ',' + str(sparsity) + "," + str(sparsity_all)+ ", " + str(np.mean(y)) + ",")
        print str(sparsity) + ", " + str(sparsity_all)

#         f_result.write(str(prerequisite_length) + ",")


        print "forest"
        clf_2 = RandomForestRegressor(max_depth=3,min_samples_split=10,n_estimators=forest_tree_num)
    #     s1=cross_val_score(clf_2,X,y,cv=5)
    #     print s1.mean()
        s2=cross_val_score(clf_2,X,y,cv=2)
        print s2.mean()
        f_result.write(str(str(s2.mean()) + ", "))


        clf_2 = RandomForestRegressor(max_depth=3,min_samples_split=10,n_estimators=forest_tree_num)
#         clf_2 = GradientBoostingRegressor(n_estimators=30)
#         clf_2 = RandomForestRegressor(max_depth=3,min_samples_split=10,n_estimators=50)
        clf_2.fit(X,y)
#
#         clf_3 = RandomForestRegressor(max_depth=3,min_samples_split=10,n_estimators=50)
#         clf_3.fit(X,y)

#         tree.export_graphviz(clf_2.estimators_[0].tree_, out_file='.\\output\\test.txt')
#         joblib.dump(clf_2, 'my_model.pkl', compress=9)

#         importances = (clf_2.feature_importances_+clf_3.feature_importances_)/2
        importances = clf_2.feature_importances_
#         stds=np.zeros_like(importances)
        stds = np.std([tree.feature_importances_ for tree in clf_2.estimators_],axis=0)

        f_org.write(str(exer_id) + ", " + exer_name + ", ")
        f_dist.write(str(exer_id) + ", " + exer_name + ", ")

        raw_dim=r_ind_org.size
        dist_dim=r_ind_dist.size
        save_feature_weights(r_ind_org,dim_org[0],importances[0:raw_dim],stds[0:raw_dim],f_org)
        f_dist.write(str(dim_org[3]) + ", " + str(dim_org[4]) + ", " + str(dim_org[5]) + ", ")
        save_feature_weights(r_ind_dist,dim_org[1],importances[raw_dim:raw_dim+dist_dim],stds[raw_dim:raw_dim+dist_dim],f_dist)

        f_org.write("\n")
        f_dist.write("\n")

        if label_num<=GMM_max_sample:
            pre_size=r_ind_org.size+r_ind_dist.size
            gmm_weights=importances[pre_size:pre_size+dim_org[2]]
            f_gmm_trans.write(str(exer_id) + ", " + exer_name + ", ")
            col_sum=belonging_prob_acc.sum(axis=0)
            belonging_prob_acc_norm=belonging_prob_acc/col_sum[np.newaxis,:]
            node_weights_val=(belonging_prob_acc_norm*gmm_weights[np.newaxis,:]).sum(axis=1)
            node_weights=np.zeros(exer_num)
            node_weights[r_ind_org]=node_weights_val
            print exer_num
            print len(node_weights)
#             print node_weights.sum()
#             print gmm_weights.sum()
            for i in node_weights:
                f_gmm_trans.write(str(i)+", ")
            f_gmm_trans.write("\n")

            f_gmm.write(str(exer_id) + ", " + exer_name + ", ")
            save_feature_weights(np.arange(0,dim_org[2]),dim_org[2],gmm_weights,stds[pre_size:pre_size+dim_org[2]],f_gmm)
            f_gmm.write("\n")
            for i in r_ind_org:
                f_gmm.write(str(i)+", ")
            for column in belonging_prob_acc:
                for i in column:
                    f_gmm.write(str(i)+", ")
                f_gmm.write("\n")
            f_gmm.write("\n")

            gmm_dim=32+16+8+4+2
            gmm_imp=importances[raw_dim+dist_dim:raw_dim+dist_dim+gmm_dim].sum()
        else:
            gmm_dim=0
            gmm_imp=0

        raw_imp=importances[0:raw_dim].sum()
        dist_imp=importances[raw_dim:raw_dim+dist_dim].sum()
        raw_sum_dim=2
#         correct_dim=2
#         time_dim=2
#         exer_sum_num=2
        final_fstart=raw_dim+dist_dim+gmm_dim
        raw_sum_imp=importances[final_fstart:final_fstart+raw_sum_dim].sum()
#         correct_imp=importances[final_fstart+raw_sum_dim:final_fstart+raw_sum_dim+correct_dim].sum()
#         time_imp=importances[final_fstart+raw_sum_dim+correct_dim:final_fstart+raw_sum_dim+correct_dim+time_dim].sum()
#         exer_imp=importances[final_fstart+raw_sum_dim+correct_dim+time_dim:final_fstart+raw_sum_dim+correct_dim+time_dim+exer_sum_num].sum()

#         f_fw_sum.write(str(exer_id) + ", " + exer_name + ", " + str(raw_imp) + ", " + str(dist_imp) + ", " + str(gmm_imp) + ", " + str(raw_sum_imp) + ", " + str(correct_imp) + ", " + str(time_imp) + ", " + str(exer_imp) + "\n")
        f_fw_sum.write(str(exer_id) + ", " + exer_name + ", " + str(raw_imp) + ", " + str(dist_imp) + ", " + str(gmm_imp) + ", " + str(raw_sum_imp) + "\n")

        if label_num>GMM_max_sample:
            f_result.write('no_gmm')
        f_result.write("\n")
#
#
#     #
    f_result.close()
    f_org.close()
    f_dist.close()
    f_gmm.close()
    f_gmm_trans.close()
    f_fw_sum.close()
    f_sample_num_crt1.close()
    f_result_ROC.close()
#     f_sample_num.close()

    raw_input("Press ENTER to exit")


if __name__ == '__main__':
    data_location="..\\..\\input"
    inter_dir="..\\..\\intermediate"
    val_dir="..\\..\\validation"
    output_dir="..\\..\\output\\student_modeling"
    exer_num=837
    regression_new_feature(data_location,inter_dir,val_dir,output_dir,exer_num)
