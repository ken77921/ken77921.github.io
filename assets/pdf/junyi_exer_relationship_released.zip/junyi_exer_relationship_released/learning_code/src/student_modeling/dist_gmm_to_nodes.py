'''
Created on Aug 20, 2014

@author: Ken-MMNlab
'''

import csv
import numpy as np
import ast

def file_len(fname):
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1

def load_dict_into_csv(file_name,exer_num):
    dict_out = range(exer_num)
    for key, val in csv.reader(open(file_name)):
        dict_out[int(key)] = ast.literal_eval(val)
    return dict_out

def read_hie_dist(row,start_num,node_num_org):
    hie_dist=np.zeros(node_num_org)
    node_num=int(node_num_org/2)
    while node_num>1:
        compress_factor=int(node_num_org/node_num)
        range_f=compress_factor*node_num
        weights=[float(x)/compress_factor for x in row[start_num:start_num+node_num]]
        for i in range(compress_factor):
            save_ind=np.arange(i, range_f-compress_factor+i+1, compress_factor)
            hie_dist[save_ind]=hie_dist[save_ind]+weights
        start_num=start_num+node_num
        node_num=node_num/2
    return hie_dist,start_num

def read_dist_all(row,start_ind,node_num):
    dist=np.array([float(x) for x in row[start_ind:start_ind+node_num]])+np.array([float(x) for x in row[start_ind+node_num:start_ind+2*node_num]])
    hie_dist,end_ind=read_hie_dist(row,start_ind+2*node_num,node_num)
    dist=dist+hie_dist
    hie_dist,end_ind=read_hie_dist(row,end_ind,node_num)
    dist=dist+hie_dist
    return dist,end_ind

def dist_acc_to_node(dist_weight,dir_dist,exer_id,exer_num):
    node_weight=np.zeros(exer_num)
    dir_dist_others=dir_dist[exer_id]
    dist_num=len(dist_weight)
    dist_count=[0]*dist_num
    for f in dir_dist_others:
        if f == exer_id:
            continue
        dist_count[dir_dist_others[f]-1]=dist_count[dir_dist_others[f]-1]+1

    for d in range(dist_num):
        dist_weight[d]=dist_weight[d]/dist_count[d]

    for f in dir_dist_others:
        if f == exer_id:
            continue
        node_weight[f]=dist_weight[dir_dist_others[f]-1]
    return node_weight



def dist_gmm_to_nodes(modeling_dir,inter_dir,exer_num):
##    if(len(exer_num)==0):
##        exer_num=file_len(modeling_dir+'\\classifier_results_fw_dist_trans.txt')
    f_out = open(modeling_dir+'\\classifier_results_fw_dist_trans.txt','w')
    dir_dist=load_dict_into_csv(inter_dir+"\\dir_dist.txt",exer_num)
    rdir_dist=load_dict_into_csv(inter_dir+"\\rdir_dist.txt",exer_num)
    udir_dist=load_dict_into_csv(inter_dir+"\\udir_dist.txt",exer_num)
    with open(modeling_dir+'\\classifier_results_fw_dist.txt','rb') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        for row in spamreader:
            exer_id=int(row[0])
            f_out.write(row[0] + ", " + row[1] + ", ")
            child_num=int(row[2])
            parent_num=int(row[3])
            dia_num=int(row[4])
            dist_child=[0]*child_num
            start_ind=5
            dist_child,start_ind=read_dist_all(row,start_ind,child_num)
            node_weight_child=dist_acc_to_node(dist_child,dir_dist,exer_id,exer_num)

            dist_parent,start_ind=read_dist_all(row,start_ind,parent_num)
            node_weight_parent=dist_acc_to_node(dist_parent,rdir_dist,exer_id,exer_num)

            dist_dia,start_ind=read_dist_all(row,start_ind,dia_num)
            node_weight_dia=dist_acc_to_node(dist_dia,udir_dist,exer_id,exer_num)

            node_weight=node_weight_child+node_weight_parent+node_weight_dia

#             print row[start_ind]
            for i in node_weight:
                f_out.write(str(i)+", ")

            f_out.write("\n")

    f_out.close()

    d={}
    f_out = open(modeling_dir+'\\classifier_results_fw_sum.txt','w')
    target_node_num=0
    with open(modeling_dir+'\\classifier_results_fw_org.txt','rb') as csvfile:
        reader = csv.reader(csvfile, delimiter=',')
        for row in reader:
            d[row[0]]=np.array([float(x) for x in row[2:2+exer_num]])
        gmmcsvfile=open(modeling_dir+'\\classifier_results_fw_gmm_trans.txt','rb')
        gmmreader = csv.reader(gmmcsvfile, delimiter=',')
        for row in gmmreader:
            d[row[0]]=d[row[0]]+np.array([float(x) for x in row[2:]])
        distcsvfile=open(modeling_dir+'\\classifier_results_fw_dist_trans.txt','rb')
        distreader = csv.reader(distcsvfile, delimiter=',')
        for row in distreader:
            target_node_num=target_node_num+1
##            print len(row[2:])
##            for x in row[2:]:
##                print x
##                i=float(x)
##            a=[x for x in row[2:] if len(x.strip())>0]
##            print a
            d[row[0]]=d[row[0]]+np.array([float(x) for x in row[2:] if len(x.strip())>0])
            f_out.write(row[0] + ", " + row[1] + ", ")
            for x in d[row[0]]:
                f_out.write(str(x) + ", ")
            f_out.write("\n")

    l_id=[0]*target_node_num
    l_exer_name=[0]*target_node_num
    l_sample_num=[0]*target_node_num
    l_base_error=[0]*target_node_num
    l_sparsity_s=[0]*target_node_num
    l_sparsity_c=[0]*target_node_num
    l_mean_acc=[0]*target_node_num
    l_RF_score=[0]*target_node_num
    l_RF_score_max=0

    with open(modeling_dir+'\\classifier_results.txt','rb') as csvfile:
        reader = csv.reader(csvfile, delimiter=',')
        i=0
        for row in reader:
            l_id[i]=int(row[0])
            l_exer_name[i]=row[1]
            l_sample_num[i]=int(row[2])
            l_base_error[i]=float(row[3])
            l_sparsity_s[i]=float(row[4])
            l_sparsity_c[i]=float(row[5])
            l_mean_acc[i]=float(row[6])
            l_RF_score[i]=float(row[7])
            if l_RF_score_max<float(row[7]):
                l_RF_score_max=float(row[7])
            i=i+1

    f_out = open(modeling_dir+'\\rf_score_data.csv','w')
    f_out.write('exercise id, exercise name, RF_score, RF_score_norm, correct sample number, base error, simple sparsity, complex sparsity, absolute error, mean accuracy\n')
    for i in range(target_node_num):
        f_out.write(str(l_id[i])+','+l_exer_name[i]+','+str(l_RF_score[i])+','+str(l_RF_score[i]/l_RF_score_max)+
                    ','+str(l_sample_num[i])+','+str(l_base_error[i])+','+str(l_sparsity_s[i])+','+str(l_sparsity_c[i])+
                    ','+str((1-l_RF_score[i])*l_base_error[i]) + ',' + str(l_mean_acc[i]) +'\n' )

    return target_node_num
#     f_out = open('..\\output\\classifier_results_fw_gmm_trans.txt','w')
#     with open('..\\output\\classifier_results_fw_gmm.txt','rb') as csvfile:
#         spamreader = csv.reader(csvfile, delimiter=',')
#         for row in spamreader:
#             f_out.write("\n")
#     f_out.close()

if __name__ == '__main__':
#     data_location='..\\..\\input'
    modeling_dir='..\\..\\output\\student_modeling'
    inter_dir='..\\..\\intermediate'
    exer_num=837
    dist_gmm_to_nodes(modeling_dir,inter_dir,exer_num)
