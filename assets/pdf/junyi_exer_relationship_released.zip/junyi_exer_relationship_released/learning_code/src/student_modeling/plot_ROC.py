'''
Created on Aug 18, 2014

@author: Ken-MMNlab
'''

import numpy as np
import pylab as pl
import os.path
from sklearn.metrics import roc_curve, auc

def file_len(fname):
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1

def plot_ROC(val_loc,exer_num_eff,exer_num):
    c=0
    label_num_all=[0]*exer_num_eff
    y_load=np.zeros((0,5))
    for i in range(exer_num):
        file_name=val_loc+'ROC_results\\'+str(i)+".txt"
        if os.path.isfile(file_name):
#            label_num_all[c]=file_len(file_name)
            y_i=np.loadtxt(val_loc+"classifier_results_ROC_RF.txt", delimiter=',')
            label_num_all[c]=y_i.shape[0]
            y_load=np.concatenate((y_load, y_i), axis=0)
            c=c+1
    print y_load.shape[0]
    pl.figure(1)
    pl.clf()
#    y_load=np.loadtxt(val_loc+"classifier_results_ROC_RF.txt", delimiter=',')
    y_RF_c=y_load[:,3]
    y_g=y_load[:,2]
    fpr, tpr, thresholds = roc_curve(y_load[:,2], y_load[:,1])
    roc_auc = auc(fpr, tpr)
    pl.plot(fpr, tpr, label='RF regressor (area = %0.2f)' % roc_auc)

    fpr, tpr, thresholds = roc_curve(y_load[:,2], y_load[:,3])
    roc_auc = auc(fpr, tpr)
    pl.plot(fpr, tpr, label='RF classifier (area = %0.2f)' % roc_auc)

    # y_load=np.loadtxt(".\classifier_results_ROC_GB.txt", delimiter=',')
    # fpr, tpr, thresholds = roc_curve(y_load[:,2], y_load[:,3])
    # roc_auc = auc(fpr, tpr)
    # pl.plot(fpr, tpr, label='GB classifier (area = %0.2f)' % roc_auc)

    fpr, tpr, thresholds = roc_curve(y_load[:,2], y_load[:,4])
    roc_auc = auc(fpr, tpr)
    pl.plot(fpr, tpr, label='Baseline (area = %0.2f)' % roc_auc)

    pl.plot([0, 1], [0, 1], 'k--')
    pl.xlim([0.0, 1.0])
    pl.ylim([0.0, 1.0])
    pl.xlabel('False Positive Rate')
    pl.ylabel('True Positive Rate')
    pl.title('exercise correctness prediction ROC')
    pl.legend(loc="lower right")
    pl.grid(b=True, which='major', color='b', linestyle='-')
    pl.show()

    y_weight=np.zeros_like(y_load[:,2])
    label_num_cum=np.cumsum(label_num_all)
    j=0
    for i in range(label_num_cum[-1]):
        if i>=label_num_cum[j]:
            j=j+1
        y_weight[i]=float(1)/label_num_all[j]

    # print y_g.shape
    # print y_weight.shape
    pl.figure(2)
    fpr, tpr, thresholds = roc_curve(y_g, y_RF_c, sample_weight=y_weight)
    roc_auc = auc(fpr, tpr,reorder = 'True')
    pl.plot(fpr, tpr, label='RF classifier weighted (area = %0.2f)' % roc_auc)
    # pl.plot(fpr, tpr, label='RF classifier weighted')

    fpr, tpr, thresholds = roc_curve(y_load[:,2], y_load[:,4],sample_weight=y_weight)
    roc_auc = auc(fpr, tpr)
    pl.plot(fpr, tpr, label='Baseline weighted (area = %0.2f)' % roc_auc)

    pl.plot([0, 1], [0, 1], 'k--')
    pl.xlim([0.0, 1.0])
    pl.ylim([0.0, 1.0])
    pl.xlabel('False Positive Rate')
    pl.ylabel('True Positive Rate')
    pl.title('exercise correctness prediction ROC')
    pl.legend(loc="lower right")
    pl.grid(b=True, which='major', color='b', linestyle='-')
    pl.show()

if __name__ == '__main__':
    exer_num_eff=577
    exer_num=837
    val_loc="..\\..\\validation\\"
    plot_ROC(val_loc,exer_num_eff,exer_num)
