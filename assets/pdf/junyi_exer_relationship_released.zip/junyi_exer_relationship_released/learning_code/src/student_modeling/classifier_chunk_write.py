import csv
import os
import math
# import operator
# import sys
# from collections import defaultdict

max_open_file_num=500

##for i in range(exer_num,full_exer_num):

def classifier_chunk_write(data_location,output_dir,exer_num):
    f_l=[0]*exer_num
    f_c_l=[0]*exer_num
#     f_f=[]

    if not os.path.exists(output_dir+'\\classify_label_pieces'):
        os.makedirs(output_dir+'\\classify_label_pieces')

    iter_num=int(math.ceil(exer_num/float(max_open_file_num)))
    
    for j in range(iter_num):
        upper_bound=min((j+1)*max_open_file_num,exer_num)
        for i in range(j*max_open_file_num,upper_bound):
            f_c_l[i]= open(output_dir+'\\classify_label_pieces\\'+ str(i)+'.txt','w') 

        with open(data_location+'\\pretest_label.csv','rb') as csvfile:
            spamreader = csv.reader(csvfile, delimiter=',')
            row=spamreader.next()
##            print row
            for row in spamreader:
                exe_id=int(row[2])
                if(f_c_l[exe_id-1]==0):
                    continue
                if row[8]=="TRUE":
                    f_c_l[exe_id-1].write(row[1] + ", 1\n")
                else:
                    f_c_l[exe_id-1].write(row[1] + ", 0\n")
                

        for i in range(j*max_open_file_num,upper_bound):
            f_c_l[i].close()
            f_c_l[i]=0


    if not os.path.exists(output_dir+'\\label_pieces'):
        os.makedirs(output_dir+'\\label_pieces')

    for j in range(iter_num):
        upper_bound=min((j+1)*max_open_file_num,exer_num)
        for i in range(j*max_open_file_num,upper_bound):
            f_l[i]= open(output_dir+'\\label_pieces\\'+ str(i)+'.txt','w') 

        ##f_sta=open('./classifier_data_statistics.txt','w')

    #     d=[0]*exer_num
        with open(data_location+'\\pretest_label.csv','rb') as csvfile:
            spamreader = csv.reader(csvfile, delimiter=',')
            row=spamreader.next()
            for row in spamreader:
                exe_id=int(row[2])
                if(f_l[exe_id-1]==0):
                    continue
                f_l[exe_id-1].write(row[1] + ", " + row[3] + ", " + row[4] + "\n")
        ##        d[exe_id-1]=d[exe_id-1]+1
        ##        if exe_id<=exer_num :
        ##        if exe_id>exer_num :
        ##            f_l[exe_id-1].write(row[1] + ", " + row[3] + ", " + row[4] + "\n")
        ##            f_l[exe_id-exer_num-1].write(row[1] + ", " + row[3] + ", " + row[4] + "\n")

        ##    print d
        ##    for i in range(len(d)):
        ##        f_sta.write(str(i) + ", " + str(d[i]) + "\n")
        ##

        for i in range(j*max_open_file_num,upper_bound):
            f_l[i].close()
            f_l[i]=0


    # if not os.path.exists(output_dir+'\\feature_pieces'):
    #     os.makedirs(output_dir+'\\feature_pieces')
    #
    # for i in range(exer_num):
    #     f_f.append( open(output_dir+'\\feature_pieces\\'+ str(i)+'.txt','w') )
    #
    # with open(data_location+'\\ken_feature.csv','rb') as csvfile:
    #     spamreader = csv.reader(csvfile, delimiter=',')
    #     row=spamreader.next()
    #     print row
    #     for row in spamreader:
    #         exe_id=int(row[2])
    #         sys.stdout.write('.')
    #         if exe_id<=exer_num :
    #             f_f[exe_id-1].write(row[1] + ", " + row[3] + ", " + row[4] + ", " + row[5] + ", " + row[6] + "\n")
    #
    #
    #
    # ##for i in range(full_exer_num-exer_num):
    # for i in range(exer_num):
    #     f_f[i].close()


if __name__ == '__main__':
    exer_num=837
    data_location="..\..\input"
    output_dir="..\..\intermediate"
    classifier_chunk_write(data_location,output_dir,exer_num)
