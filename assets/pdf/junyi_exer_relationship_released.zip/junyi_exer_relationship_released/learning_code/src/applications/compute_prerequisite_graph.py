'''
Created on Jan 12, 2015

@author: Ken-MMNlab
'''

from matplotlib import pyplot as plt
import csv
import numpy as np
##import pylab


max_s=9
k=5
decay_factor=0.5
spread_iter=5

def compute_prerequisite_graph(output_dir,effective_exer_num):
    csvfile=open(output_dir+"\\regression_prerequisite_results.csv",'rb')
    spamreader = csv.reader(csvfile, delimiter=',')
    d_order2name=['']*effective_exer_num
    d_order2id=[0]*effective_exer_num
    d_name2order={}
    i=0
    similarity=np.zeros((effective_exer_num,effective_exer_num))
    for row in spamreader:
        d_order2name[i]=row[1]
        d_order2id[i]=int(row[0])
        d_name2order[row[1]]=i
        similarity[i,:]=[float(x) for x in row[2:-1]]
        i=i+1

    np.fill_diagonal(similarity, 0)
    similarity=similarity/max_s
    similarity_ind_sorted=np.argsort(similarity,axis=1)
    for i in range(effective_exer_num):
        similarity[i,similarity_ind_sorted[i,1:-k-1]]=0

#     max_parent_sum=max(np.sum(similarity,axis=1))
#     similarity_nz=similarity/max_parent_sum
    similarity_nz=similarity*decay_factor
    np.fill_diagonal(similarity_nz, 1)
    similarity_nz=np.transpose(similarity_nz)
#     similarity_acc=similarity_nz
#     similarity_iter=similarity_nz

#     fig = pylab.figure(1)
#     axmatrix = fig.add_axes([0.1,0.1,0.8,0.6])
#     im = axmatrix.matshow(similarity_nz, aspect='auto', origin='lower')

    similarity_acc=np.zeros_like(similarity_nz)
    for i in range(effective_exer_num):
        similarity_iter=np.transpose(similarity_nz[:,i])
        for iter in range(spread_iter):
            similarity_iter=np.transpose(np.max(similarity_nz*similarity_iter,axis=1))
        similarity_acc[:,i]=np.transpose(similarity_iter)

#     for i in range(spread_iter):
#         similarity_iter=decay_factor*np.dot(similarity_nz,similarity_iter)
#         similarity_acc=similarity_acc+similarity_iter

#     fig = pylab.figure(2)
#     axmatrix = fig.add_axes([0.1,0.1,0.8,0.6])
#     im = axmatrix.matshow(similarity_acc, aspect='auto', origin='lower')
#     fig.show()
#
#     plt.show()

    fout=open(output_dir+"\\prerequisite_k"+str(k)+"_graph.csv",'w')
    for i in range(effective_exer_num):
        fout.write(str(d_order2id[i])+','+d_order2name[i])
        for j in range(effective_exer_num):
            fout.write(','+str(similarity_acc[i,j]))
        fout.write('\n')

#     fout=open("similarity_k5_graph_i0.csv",'w')
#     for i in range(effective_exer_num):
#         fout.write(str(d_order2id[i])+','+d_order2name[i])
#         for j in range(effective_exer_num):
#             fout.write(','+str(similarity_nz[i,j]))
#         fout.write('\n')


if __name__ == '__main__':
    effective_exer_num=577
    output_dir="..\\..\\output"
    compute_prerequisite_graph(output_dir,effective_exer_num)
