'''
Created on Jan 7, 2015

@author: Ken-MMNlab
'''

from matplotlib import pyplot as plt
import csv
from collections import defaultdict
import numpy as np
import scipy.spatial.distance as ssd
import pylab
# convert the redundant n*n square matrix form into a condensed nC2 array

import scipy.cluster as sc

def hierarchical_clustering(output_dir,effective_exer_num):
    csvfile=open(output_dir+"\\regression_similarity_results.csv",'rb')
    spamreader = csv.reader(csvfile, delimiter=',')
#     d_order2name=defaultdict(int)
    d_order2name=['']*effective_exer_num
    d_name2order={}
    distance_mat=np.zeros((effective_exer_num,effective_exer_num))
    i=0
    similarity=np.zeros((effective_exer_num,effective_exer_num))
    for row in spamreader:
        d_order2name[i]=row[1]
        d_name2order[row[1]]=i
        distance_mat[i,:]=[9-float(x) for x in row[2:-1]]
        similarity[i,:]=[float(x) for x in row[2:-1]]
        i=i+1

    distance_mat=(distance_mat+np.transpose(distance_mat))/2
    distance_mat=distance_mat-np.min(distance_mat)
    np.fill_diagonal(distance_mat, 0)

    distArray = ssd.squareform(distance_mat) # distArray[{n choose 2}-{n-i choose 2} + (j-i-1)] is the distance between points i and j
    Z=sc.hierarchy.linkage(distArray, method='average')
#     plt.figure(1)
#     sc.hierarchy.dendrogram(Z,labels=d_order2name)

    plt.figure(1)
#     Zv = sc.hierarchy.dendrogram(Z, orientation='right',labels=d_order2name,leaf_font_size=5)
    Zv = sc.hierarchy.dendrogram(Z, orientation='left',labels=d_order2name)

    idx = Zv['leaves']
    d_name_sorted=[d_order2name[idx[i]] for i in range(len(idx))]
#     fout=open("exer_name_order.csv",'w')
#     for i in range(len(idx)):
#         fout.write(d_order2name[idx[i]]+','+str(idx[i])+'\n')
#     np.savetxt("exer_name_order.csv", d_name_sorted, delimiter=",",fmt='%s')

    fig = pylab.figure()
    ax1 = fig.add_axes([0.1,0.71,0.8,0.2])
    Zh=sc.hierarchy.dendrogram(Z)

    idx = Zh['leaves']
    similarity_mat_sorted=similarity[idx,:]
    similarity_mat_sorted=similarity_mat_sorted[:,idx]
    axmatrix = fig.add_axes([0.1,0.1,0.8,0.6])
    im = axmatrix.matshow(similarity_mat_sorted, aspect='auto', origin='lower')

    axcolor = fig.add_axes([0.91,0.1,0.02,0.6])
    pylab.colorbar(im, cax=axcolor)
    fig.show()

    plt.show()

#     csvfile=open('C:\\Users\\Ken-MMNlab\\Desktop\\MMNlab_svn\\junyi\\data\\proc_exercise.csv','rb')
#     spamreader = csv.reader(csvfile, delimiter=',')
#     d_order_par=defaultdict(int)
#     row=spamreader.next()
#     for row in spamreader:
#         if row[8] not in d_name2order:
#             continue
#         parstr=row[9].replace('[','')
#         parstr=parstr.replace(']','')
#         if len(parstr) == 0:
#             continue
#         tok=[ x.strip() for x in parstr.split(',')]
#         d_order_par[d_name2order[row[8]]]=[d_name2order[par] for par in tok if (par in d_name2order)]
#
#


if __name__ == '__main__':
    output_dir="..\\..\\output"
    effective_exer_num=577
    hierarchical_clustering(output_dir,effective_exer_num)
