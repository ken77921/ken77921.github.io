'''
Created on Jan 9, 2015

@author: Ken-MMNlab
'''
import csv
import numpy as np

def compact_ranking(data_location,output_dir,effective_exer_num):
    csvfile=open(output_dir+"\\regression_similarity_results.csv",'rb')
    spamreader = csv.reader(csvfile, delimiter=',')
#     d_order2name=defaultdict(int)
    d_order2name=['']*effective_exer_num
    d_name2order={}
    i=0
    similarity=np.zeros((effective_exer_num,effective_exer_num))
    for row in spamreader:
        d_order2name[i]=row[1]
        d_name2order[row[1]]=i
        similarity[i,:]=[float(x) for x in row[2:-1]]
        i=i+1

    csvfile=open(data_location+'\\junyi_Exercise.csv','rb')
    spamreader = csv.reader(csvfile, delimiter=',')
#     parent_mat=np.zeros((effective_exer_num,effective_exer_num))
    row=spamreader.next()
    d_chinese_name={}
    for row in spamreader:
        if row[8] not in d_name2order:
            continue
        d_chinese_name[row[8]]=row[10]

    similarity_sorted=np.sort(similarity,axis=1)
    similarity_sum=np.sum(similarity_sorted[:,-6:-1],axis=1)
    not_compact_ind=np.argsort(similarity_sum)
    not_compact_list=[d_order2name[ind] for ind in not_compact_ind]
    fout=open(output_dir+"\\not_compact_order.csv",'w')

    fout.write("Rank, Exercise name, Exercise Chinese name, Similarity sum\n")
    for i in range(effective_exer_num):
#         print i
        fout.write(str(i)+','+not_compact_list[i]+','+ d_chinese_name[not_compact_list[i]] +','+str(similarity_sum[not_compact_ind[i]])+'\n')

if __name__ == '__main__':
    effective_exer_num=577
    output_dir="..\\..\\output"
    data_location="..\\..\\input"
    compact_ranking(data_location,output_dir,effective_exer_num)
