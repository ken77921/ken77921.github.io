'''
Created on Jan 9, 2015

@author: Ken-MMNlab
'''

import csv
import numpy as np

def bad_prerequisite_ranking(data_location,output_dir,effective_exer_num):
    csvfile=open(output_dir+"\\regression_prerequisite_results.csv",'rb')
    spamreader = csv.reader(csvfile, delimiter=',')
#     d_order2name=defaultdict(int)
    d_order2name=['']*effective_exer_num
    d_name2order={}
    distance_mat=np.zeros((effective_exer_num,effective_exer_num))
    i=0
    similarity=np.zeros((effective_exer_num,effective_exer_num))
    for row in spamreader:
        d_order2name[i]=row[1]
        d_name2order[row[1]]=i
        distance_mat[i,:]=[9-float(x) for x in row[2:-1]]
        similarity[i,:]=[float(x) for x in row[2:-1]]
        i=i+1

    csvfile=open(output_dir+"\\regression_similarity_results.csv",'rb')
    spamreader = csv.reader(csvfile, delimiter=',')
    i=0
    similarity_rel=np.zeros((effective_exer_num,effective_exer_num))
    for row in spamreader:
        similarity_rel[i,:]=[float(x) for x in row[2:-1]]
        i=i+1

    np.fill_diagonal(similarity, 0)
    csvfile=open(data_location+'\\junyi_Exercise.csv','rb')
    spamreader = csv.reader(csvfile, delimiter=',')
#     parent_mat=np.zeros((effective_exer_num,effective_exer_num))
    row=spamreader.next()
    d_chinese_name={}
    d_order_par={}
    d_order_max_pre={}
    parent_score=[0]*effective_exer_num

    similarity_sorted=np.sort(similarity,axis=1)

    for row in spamreader:
        if row[8] not in d_name2order:
            continue
        d_chinese_name[row[8]]=row[10]


        parstr=row[9].replace('[','')
        parstr=parstr.replace(']','')
#         if len(parstr) == 0:
#             continue
        tok=[ x.strip() for x in parstr.split(',') if (x.strip() in d_name2order and x.strip() != row[8])]
        par_num=len(tok)
        this_order=d_name2order[row[8]]
        if par_num==0:
            parent_score[this_order]=1
            d_order_par[this_order]=[]
            d_order_max_pre[this_order]=[]
            continue

        max_pre_weight=np.sum(similarity_sorted[this_order,-par_num:])
        par_pre_weight=np.sum([similarity[this_order,d_name2order[par]] for par in tok])
#         if par_pre_weight>max_pre_weight:
#             similarity_sorted_i=similarity_sorted[this_order,:]
#             print similarity_sorted_i[-1]
#             print [similarity[this_order,d_name2order[par]] for par in tok]

        parent_score[this_order]=par_pre_weight/max_pre_weight
#         if (max_pre_weight==0):
#             print similarity_sorted[this_order,:]
#             print similarity_sorted[this_order,-par_num-1:-1]
#             test=0
        d_order_par[this_order]=tok
        exer_pre_sorted=np.argsort(similarity[this_order,:])
#         print exer_pre_sorted[-par_num:-1]
#         if (row[8]=='exponents_1'):
#             print exer_pre_sorted[-par_num:]
#             print similarity[this_order,exer_pre_sorted[-1]]
        d_order_max_pre[this_order]=[d_order2name[x] for x in exer_pre_sorted[-par_num:]]

    indexs_par_score_sorted=np.argsort(parent_score)
    fout=open(output_dir+"\\bad_prerequisite_order.csv",'w')
    fout.write("Rank, Suitable score of being parents, Target exercise, Original parent(s), Suggested parent(s), Chinses target exercise, Chinses original parent(s), Chinses suggested parent(s), Prerequisite score of original parents, Prerequisite score of suggested parents\n")
    for i in range(effective_exer_num):
#         print i
        index=indexs_par_score_sorted[i]
        exer_name=d_order2name[index]
        par_rel=[similarity_rel[index,d_name2order[x]] for x in d_order_par[index]]
        max_pre_rel=[similarity_rel[index,d_name2order[x]] for x in d_order_max_pre[index]]
        fout.write(str(i)+','+ str(parent_score[index])+ ',' +exer_name+','+ ';'.join(d_order_par[index]) + ',' + ';'.join(d_order_max_pre[index])+',')
        par_chinese_name=[d_chinese_name[x] for x in d_order_par[index]]
        max_pre_chinese_name=[d_chinese_name[x] for x in d_order_max_pre[index]]
#         print d_order_par[index]
        fout.write( d_chinese_name[exer_name]+ ',' +  ';'.join(par_chinese_name)+ ',' +  ';'.join(max_pre_chinese_name) + ',' + ';'.join(map(str,par_rel)) + ',' + ';'.join(map(str,max_pre_rel)) +'\n')

if __name__ == '__main__':
    data_location="..\\..\\input"
    output_dir="..\\..\\output"
    effective_exer_num=577
    bad_prerequisite_ranking(data_location,output_dir,effective_exer_num)
