'''
Created on 2015/3/1

@author: ken77921
'''

import student_modeling
import feature_extraction
import prediction
import applications

if __name__ == '__main__':
    data_location="..\\input"
    inter_dir="..\\intermediate"
    val_dir="..\\validation"
    modeling_dir="..\\output\\student_modeling"
    output_dir="..\\output"
    feature_dir="..\\intermediate\\feature_files"

    exer_num=student_modeling.build_distances.load_exer_num(data_location)
    print 'total exercise number is '+str(exer_num)
    print 'Writing label chunks...'
    student_modeling.classifier_chunk_write(data_location,inter_dir,exer_num)
    print 'Building distances...'
    student_modeling.build_distances.build_distances(data_location,inter_dir)
    print 'Building student models (This step would take around one day)...'
    student_modeling.regression_new_feature(data_location,inter_dir,val_dir,modeling_dir,exer_num)
    print 'Post-processing feature weights...'
    effective_exer_num=student_modeling.dist_gmm_to_nodes(modeling_dir,inter_dir,exer_num)

    print 'Computing distances of exercise titles...'
    feature_extraction.exer_titles(data_location,feature_dir,modeling_dir)
    print 'Computing features related to knowledge maps...'
    feature_extraction.knowledge_maps(data_location, inter_dir, feature_dir, modeling_dir,exer_num,effective_exer_num)
    print 'Computing misc features extracted from label files...'
    feature_extraction.compute_label_features(data_location,feature_dir,exer_num)
    print 'Computing features related to user number and the order of answering exercises...'
    feature_extraction.user_num_and_order(data_location,modeling_dir,feature_dir,exer_num,effective_exer_num)

    print 'Training exercise models...'
    mode='saving_training_data'
    prediction.regression_training(data_location,feature_dir,inter_dir,val_dir,modeling_dir,exer_num,effective_exer_num,mode)
    print 'Evaluating on testing set...'
    prediction.regression_testing(data_location,feature_dir,inter_dir,val_dir,modeling_dir,exer_num,effective_exer_num)
    print 'Predicting all exercise relationships...'
    prediction.regression_predict_all(data_location,feature_dir,inter_dir,modeling_dir,output_dir,exer_num,effective_exer_num)

    print 'Computing prerequisite graph...'
    applications.compute_prerequisite_graph(output_dir,effective_exer_num)
    
