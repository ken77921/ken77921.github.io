'''
Created on Oct 31, 2014

@author: Ken-MMNlab
'''

import csv
import Levenshtein as str_match
import os
# import difflib
# import math
# import numpy as np
# eff_exer_num=370
def isfloat(value):
    try:
        float(value)
        return True
    except ValueError:
        return False

def exer_titles(data_location,output_dir,modeling_dir):
#     csvfile=open('..\\output\\easy_problem_scores_first_correct.csv','rb')
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    csvfile=open(modeling_dir+'\\classifier_results.txt','rb')
    spamreader = csv.reader(csvfile, delimiter=',')
    l_exer_name=[]
    l_ind=[]
    for row in spamreader:
        exer_name=row[1].strip()
        l_exer_name.append(exer_name)
        l_ind.append(row[0])

    csvfile=open(data_location+'\\junyi_Exercise.csv','rb')
    spamreader = csv.reader(csvfile, delimiter=',')
    row=spamreader.next()
    d_chinese_name={}
    for row in spamreader:
        d_chinese_name[row[8]]=row[10]

    eff_exer_num=len(l_exer_name)
#     dist_mat=np.zeros((eff_exer_num,eff_exer_num),float)
    fout=open(output_dir+'\\ET_pair_exer_name_dist.csv','w')
    fout_d=open(output_dir+'\\ET_pair_exer_name_dist_decomposed.csv','w')
    fout_c=open(output_dir+'\\ET_pair_exer_chinese_name_dist.csv','w')
    stop_words=['and','of','the','a']
    for i in range(eff_exer_num):
        fout.write(l_ind[i]+','+l_exer_name[i]+',')
        fout_c.write(l_ind[i]+','+l_exer_name[i]+',')
        fout_d.write(l_ind[i]+','+l_exer_name[i]+',')
        exer_a_list=l_exer_name[i].split('_')
        for j in range(eff_exer_num):
#             matcher=difflib.SequenceMatcher(a=l_exer_name[i],b=l_exer_name[j])
#             dist=difflib.SequenceMatcher.ratio(matcher)
            dist=str_match.ratio(l_exer_name[i],l_exer_name[j])
            dist_chinese=str_match.ratio(d_chinese_name[l_exer_name[i]],d_chinese_name[l_exer_name[j]])
            fout.write(str(dist)+',')
            fout_c.write(str(dist_chinese)+',')

            exer_b_list=l_exer_name[j].split('_')
            rw_sum=0
            w_sum=0
            for wa in exer_a_list:
                if wa in stop_words:
                    continue
                max_ratio=0
                for wb in exer_b_list:
                    if isfloat(wa) and isfloat(wb):
                        r=1/(1+abs(float(wa)-float(wb)))
                    else:
                        r=str_match.ratio(wa,wb)
                    if r>max_ratio:
                        max_ratio=r
                w_sum=w_sum+len(wa)
                rw_sum=rw_sum+len(wa)*max_ratio
            if w_sum==0:
                print exer_a_list
            fout_d.write(str(rw_sum/w_sum)+',')

        fout.write('\n')
        fout_c.write('\n')
        fout_d.write('\n')
    fout.close()
    fout_c.close()
    fout_d.close()



if __name__ == '__main__':
    data_location="..\\..\\input"
    output_dir="..\\..\\intermediate\\feature_files"
    modeling_dir="..\\..\\output\\student_modeling"
    exer_titles(data_location,output_dir,modeling_dir)