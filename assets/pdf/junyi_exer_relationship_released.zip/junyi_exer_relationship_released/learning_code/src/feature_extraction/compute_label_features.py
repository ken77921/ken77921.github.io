'''
Created on Oct 16, 2014

@author: Ken-MMNlab
'''
import csv

def compute_label_features(data_location,feature_dir,exer_num):
    csvfile=open(data_location+"\\pretest_label.csv",'rb')
    spamreader = csv.reader(csvfile, delimiter=',')
    d_usr_num=[0]*exer_num
    d_crct_num_sum=[0]*exer_num
    d_crct_sum=[0]*exer_num
    d_tt_avg_sum=[0]*exer_num

    d_usr_crt_num=[0]*exer_num
    d_tt_avg_crt_sum=[0]*exer_num
    d_tt_crt1_sum=[0]*exer_num
    row=spamreader.next()

    for row in spamreader:
        ind=int(row[2])-1
        d_usr_num[ind]=d_usr_num[ind]+1
        d_crct_num_sum[ind]=d_crct_num_sum[ind]+float(row[4])*int(row[3])
        d_crct_sum[ind]=d_crct_sum[ind]+float(row[4])
        d_tt_avg_sum[ind]=d_tt_avg_sum[ind]+float(row[5])
        if float(row[4]) == 0:
            continue
        d_usr_crt_num[ind]=d_usr_crt_num[ind]+1
        d_tt_avg_crt_sum[ind]=d_tt_avg_crt_sum[ind]+float(row[6])
        d_tt_crt1_sum[ind]=d_tt_crt1_sum[ind]+float(row[7])

    d_crct_num=[-1]*exer_num
    d_crct=[-1]*exer_num
    d_tt_avg=[-1]*exer_num
    d_tt_avg_crt=[-1]*exer_num
    d_tt_crt1=[-1]*exer_num

    f_out=open(feature_dir+"\\features_from_label.csv",'w')
    f_out.write('exer_id,user_num,crct_num,crct_rate,tt_avg,crct_num_sum,tt_avg_crt,tt_avg_crt1\n')
    for i in range(0,exer_num):
        if d_usr_num[i] == 0:
            continue
        d_crct_num[i]=d_crct_num_sum[i]/d_usr_num[i]
        d_crct[i]=d_crct_sum[i]/d_usr_num[i]
        d_tt_avg[i]=d_tt_avg_sum[i]/d_usr_num[i]
        f_out.write(str(i)+', '+str(d_usr_num[i])+', '+str(d_crct_num[i])+', '+str(d_crct[i])+', '+str(d_tt_avg[i])+', '+str(d_crct_num_sum[i]));
        if d_usr_crt_num[i] == 0:
            f_out.write('\n')
            continue
        d_tt_avg_crt[i]=d_tt_avg_crt_sum[i]/d_usr_crt_num[i]
        d_tt_crt1[i]=d_tt_crt1_sum[i]/d_usr_crt_num[i]
        f_out.write(', '+str(d_tt_avg_crt[i])+', '+str(d_tt_crt1[i])+'\n')

if __name__ == '__main__':
    data_location="..\\..\\input"
    feature_dir="..\\..\\intermediate\\feature_files"
    exer_num=837
    compute_label_features(data_location,feature_dir,exer_num)
