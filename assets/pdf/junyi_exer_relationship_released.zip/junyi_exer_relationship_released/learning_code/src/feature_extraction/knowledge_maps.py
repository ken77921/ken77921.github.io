'''
Created on 2015/2/23

@author: ken77921
'''

import csv
import numpy as np
import ast
from scipy.spatial import distance

def load_dict_into_csv(file_name,exer_num):
    dict_out = range(exer_num)
    for key, val in csv.reader(open(file_name)):
        dict_out[int(key)] = ast.literal_eval(val)
    return dict_out

def have_enough_sample(fname,exer_num):
    d=[-1]*exer_num
    with open(fname) as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        for row in spamreader:
            d[int(row[0])]=row[1]
    return d

def knowledge_maps(data_location, inter_dir, feature_dir,  modeling_dir,exer_num,effective_exer_num):
    udir_dist=load_dict_into_csv(inter_dir+"\\udir_dist.txt",exer_num)
    dir_dist=load_dict_into_csv(inter_dir+"\\dir_dist.txt",exer_num)
    rdir_dist=load_dict_into_csv(inter_dir+"\\rdir_dist.txt",exer_num)

    f_sibling=open(feature_dir+'\\KT_sibling_list.csv','w')
    d=have_enough_sample(modeling_dir+'\\classifier_results.txt',exer_num)
    csvfile=open(modeling_dir+'\\classifier_results.txt','rb')

    spamreader = csv.reader(csvfile, delimiter=',')
#     score=[0.0]*effective_exer_num
    i=0

    l_o=[]
    d_o={}

    for row in spamreader:
        d_o[row[1].strip()]=i
        l_o.append(row[1].strip())

        target_exer_id=int(row[0])
        target_dist=dir_dist[target_exer_id]
        target_udist=udir_dist[target_exer_id]
        target_rdist=rdir_dist[target_exer_id]

        par_1_list=[]
        sibling_cand_list=[]
        for j in range(exer_num):
            if d[j]==-1:
                continue

            if (j in target_rdist):
                if (target_rdist[j] == 1):
                    par_1_list.append(j)

            if (j in target_udist):
                if (target_udist[j] == 2) and (j not in target_dist) and (j not in target_rdist):
                    sibling_cand_list.append(j)

        sibling_list=[]
        for j in sibling_cand_list:
            have_same_par=0
            for k in par_1_list:
                if udir_dist[k][j]==1:
                    have_same_par=1
                    break
            if have_same_par==1:
                sibling_list.append(j)

#         choose_ind=[0]*4

        f_sibling.write(row[0] + ", " + row[1] + ", ")
        sibling_arr=[0]*exer_num
        for x in sibling_list:
            sibling_arr[x]=1
        for j in range(exer_num):
            f_sibling.write(str(sibling_arr[j])+", ")
        f_sibling.write('\n')

        i=i+1
    csvfile.close()

    csvfile=open(data_location+'\\junyi_Exercise.csv','rb')
    spamreader = csv.reader(csvfile, delimiter=',')
    X=np.zeros((effective_exer_num,2),float)
    for row in spamreader:
        if(row[8] not in d_o):
            continue
        ind=d_o[row[8]]
        X[ind,0]=int(row[5])
        X[ind,1]=int(row[16])

    Y = distance.squareform(distance.pdist(X, 'euclidean'))
    fout=open(feature_dir+'\\KM_pair_location_dist.csv','w')
    for i in range(0,effective_exer_num):
        fout.write(l_o[i]+',')
        for y in Y[i,:]:
            fout.write(str(y)+',')
        fout.write('\n')

if __name__ == '__main__':
    data_location="..\\..\\input"
    feature_dir="..\\..\\intermediate\\feature_files"
    inter_dir="..\\..\\intermediate"
    modeling_dir="..\\..\\output\\student_modeling"
    exer_num=837
    effective_exer_num=577
    knowledge_maps(data_location, inter_dir, feature_dir, modeling_dir,exer_num,effective_exer_num)
