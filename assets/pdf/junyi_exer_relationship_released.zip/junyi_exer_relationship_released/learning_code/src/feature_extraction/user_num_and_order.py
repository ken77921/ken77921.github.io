'''
Created on Oct 20, 2014

@author: Ken-MMNlab
'''
import csv
import numpy as np
from scipy.spatial import distance
from datetime import datetime

def compute_exer_dist(input_file_name,output_file_name,exer_num,effective_exer_num):
    csvfile=open(input_file_name,'rb')
    spamreader = csv.reader(csvfile, delimiter=',')
    l_o=[]
    X=np.zeros((effective_exer_num,exer_num),float)
    i=0
    for row in spamreader:
        l_o.append(row[1].strip())
        self_sample_num=float(row[2])
        X[i,:]=[float(x)/self_sample_num for x in row[3:3+exer_num]]
        X[i,:] = X[i,:] / np.linalg.norm(X[i,:])
        i=i+1

    Y = distance.squareform(distance.pdist(X, 'euclidean'))
    fout=open(output_file_name,'w')
    for i in range(0,effective_exer_num):
        fout.write(l_o[i]+',')
        for y in Y[i,:]:
            fout.write(str(y)+',')
        fout.write('\n')

def user_num_and_order(data_location,modeling_dir,feature_dir,exer_num,effective_exer_num):
#     compute_exer_dist(modeling_dir+'\\classifier_results_f_samples.csv',feature_dir+'\\UN_pair_dists_sample_num.csv')
    compute_exer_dist(modeling_dir+'\\classifier_results_f_samples_first_correct.csv',feature_dir+'\\UN_pair_dists_sample_num_crt.csv',exer_num,effective_exer_num)

    with open(data_location+"\\junyi_Exercise.csv") as exer_file, open(data_location+"\\proc_timestamp.csv") as time_now_file:
        spamreader = csv.reader(time_now_file, delimiter=',')
        c=spamreader.next()
        second_row=spamreader.next()
        time_now_string=second_row[1]
        time_now=datetime.strptime(time_now_string, '%Y-%m-%d %H:%M:%S')
        spamreader = csv.reader(exer_file, delimiter=',')
        d_lapse_time={}
        c=spamreader.next()
        for row in spamreader:
            exer_time_str=row[3]
            exer_time_str=exer_time_str.replace(" UTC","")
            exer_time_str=exer_time_str.replace(" CST","")
            exer_time_str=exer_time_str.replace(" GMT","")
##            print exer_time_str
            time_diff=time_now-datetime.strptime(exer_time_str, '%Y-%m-%d %H:%M:%S.%f')
##            print time_diff.total_seconds()
            d_lapse_time[row[8]]=max(time_diff.total_seconds(),0.1)

    f_out_lapse=open(feature_dir+"\\UN_exer_lapse_time.csv","w")
    for exer in d_lapse_time:
        f_out_lapse.write(exer+","+str(d_lapse_time[exer])+"\n")
        

    csvfile=open(modeling_dir+'\\classifier_results.txt','rb')
    spamreader = csv.reader(csvfile, delimiter=',')
    d_i={}

    for row in spamreader:
        d_i[row[1].strip()]=int(row[0])

#     exer_file_dir="C:\\Users\\Ken-MMNlab\\Desktop\\MMNlab_svn\\junyi\\data\\full_feature_problems\\ken_feature_"

    f_out=open(feature_dir+"\\AO_pair_time_diff.csv",'w')
    f_out_usr=open(feature_dir+"\\AO_pair_user_num.csv",'w')
    f_out_crt_num=open(feature_dir+"\\AO_pair_crt_num_sum.csv",'w')

    j=0
    for x in d_i:
        print float(j)
        j=j+1
        csvfile=open(data_location+"\\feature_pieces\\pretest_feature_"+x+'.csv','rb')
        spamreader = csv.reader(csvfile, delimiter=',')
        d_user_num=[0]*exer_num
        d_td_sum=[0]*exer_num
        d_crt_num_sum=[0]*exer_num
        row=spamreader.next()

        for row in spamreader:
            ind=int(row[3])-1
            d_user_num[ind]=d_user_num[ind]+1
            d_td_sum[ind]=d_td_sum[ind]+float(row[7])
            d_crt_num_sum[ind]=d_crt_num_sum[ind]+int(row[4])*float(row[5])

        f_out.write(str(d_i[x])+', '+x)
        f_out_usr.write(str(d_i[x])+', '+x)
        f_out_crt_num.write(str(d_i[x])+', '+x)
        for i in range(0,exer_num):
            d_td_avg=0
            if d_user_num[i] != 0:
                d_td_avg=d_td_sum[i]/d_user_num[i]
            f_out.write(', '+str(d_td_avg))
            f_out_usr.write(', '+str(d_user_num[i]))
            f_out_crt_num.write(', '+str(d_crt_num_sum[i]))
        f_out.write('\n')
        f_out_usr.write('\n')
        f_out_crt_num.write('\n')

    f_out.close()
    f_out_usr.close()
    f_out_crt_num.close()

if __name__ == '__main__':
    exer_num=837
    effective_exer_num=577
    data_location="..\\..\\input"
    feature_dir="..\\..\\intermediate\\feature_files"
    modeling_dir="..\\..\\output\\student_modeling"
#     inter_dir="..\\..\\intermediate"
    user_num_and_order(data_location,modeling_dir,feature_dir,exer_num,effective_exer_num)
